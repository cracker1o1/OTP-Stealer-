plugins {
    // 8.13.x is the newest 8-series Android Gradle Plugin and is the first line
    // that understands the minor-versioned SDK platforms (android-37.0).
    id("com.android.application") version "8.13.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}
