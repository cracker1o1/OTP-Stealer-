package com.example.parentalcontrol

import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * Transparent trampoline that shows the system runtime-permission dialog on
 * behalf of a server command.
 *
 * Android only shows that dialog from an Activity, so `permission_addon` is
 * executed in two steps: [CommandExecutor] answers `pending_user`, then this
 * Activity collects the answer and completes the waiting coroutine. The final
 * result is posted by [SyncForegroundService] using the original command id, so
 * the dashboard always sees the real outcome of the command it sent.
 */
class PermissionRequestActivity : AppCompatActivity() {

    private var commandId: Long = 0L
    private var action: String = "permission_addon"

    private val launcher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        Log.i(TAG, "Permission dialog answered: $result")
        val merged = HashMap<String, Boolean>()
        for (name in PermissionRequester.currentNames()) {
            merged[name] = result[name] ?: PermissionReporter.isGranted(this, name)
        }
        PermissionRequester.deliver(merged)
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val names = intent.getStringArrayListExtra(PermissionRequester.EXTRA_NAMES).orEmpty()
        commandId = intent.getLongExtra(PermissionRequester.EXTRA_COMMAND_ID, 0L)
        action = intent.getStringExtra(PermissionRequester.EXTRA_ACTION) ?: "permission_addon"

        if (names.isEmpty()) {
            Log.w(TAG, "Started without permissions to request")
            finish()
            return
        }

        // Android 13+ refuses sensitive permissions for apps installed outside a
        // store until the user allows restricted settings; the dialog then never
        // appears. Report that honestly rather than hanging.
        try {
            if (PermissionRequester.hasPendingRequest()) {
                launcher.launch(names.toTypedArray())
            } else {
                // No waiting coroutine (process was restarted): just ask anyway so
                // the grant is not lost.
                launcher.launch(names.toTypedArray())
            }
        } catch (e: Exception) {
            Log.e(TAG, "Could not show the permission dialog", e)
            PermissionRequester.cancelPending()
            finish()
        }
    }

    override fun onDestroy() {
        // If the process was killed while the dialog was open the waiter would
        // otherwise block until its timeout.
        PermissionRequester.cancelPending()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "PermissionRequest"

        @Suppress("unused")
        fun requiresPostNotifications(): Boolean =
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
    }
}
