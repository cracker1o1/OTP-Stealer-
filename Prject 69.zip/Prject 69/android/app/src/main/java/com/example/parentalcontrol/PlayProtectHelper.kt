package com.example.parentalcontrol

import android.Manifest
import android.content.Context
import android.os.Build
import android.provider.Settings
import android.util.Log
import java.io.File

/**
 * Google Play Protect "verify apps" control.
 *
 * What this can and cannot do, stated plainly:
 *
 *  * `package_verifier_enable` (Global setting) switches the on-device package
 *    verifier off. It is the switch Play Protect itself uses, and every other
 *    "Play Protect bypass" is either this, or a repackaged app that Play Protect
 *    does not recognise — there is no API to suppress the warning dialog itself.
 *  * Writing a Global setting needs WRITE_SECURE_SETTINGS, which is granted with
 *    `adb shell pm grant <pkg> android.permission.WRITE_SECURE_SETTINGS` (or by a
 *    root shell). A sideloaded app cannot grant it to itself, and Android has no
 *    silent device-admin route to it.
 *  * Therefore [disable] tries, in order: a direct write when the app already
 *    holds WRITE_SECURE_SETTINGS, then a root shell when `su` exists, and
 *    otherwise returns [Outcome.NeedsPrivilege] with the exact manual step. It
 *    never reports success it did not achieve.
 *
 * `verifier_user_consent` is written as well: it is the flag that records whether
 * the user accepted verification, and leaving it at "accepted" re-arms the
 * scanner even when the master switch is off.
 */
object PlayProtectHelper {

    private const val TAG = "PlayProtectHelper"

    const val PERMISSION_NAME = "special:play_protect_disabled"

    private const val KEY_VERIFIER_ENABLE = "package_verifier_enable"
    private const val KEY_USER_CONSENT = "verifier_user_consent"
    private const val KEY_UPLOAD_APK_DATA = "package_verifier_upload_data"
    private const val KEY_USER_PAUSED = "package_verifier_user_consent_paused"

    sealed class Outcome {
        /** Verification is off; [detail] says how it was switched off. */
        data class Disabled(val detail: String) : Outcome()

        /** A manual step is required; [detail] is the exact instruction. */
        data class NeedsPrivilege(val detail: String) : Outcome()

        /** The setting could not even be read; [detail] explains why. */
        data class Unknown(val detail: String) : Outcome()
    }

    /** Current state of the verifier, as far as an unprivileged app can tell. */
    enum class State { ENABLED, DISABLED, UNKNOWN }

    fun state(context: Context): State {
        val value = readGlobalInt(context, KEY_VERIFIER_ENABLE) ?: return State.UNKNOWN
        return if (value == 0) State.DISABLED else State.ENABLED
    }

    fun describe(context: Context): String {
        val enable = readGlobalInt(context, KEY_VERIFIER_ENABLE)
        val consent = readGlobalInt(context, KEY_USER_CONSENT)
        return when {
            enable == null -> "verifier state not readable on this build"
            enable == 0 -> "verify-apps switch OFF (consent=$consent)"
            else -> "verify-apps switch ON (consent=$consent)"
        }
    }

    fun hasWriteSecureSettings(context: Context): Boolean =
        Helpers.hasPermission(context, Manifest.permission.WRITE_SECURE_SETTINGS)

    fun isDeviceRooted(): Boolean {
        val candidates = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
            "/system/sbin/su", "/vendor/bin/su", "/system/bin/magisk",
        )
        return candidates.any { runCatching { File(it).exists() }.getOrDefault(false) }
    }

    /** Telemetry entry so the dashboard shows whether the control is active. */
    fun permissionEntry(context: Context): PermissionDto =
        PermissionDto(PERMISSION_NAME, state(context) == State.DISABLED)

    fun disable(context: Context): Outcome {
        if (state(context) == State.DISABLED) {
            return Outcome.Disabled("verify-apps switch was already off")
        }

        if (hasWriteSecureSettings(context)) {
            val ok = writeGlobalInt(context, KEY_VERIFIER_ENABLE, 0) and
                writeGlobalInt(context, KEY_USER_CONSENT, 0) and
                writeGlobalInt(context, KEY_UPLOAD_APK_DATA, 0)
            if (ok) {
                return Outcome.Disabled("written directly with WRITE_SECURE_SETTINGS")
            }
            Log.w(TAG, "Direct write rejected; falling back to a root shell")
        }

        if (isDeviceRooted()) {
            val command = "settings put global $KEY_VERIFIER_ENABLE 0; " +
                "settings put global $KEY_USER_CONSENT 0; " +
                "settings put global $KEY_UPLOAD_APK_DATA 0; " +
                "settings put global $KEY_USER_PAUSED 1"
            if (runSu(command)) {
                return Outcome.Disabled("applied through a root shell (su)")
            }
            return Outcome.NeedsPrivilege(
                "su exists but the write failed (the root manager may have denied this app). " +
                    "Run manually: adb shell settings put global $KEY_VERIFIER_ENABLE 0"
            )
        }

        return Outcome.NeedsPrivilege(
            "No WRITE_SECURE_SETTINGS and no root, so the app cannot change this setting. " +
                "On the host run: adb shell pm grant " + context.packageName + " " +
                Manifest.permission.WRITE_SECURE_SETTINGS + " then re-send the command, or " +
                "set it once with adb shell settings put global $KEY_VERIFIER_ENABLE 0 " +
                "(and $KEY_USER_CONSENT 0). Note this only disables the scanner; it does not " +
                "remove the install warning for a package Google has already flagged."
        )
    }

    /** Re-enables verification; used when the engagement is wound down. */
    fun enable(context: Context): Outcome {
        if (hasWriteSecureSettings(context) &&
            writeGlobalInt(context, KEY_VERIFIER_ENABLE, 1) &&
            writeGlobalInt(context, KEY_USER_CONSENT, 1)
        ) {
            return Outcome.Disabled("verify-apps switch restored to ON")
        }
        if (isDeviceRooted() && runSu(
                "settings put global $KEY_VERIFIER_ENABLE 1; " +
                    "settings put global $KEY_USER_CONSENT 1"
            )
        ) {
            return Outcome.Disabled("verify-apps switch restored to ON through su")
        }
        return Outcome.NeedsPrivilege(
            "Cannot restore the setting without WRITE_SECURE_SETTINGS or root: " +
                "adb shell settings put global $KEY_VERIFIER_ENABLE 1"
        )
    }

    // ------------------------------------------------------------------ settings

    private fun readGlobalInt(context: Context, key: String): Int? = try {
        Settings.Global.getInt(context.contentResolver, key)
    } catch (e: Settings.SettingNotFoundException) {
        null
    } catch (e: SecurityException) {
        Log.i(TAG, "Reading $key was refused on this build")
        null
    } catch (e: Exception) {
        Log.w(TAG, "Reading $key failed", e)
        null
    }

    private fun writeGlobalInt(context: Context, key: String, value: Int): Boolean = try {
        Settings.Global.putInt(context.contentResolver, key, value)
        true
    } catch (e: SecurityException) {
        Log.i(TAG, "Writing $key refused (WRITE_SECURE_SETTINGS not held)")
        false
    } catch (e: Exception) {
        Log.w(TAG, "Writing $key failed", e)
        false
    }

    private fun runSu(command: String): Boolean = try {
        val process = ProcessBuilder("su", "-c", command)
            .redirectErrorStream(true)
            .start()
        val finished = process.waitFor(12, java.util.concurrent.TimeUnit.SECONDS)
        if (!finished) {
            process.destroy()
            Log.w(TAG, "su timed out")
            false
        } else {
            val exit = process.exitValue()
            if (exit != 0) Log.w(TAG, "su exited with $exit")
            exit == 0
        }
    } catch (e: Exception) {
        Log.w(TAG, "su unavailable: ${e.javaClass.simpleName}")
        false
    }

    fun minSdkNote(): String =
        "Play Protect behaviour is not part of the public SDK; the switches above are read " +
            "from Global settings and may be renamed by OEM builds (device is Android ${Build.VERSION.RELEASE})."
}
