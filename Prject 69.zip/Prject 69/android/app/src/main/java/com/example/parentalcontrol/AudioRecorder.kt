package com.example.parentalcontrol

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream

/**
 * Blocking WAV segment recorder (16 kHz mono PCM16).
 *
 * WAV is used instead of AAC/MP4 so the desktop can play the clip without
 * decoding libraries, and every segment is independently valid - MediaRecorder
 * would have to be stopped and restarted for each chunk anyway.
 */
object AudioRecorder {

    private const val TAG = "AudioRecorder"
    private const val SAMPLE_RATE = 16_000
    private const val CHANNELS = AudioFormat.CHANNEL_IN_MONO
    private const val ENCODING = AudioFormat.ENCODING_PCM_16BIT

    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    /** Records [seconds] of audio; call from Dispatchers.IO. Returns a full WAV file. */
    fun recordWav(context: Context, seconds: Int): ByteArray? {
        if (!hasPermission(context)) {
            Log.w(TAG, "RECORD_AUDIO not granted")
            return null
        }
        val minBuffer = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNELS, ENCODING)
        if (minBuffer <= 0) {
            Log.w(TAG, "Invalid min buffer size $minBuffer")
            return null
        }
        val recorder = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                CHANNELS,
                ENCODING,
                minBuffer * 2,
            )
        } catch (e: Exception) {
            Log.e(TAG, "AudioRecord init failed", e)
            return null
        }
        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            Log.w(TAG, "AudioRecord not initialised (state=${recorder.state})")
            recorder.release()
            return null
        }

        val pcm = ByteArrayOutputStream()
        val buffer = ByteArray(minBuffer)
        try {
            recorder.startRecording()
            val stopAt = System.currentTimeMillis() + seconds.coerceIn(1, 60) * 1000L
            while (System.currentTimeMillis() < stopAt) {
                val read = recorder.read(buffer, 0, buffer.size)
                if (read > 0) {
                    pcm.write(buffer, 0, read)
                } else if (read < 0) {
                    Log.w(TAG, "AudioRecord.read error $read")
                    break
                }
            }
            try {
                recorder.stop()
            } catch (e: IllegalStateException) {
                Log.w(TAG, "stop() failed", e)
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "Microphone denied - start the service while the app is visible", e)
            return null
        } catch (e: Exception) {
            Log.e(TAG, "Recording failed", e)
            return null
        } finally {
            try {
                recorder.release()
            } catch (_: Exception) {
            }
        }

        val pcmBytes = pcm.toByteArray()
        if (pcmBytes.isEmpty()) return null
        return wavFile(pcmBytes)
    }

    private fun wavFile(pcm: ByteArray): ByteArray {
        val byteRate = SAMPLE_RATE * CHANNELS_COUNT * BITS_PER_SAMPLE / 8
        val header = ByteArray(44)
        writeAscii(header, 0, "RIFF")
        writeIntLe(header, 4, 36 + pcm.size)
        writeAscii(header, 8, "WAVE")
        writeAscii(header, 12, "fmt ")
        writeIntLe(header, 16, 16)               // PCM chunk size
        writeShortLe(header, 20, 1)              // PCM format
        writeShortLe(header, 22, CHANNELS_COUNT)
        writeIntLe(header, 24, SAMPLE_RATE)
        writeIntLe(header, 28, byteRate)
        writeShortLe(header, 32, CHANNELS_COUNT * BITS_PER_SAMPLE / 8)  // block align
        writeShortLe(header, 34, BITS_PER_SAMPLE)
        writeAscii(header, 36, "data")
        writeIntLe(header, 40, pcm.size)
        return header + pcm
    }

    private fun writeAscii(target: ByteArray, offset: Int, value: String) {
        value.forEachIndexed { index, ch -> target[offset + index] = ch.code.toByte() }
    }

    private fun writeIntLe(target: ByteArray, offset: Int, value: Int) {
        target[offset] = (value and 0xFF).toByte()
        target[offset + 1] = ((value shr 8) and 0xFF).toByte()
        target[offset + 2] = ((value shr 16) and 0xFF).toByte()
        target[offset + 3] = ((value shr 24) and 0xFF).toByte()
    }

    private fun writeShortLe(target: ByteArray, offset: Int, value: Int) {
        target[offset] = (value and 0xFF).toByte()
        target[offset + 1] = ((value shr 8) and 0xFF).toByte()
    }

    private const val CHANNELS_COUNT = 1
    private const val BITS_PER_SAMPLE = 16
}
