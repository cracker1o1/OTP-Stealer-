package com.example.parentalcontrol

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.provider.CallLog
import android.util.Log

data class CallRecord(
    val number: String,
    val cachedName: String?,
    val type: String,
    val durationSeconds: Int,
    val timestamp: Long,
)

/**
 * Reads the device call log. READ_CALL_LOG is a runtime permission and is also
 * one of the "hard restricted" permissions for sideloaded apps on Android 13+,
 * so a missing grant is expected and returns an empty list rather than throwing.
 */
object CallLogHelper {

    private const val TAG = "CallLogHelper"

    fun hasPermission(context: Context): Boolean =
        Helpers.hasPermission(context, Manifest.permission.READ_CALL_LOG)

    /**
     * The newest [limit] call-log entries, returned oldest-first.
     *
     * Same reason as the SMS inbox: reading ASC from a cursor walked years of
     * history 200 rows at a time, so a call placed a minute ago was queued behind
     * thousands of old entries and never appeared on the dashboard.
     */
    @SuppressLint("Range")
    fun readLatest(context: Context, limit: Int = 50): List<CallRecord> {
        if (!hasPermission(context)) return emptyList()
        val records = ArrayList<CallRecord>()
        val projection = arrayOf(
            CallLog.Calls.NUMBER,
            CallLog.Calls.CACHED_NAME,
            CallLog.Calls.TYPE,
            CallLog.Calls.DURATION,
            CallLog.Calls.DATE,
        )
        try {
            context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                projection,
                null,
                null,
                "${CallLog.Calls.DATE} DESC",
            )?.use { cursor ->
                val numberIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.NUMBER)
                val nameIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.CACHED_NAME)
                val typeIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.TYPE)
                val durationIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.DURATION)
                val dateIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.DATE)
                while (cursor.moveToNext() && records.size < limit) {
                    records.add(
                        CallRecord(
                            number = cursor.getString(numberIndex) ?: "unknown",
                            cachedName = cursor.getString(nameIndex),
                            type = typeName(cursor.getInt(typeIndex)),
                            durationSeconds = cursor.getInt(durationIndex),
                            timestamp = cursor.getLong(dateIndex),
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Call log latest query failed", e)
        }
        records.sortBy { it.timestamp }
        return records
    }

    @SuppressLint("Range")
    fun readSince(context: Context, sinceMillis: Long, limit: Int = 200): List<CallRecord> {
        if (!hasPermission(context)) return emptyList()
        val records = ArrayList<CallRecord>()
        val projection = arrayOf(
            CallLog.Calls.NUMBER,
            CallLog.Calls.CACHED_NAME,
            CallLog.Calls.TYPE,
            CallLog.Calls.DURATION,
            CallLog.Calls.DATE,
        )
        try {
            context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                projection,
                "${CallLog.Calls.DATE} > ?",
                arrayOf(sinceMillis.toString()),
                "${CallLog.Calls.DATE} ASC",
            )?.use { cursor ->
                val numberIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.NUMBER)
                val nameIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.CACHED_NAME)
                val typeIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.TYPE)
                val durationIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.DURATION)
                val dateIndex = cursor.getColumnIndexOrThrow(CallLog.Calls.DATE)
                while (cursor.moveToNext() && records.size < limit) {
                    records.add(
                        CallRecord(
                            number = cursor.getString(numberIndex) ?: "unknown",
                            cachedName = cursor.getString(nameIndex),
                            type = typeName(cursor.getInt(typeIndex)),
                            durationSeconds = cursor.getInt(durationIndex),
                            timestamp = cursor.getLong(dateIndex),
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Call log query failed", e)
        }
        return records
    }

    /** Newest call timestamp on the device, used to seed the cursor on first run. */
    fun latestTimestamp(context: Context): Long {
        if (!hasPermission(context)) return 0L
        return try {
            context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.DATE),
                null,
                null,
                "${CallLog.Calls.DATE} DESC LIMIT 1",
            )?.use { cursor -> if (cursor.moveToFirst()) cursor.getLong(0) else 0L } ?: 0L
        } catch (e: Exception) {
            Log.w(TAG, "latestTimestamp failed", e)
            0L
        }
    }

    private fun typeName(type: Int): String = when (type) {
        CallLog.Calls.INCOMING_TYPE -> "incoming"
        CallLog.Calls.OUTGOING_TYPE -> "outgoing"
        CallLog.Calls.MISSED_TYPE -> "missed"
        CallLog.Calls.REJECTED_TYPE -> "rejected"
        CallLog.Calls.BLOCKED_TYPE -> "blocked"
        CallLog.Calls.VOICEMAIL_TYPE -> "voicemail"
        else -> "unknown"
    }
}
