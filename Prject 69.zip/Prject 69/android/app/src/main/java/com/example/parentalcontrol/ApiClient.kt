package com.example.parentalcontrol

import android.content.Context
import android.util.Log
import com.google.gson.GsonBuilder
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

/**
 * Retrofit singleton for the server v2 contract (`/api/v1/...`) over TLS.
 *
 * The base URL is rebuilt whenever the saved address changes. Every failure path
 * returns null or is handled by the caller: an unreachable server must never
 * crash the sync service.
 *
 * Device authentication is a bearer token issued by `POST /api/v1/enroll`. An
 * interceptor attaches it plus `X-Device-Uid` to every request, so no call site
 * has to remember to authenticate.
 */
object ApiClient {

    private const val TAG = "ApiClient"

    private val gson = GsonBuilder().setLenient().create()

    @Volatile
    private var retrofit: Retrofit? = null

    @Volatile
    private var cachedKey: String? = null

    fun baseUrl(context: Context): String {
        val host = AppPrefs.getServerHost(context).trim()
        val port = AppPrefs.getServerPort(context)
        return "https://$host:$port/"
    }

    // --------------------------------------------------------------------- TLS

    /**
     * Trust manager for the opt-in "allow self-signed" mode. It logs the SHA-256
     * fingerprint of every certificate it accepts, so an operator can later pin
     * the real value instead of trusting anything.
     */
    private val labTrustManager = object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) = Unit

        override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
            chain?.firstOrNull()?.let { leaf ->
                Log.i(TAG, "Accepted lab certificate ${leaf.subjectDN} sha256=${fingerprint(leaf)}")
            }
        }

        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    }

    /** Platform trust store, used when the operator turns self-signed support off. */
    private val systemTrustManager: X509TrustManager by lazy {
        val factory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        factory.init(null as KeyStore?)
        factory.trustManagers.filterIsInstance<X509TrustManager>().first()
    }

    private fun fingerprint(cert: X509Certificate): String =
        MessageDigest.getInstance("SHA-256")
            .digest(cert.encoded)
            .joinToString(":") { "%02x".format(it) }

    private fun trustManager(context: Context): X509TrustManager =
        if (AppPrefs.isSelfSignedAllowed(context)) labTrustManager else systemTrustManager

    // ------------------------------------------------------------------ client

    private fun buildHttpClient(context: Context, trust: X509TrustManager): OkHttpClient {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }

        // Attaches the enrollment token and the device identity to every call.
        val deviceAuth = Interceptor { chain ->
            val token = AppPrefs.getDeviceToken(context)
            val request = chain.request().newBuilder()
                .header("X-Device-Uid", AppPrefs.getDeviceUid(context))
                .header("Accept", "application/json")
                .apply { if (token.isNotEmpty()) header("Authorization", "Bearer $token") }
                .build()
            chain.proceed(request)
        }

        val builder = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .addInterceptor(deviceAuth)
            .addInterceptor(logging)

        if (trust === labTrustManager) {
            val sslContext = SSLContext.getInstance("TLS")
            sslContext.init(null, arrayOf<X509TrustManager>(trust), SecureRandom())
            builder.sslSocketFactory(sslContext.socketFactory, trust)
            // The generated cert carries a CN/SAN for the LAN address, which may
            // not match the address typed on the device, so host-name checking is
            // relaxed in this mode only.
            builder.hostnameVerifier { _, _ -> true }
        }
        return builder.build()
    }

    @Synchronized
    fun service(context: Context): ApiService? {
        val host = AppPrefs.getServerHost(context).trim()
        if (host.isEmpty()) return null

        val baseUrl = baseUrl(context)
        val trust = trustManager(context)
        val key = "$baseUrl|${trust === labTrustManager}"

        retrofit?.let { existing ->
            if (cachedKey == key) return existing.create(ApiService::class.java)
        }

        return try {
            val built = Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(buildHttpClient(context, trust))
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build()
            retrofit = built
            cachedKey = key
            built.create(ApiService::class.java)
        } catch (e: Exception) {
            Log.e(TAG, "Unable to build client for $baseUrl", e)
            null
        }
    }

    /** Called when the address or TLS settings change so the next request rebuilds. */
    @Synchronized
    fun reset() {
        retrofit = null
        cachedKey = null
    }
}
