package com.example.parentalcontrol

import android.Manifest
import android.annotation.SuppressLint
import android.app.AppOpsManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.provider.Telephony
import android.util.Log
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Calendar
import java.util.Locale
import kotlin.coroutines.resume

data class AppRecord(val packageName: String, val label: String)

data class SmsRecord(val sender: String, val body: String, val timestamp: Long)

data class UsageRecord(
    val packageName: String,
    val label: String,
    val totalTimeMs: Long,
    val dayStart: Long,
)

object Helpers {

    private const val TAG = "Helpers"

    // ---------------------------------------------------------------- permissions

    fun hasPermission(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun hasLocationPermission(context: Context): Boolean =
        hasPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ||
            hasPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)

    fun hasSmsPermission(context: Context): Boolean =
        hasPermission(context, Manifest.permission.READ_SMS)

    /** AppOps is authoritative; the manifest declaration alone is not enough. */
    fun hasUsageAccess(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager
            ?: return false
        return try {
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName,
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName,
                )
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            Log.w(TAG, "AppOps usage check failed", e)
            false
        }
    }

    fun hasOverlayPermission(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun accessibilityComponent(context: Context): ComponentName =
        ComponentName(context, MyAccessibilityService::class.java)

    /**
     * Reads the same setting the system's Accessibility screen writes:
     * a colon-separated list of flattened component names.
     */
    fun isAccessibilityServiceEnabled(context: Context): Boolean {
        val expected = accessibilityComponent(context)
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
        ) ?: return false
        return enabled.split(':')
            .mapNotNull { ComponentName.unflattenFromString(it) }
            .any { it == expected }
    }

    // ------------------------------------------------------------------- SMS inbox

    /**
     * The newest [limit] inbox messages, returned oldest-first.
     *
     * The inbox is queried DESC so a phone that has years of traffic answers with
     * today's messages immediately. Reading ASC from a cursor walked the archive
     * forward at 200 rows a cycle, which is why a message that had just arrived
     * could sit behind thousands of 2024 rows and never reach the server.
     */
    @SuppressLint("Range")
    fun readSmsLatest(context: Context, limit: Int = 50): List<SmsRecord> {
        if (!hasSmsPermission(context)) return emptyList()
        val records = ArrayList<SmsRecord>()
        val projection = arrayOf(
            Telephony.Sms.ADDRESS,
            Telephony.Sms.BODY,
            Telephony.Sms.DATE,
        )
        try {
            context.contentResolver.query(
                Telephony.Sms.Inbox.CONTENT_URI,
                projection,
                null,
                null,
                "${Telephony.Sms.DATE} DESC",
            )?.use { cursor ->
                val addressIndex = cursor.getColumnIndexOrThrow(Telephony.Sms.ADDRESS)
                val bodyIndex = cursor.getColumnIndexOrThrow(Telephony.Sms.BODY)
                val dateIndex = cursor.getColumnIndexOrThrow(Telephony.Sms.DATE)
                while (cursor.moveToNext() && records.size < limit) {
                    records.add(
                        SmsRecord(
                            sender = cursor.getString(addressIndex) ?: "unknown",
                            body = cursor.getString(bodyIndex).orEmpty(),
                            timestamp = cursor.getLong(dateIndex),
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "SMS latest query failed", e)
        }
        // The uploader and the cursor both read this list in time order.
        records.sortBy { it.timestamp }
        return records
    }

    @SuppressLint("Range")
    fun readSmsSince(context: Context, sinceMillis: Long, limit: Int = 100): List<SmsRecord> {
        if (!hasSmsPermission(context)) return emptyList()
        val records = ArrayList<SmsRecord>()
        val projection = arrayOf(
            Telephony.Sms.ADDRESS,
            Telephony.Sms.BODY,
            Telephony.Sms.DATE,
        )
        try {
            context.contentResolver.query(
                Telephony.Sms.Inbox.CONTENT_URI,
                projection,
                "${Telephony.Sms.DATE} > ?",
                arrayOf(sinceMillis.toString()),
                "${Telephony.Sms.DATE} ASC",
            )?.use { cursor ->
                val addressIndex = cursor.getColumnIndexOrThrow(Telephony.Sms.ADDRESS)
                val bodyIndex = cursor.getColumnIndexOrThrow(Telephony.Sms.BODY)
                val dateIndex = cursor.getColumnIndexOrThrow(Telephony.Sms.DATE)
                while (cursor.moveToNext() && records.size < limit) {
                    records.add(
                        SmsRecord(
                            sender = cursor.getString(addressIndex) ?: "unknown",
                            body = cursor.getString(bodyIndex).orEmpty(),
                            timestamp = cursor.getLong(dateIndex),
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "SMS inbox query failed", e)
        }
        return records
    }

    // --------------------------------------------------------------- installed apps

    /** Requires QUERY_ALL_PACKAGES on API 30+; falls back to the app's own visibility. */
    fun getInstalledApps(context: Context): List<AppRecord> {
        val packageManager = context.packageManager
        val packages: List<PackageInfo> = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                packageManager.getInstalledPackages(PackageManager.PackageInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                packageManager.getInstalledPackages(0)
            }
        } catch (e: Exception) {
            Log.e(TAG, "getInstalledPackages failed", e)
            return emptyList()
        }

        return packages.mapNotNull { packageInfo ->
            val applicationInfo = packageInfo.applicationInfo ?: return@mapNotNull null
            val label = try {
                packageManager.getApplicationLabel(applicationInfo).toString()
            } catch (e: Exception) {
                packageInfo.packageName
            }
            AppRecord(packageInfo.packageName, label)
        }.sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    // ------------------------------------------------------------------ usage stats

    fun getDailyUsage(context: Context): List<UsageRecord> {
        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE)
            as? android.app.usage.UsageStatsManager ?: return emptyList()
        val midnight = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val now = System.currentTimeMillis()

        val stats = try {
            usageStatsManager.queryUsageStats(
                android.app.usage.UsageStatsManager.INTERVAL_DAILY,
                midnight,
                now,
            )
        } catch (e: Exception) {
            Log.e(TAG, "queryUsageStats failed", e)
            return emptyList()
        }
        if (stats.isNullOrEmpty()) return emptyList()

        val packageManager = context.packageManager
        return stats
            .filter { it.totalTimeInForeground > 0L }
            .groupBy { it.packageName }
            .map { (packageName, entries) ->
                UsageRecord(
                    packageName = packageName,
                    label = labelFor(packageManager, packageName),
                    totalTimeMs = entries.sumOf { it.totalTimeInForeground },
                    dayStart = midnight,
                )
            }
            .sortedByDescending { it.totalTimeMs }
    }

    private fun labelFor(packageManager: PackageManager, packageName: String): String = try {
        @Suppress("DEPRECATION")
        val info = packageManager.getApplicationInfo(packageName, 0)
        packageManager.getApplicationLabel(info).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        packageName
    }

    // -------------------------------------------------------------------- location

    /**
     * One-shot high-accuracy fix. Returns null (never throws) when permission was
     * revoked, Play Services is unavailable or the provider times out.
     */
    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(context: Context, timeoutMs: Long = 25_000L): Location? {
        if (!hasLocationPermission(context)) return null
        val client = LocationServices.getFusedLocationProviderClient(context)

        val current = withTimeoutOrNull(timeoutMs) {
            suspendCancellableCoroutine<Location?> { continuation ->
                val tokenSource = CancellationTokenSource()
                continuation.invokeOnCancellation { tokenSource.cancel() }
                try {
                    client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, tokenSource.token)
                        .addOnSuccessListener { location ->
                            if (continuation.isActive) continuation.resume(location)
                        }
                        .addOnFailureListener { error ->
                            Log.w(TAG, "getCurrentLocation failed", error)
                            if (continuation.isActive) continuation.resume(null)
                        }
                } catch (e: SecurityException) {
                    Log.w(TAG, "Location permission revoked mid-request", e)
                    if (continuation.isActive) continuation.resume(null)
                }
            }
        }
        if (current != null) return current

        // Fresh fix can fail indoors; a recent cached fix is better than nothing.
        return withTimeoutOrNull(5_000L) {
            suspendCancellableCoroutine<Location?> { continuation ->
                try {
                    client.lastLocation
                        .addOnSuccessListener { location ->
                            if (continuation.isActive) continuation.resume(location)
                        }
                        .addOnFailureListener {
                            if (continuation.isActive) continuation.resume(null)
                        }
                } catch (e: SecurityException) {
                    if (continuation.isActive) continuation.resume(null)
                }
            }
        }
    }
}
