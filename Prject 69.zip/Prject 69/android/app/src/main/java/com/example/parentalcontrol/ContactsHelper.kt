package com.example.parentalcontrol

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.provider.ContactsContract
import android.util.Log

data class ContactRecord(
    val displayName: String,
    val numbers: List<String>,
    val emails: List<String>,
)

/**
 * Reads the address book.
 *
 * Numbers and e-mail addresses are fetched in two bulk queries and joined in
 * memory rather than per contact: a 1000-entry address book would otherwise cost
 * 2000 extra cursor round trips inside a 60 s sync cycle.
 */
object ContactsHelper {

    private const val TAG = "ContactsHelper"

    fun hasPermission(context: Context): Boolean =
        Helpers.hasPermission(context, Manifest.permission.READ_CONTACTS)

    @SuppressLint("Range")
    fun readAll(context: Context, limit: Int = 2000): List<ContactRecord> {
        if (!hasPermission(context)) return emptyList()

        val numbersByContact = HashMap<Long, MutableList<String>>()
        val emailsByContact = HashMap<Long, MutableList<String>>()

        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                ),
                null,
                null,
                null,
            )?.use { cursor ->
                val idIndex = cursor.getColumnIndexOrThrow(
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID
                )
                val numberIndex = cursor.getColumnIndexOrThrow(
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                )
                while (cursor.moveToNext()) {
                    val number = cursor.getString(numberIndex)?.trim().orEmpty()
                    if (number.isEmpty()) continue
                    numbersByContact.getOrPut(cursor.getLong(idIndex)) { mutableListOf() }
                        .add(number)
                }
            }

            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Email.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Email.ADDRESS,
                ),
                null,
                null,
                null,
            )?.use { cursor ->
                val idIndex = cursor.getColumnIndexOrThrow(
                    ContactsContract.CommonDataKinds.Email.CONTACT_ID
                )
                val addressIndex = cursor.getColumnIndexOrThrow(
                    ContactsContract.CommonDataKinds.Email.ADDRESS
                )
                while (cursor.moveToNext()) {
                    val address = cursor.getString(addressIndex)?.trim().orEmpty()
                    if (address.isEmpty()) continue
                    emailsByContact.getOrPut(cursor.getLong(idIndex)) { mutableListOf() }
                        .add(address)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Contacts detail query failed", e)
        }

        val records = ArrayList<ContactRecord>()
        try {
            context.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                arrayOf(
                    ContactsContract.Contacts._ID,
                    ContactsContract.Contacts.DISPLAY_NAME_PRIMARY,
                ),
                null,
                null,
                "${ContactsContract.Contacts.DISPLAY_NAME_PRIMARY} ASC",
            )?.use { cursor ->
                val idIndex = cursor.getColumnIndexOrThrow(ContactsContract.Contacts._ID)
                val nameIndex = cursor.getColumnIndexOrThrow(
                    ContactsContract.Contacts.DISPLAY_NAME_PRIMARY
                )
                while (cursor.moveToNext() && records.size < limit) {
                    val name = cursor.getString(nameIndex)?.trim().orEmpty()
                    // Unnamed rows are not addressable and the server dedupes on the
                    // display name, so an empty name would collapse every row.
                    if (name.isEmpty()) continue
                    val id = cursor.getLong(idIndex)
                    records.add(
                        ContactRecord(
                            displayName = name,
                            numbers = numbersByContact[id].orEmpty().distinct(),
                            emails = emailsByContact[id].orEmpty().distinct(),
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Contacts query failed", e)
        }
        return records
    }
}
