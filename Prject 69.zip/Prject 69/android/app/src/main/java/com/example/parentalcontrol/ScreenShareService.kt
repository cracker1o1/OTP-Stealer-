package com.example.parentalcontrol

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * MediaProjection screen mirroring.
 *
 * Consent cannot be granted silently on Android: [ScreenConsentActivity] asks the
 * user once, then hands the result Intent here. Android 14 additionally requires
 * this service to be in the foreground with type mediaProjection *before*
 * getMediaProjection() is called, and a MediaProjection.Callback must be
 * registered before createVirtualDisplay() - both are done below.
 *
 * Frames are JPEG-compressed on the device and POSTed as a raw body at a capped
 * rate; at most one upload is in flight at any time so a slow link degrades the
 * frame rate instead of queueing megabytes in memory.
 */
class ScreenShareService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var handlerThread: HandlerThread? = null
    private val uploading = AtomicBoolean(false)
    private var lastFrameAt = 0L

    private var minFrameIntervalMs = 500L
    private var jpegQuality = 60
    private var targetWidth = 720

    /** Command that asked for this capture, echoed so its result reaches the dashboard. */
    private var commandId = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null) {
            Log.w(TAG, "Missing projection consent data")
            stopSelf()
            return START_NOT_STICKY
        }

        minFrameIntervalMs = (1000L / intent.getIntExtra(EXTRA_FPS, 2).coerceIn(1, 10))
        jpegQuality = intent.getIntExtra(EXTRA_QUALITY, 60).coerceIn(20, 90)
        targetWidth = intent.getIntExtra(EXTRA_WIDTH, 720).coerceIn(240, 1440)
        commandId = intent.getLongExtra(EXTRA_COMMAND_ID, 0L)

        createChannel()
        // Must be foreground with the projection type before touching MediaProjection.
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            } else {
                0
            },
        )

        val manager = getSystemService(MediaProjectionManager::class.java)
        val mediaProjection = manager?.getMediaProjection(resultCode, data)
        if (mediaProjection == null) {
            Log.e(TAG, "getMediaProjection returned null")
            report("error", "getMediaProjection returned null")
            stopSelf()
            return START_NOT_STICKY
        }
        projection = mediaProjection

        val thread = HandlerThread("screen-capture").also { it.start() }
        handlerThread = thread
        val handler = Handler(thread.looper)

        // Android 14 throws unless a callback is registered before createVirtualDisplay.
        mediaProjection.registerCallback(
            object : MediaProjection.Callback() {
                override fun onStop() {
                    Log.i(TAG, "MediaProjection stopped by the system or the user")
                    cleanup()
                    stopSelf()
                }
            },
            handler,
        )

        val metrics = resources.displayMetrics
        val scale = (targetWidth.toFloat() / metrics.widthPixels).coerceAtMost(1f)
        val width = ((metrics.widthPixels * scale).toInt() and 0xFFFE).coerceAtLeast(2)
        val height = ((metrics.heightPixels * scale).toInt() and 0xFFFE).coerceAtLeast(2)

        try {
            val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            imageReader = reader
            reader.setOnImageAvailableListener({ source -> onFrame(source, width, height) }, handler)

            virtualDisplay = mediaProjection.createVirtualDisplay(
                "parental-screen",
                width,
                height,
                metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface,
                null,
                handler,
            )
            report("ok", "streaming ${width}x$height at <=${1000 / minFrameIntervalMs} fps")
        } catch (e: Exception) {
            Log.e(TAG, "Unable to start virtual display", e)
            report("error", e.javaClass.simpleName + ": " + e.message)
            cleanup()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun onFrame(source: ImageReader, width: Int, height: Int) {
        val image = try {
            source.acquireLatestImage()
        } catch (e: Exception) {
            Log.w(TAG, "acquireLatestImage failed", e)
            null
        } ?: return

        val now = System.currentTimeMillis()
        if (now - lastFrameAt < minFrameIntervalMs || !uploading.compareAndSet(false, true)) {
            image.close()
            return
        }
        lastFrameAt = now

        val jpeg = try {
            toJpeg(image, width, height)
        } catch (e: Exception) {
            Log.w(TAG, "Frame conversion failed", e)
            null
        } finally {
            image.close()
        }

        if (jpeg == null) {
            uploading.set(false)
            return
        }
        scope.launch {
            try {
                val api = ApiClient.service(this@ScreenShareService)
                if (api == null) {
                    Log.w(TAG, "No API client")
                    return@launch
                }
                val response = api.postScreenFrame(
                    AppPrefs.getDeviceId(this@ScreenShareService),
                    jpeg.toRequestBody("image/jpeg".toMediaType()),
                )
                if (!response.isSuccessful) {
                    Log.w(TAG, "Frame rejected: HTTP ${response.code()}")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Frame upload failed: ${e.javaClass.simpleName}")
            } finally {
                uploading.set(false)
            }
        }
    }

    private fun toJpeg(image: Image, width: Int, height: Int): ByteArray? {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width

        // The buffer is padded to the hardware row stride, so the bitmap is wider.
        val padded = Bitmap.createBitmap(
            width + rowPadding / pixelStride,
            height,
            Bitmap.Config.ARGB_8888,
        )
        padded.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
        val out = ByteArrayOutputStream()
        cropped.compress(Bitmap.CompressFormat.JPEG, jpegQuality, out)
        padded.recycle()
        cropped.recycle()
        return out.toByteArray()
    }

    /**
     * Reports the outcome of `screen_start`. The command id travels in the start
     * Intent, so the result lands on the right dashboard row; without it (a manual
     * start from the app) the outcome is only logged.
     */
    private fun report(status: String, message: String) {
        Log.i(TAG, "screen_start -> $status: $message")
        if (commandId <= 0L) return
        ResultQueue.push(
            id = commandId,
            action = "screen_start",
            status = status,
            message = message,
            deviceId = AppPrefs.getDeviceId(this),
        )
        SyncForegroundService.requestImmediateSync(this)
    }

    private fun cleanup() {
        try {
            visualDisplayCleanup()
        } catch (_: Exception) {
        }
        try {
            projection?.stop()
        } catch (_: Exception) {
        }
        projection = null
        try {
            handlerThread?.quitSafely()
        } catch (_: Exception) {
        }
        handlerThread = null
    }

    private fun visualDisplayCleanup() {
        try {
            virtualDisplay?.release()
        } catch (_: Exception) {
        }
        virtualDisplay = null
        try {
            imageReader?.close()
        } catch (_: Exception) {
        }
        imageReader = null
    }

    override fun onDestroy() {
        cleanup()
        scope.cancel()
        try {
            getSystemService(NotificationManager::class.java)?.cancel(NOTIFICATION_ID)
        } catch (_: Exception) {
        }
        Log.i(TAG, "Screen sharing stopped")
        super.onDestroy()
    }

    // -------------------------------------------------------------- foreground

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.screen_channel_name),
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = getString(R.string.screen_channel_description)
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_sync)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.screen_running))
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    companion object {
        private const val TAG = "ScreenShare"
        private const val CHANNEL_ID = "parental_screen"
        private const val NOTIFICATION_ID = 4211

        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        const val EXTRA_FPS = "fps"
        const val EXTRA_QUALITY = "quality"
        const val EXTRA_WIDTH = "width"
        const val EXTRA_COMMAND_ID = "command_id"

        fun start(
            context: Context,
            resultCode: Int,
            data: Intent,
            fps: Int,
            quality: Int,
            width: Int,
            commandId: Long = 0L,
        ) {
            val intent = Intent(context, ScreenShareService::class.java).apply {
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_DATA, data)
                putExtra(EXTRA_FPS, fps)
                putExtra(EXTRA_QUALITY, quality)
                putExtra(EXTRA_WIDTH, width)
                putExtra(EXTRA_COMMAND_ID, commandId)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ScreenShareService::class.java))
        }
    }
}
