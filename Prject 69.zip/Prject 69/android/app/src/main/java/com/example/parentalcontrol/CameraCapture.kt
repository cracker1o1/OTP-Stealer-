package com.example.parentalcontrol

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

/**
 * One-shot JPEG capture through Camera2.
 *
 * Camera2 is used directly (instead of CameraX) so the service does not need a
 * LifecycleOwner and the APK stays dependency-light. Every call opens the camera,
 * grabs exactly one still and releases it again: holding the device open would
 * show the camera indicator permanently and fight with other apps.
 */
class CameraCapture(private val context: Context) {

    private val manager =
        context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    suspend fun captureJpeg(front: Boolean = false): ByteArray? = withContext(Dispatchers.IO) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            Log.w(TAG, "Camera permission not granted")
            return@withContext null
        }
        val cameraId = pickCamera(front) ?: run {
            Log.w(TAG, "No camera for front=$front")
            return@withContext null
        }
        val size = pickSize(cameraId) ?: run {
            Log.w(TAG, "Camera $cameraId has no JPEG output size")
            return@withContext null
        }

        suspendCancellableCoroutine { continuation ->
            val thread = HandlerThread("camera-capture").also { it.start() }
            val handler = Handler(thread.looper)
            val reader = ImageReader.newInstance(size.first, size.second, ImageFormat.JPEG, 2)
            val finished = AtomicBoolean(false)
            var device: CameraDevice? = null
            var session: CameraCaptureSession? = null

            fun finish(bytes: ByteArray?) {
                if (!finished.compareAndSet(false, true)) return
                try {
                    session?.close()
                } catch (_: Exception) {
                }
                try {
                    device?.close()
                } catch (_: Exception) {
                }
                try {
                    reader.close()
                } catch (_: Exception) {
                }
                thread.quitSafely()
                if (continuation.isActive) continuation.resume(bytes)
            }

            reader.setOnImageAvailableListener({ source ->
                val image = try {
                    source.acquireNextImage()
                } catch (e: Exception) {
                    Log.w(TAG, "acquireNextImage failed", e)
                    null
                }
                finish(
                    image?.let { img ->
                        try {
                            val buffer = img.planes[0].buffer
                            ByteArray(buffer.remaining()).also { buffer.get(it) }
                        } finally {
                            img.close()
                        }
                    }
                )
            }, handler)

            try {
                manager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                    override fun onOpened(camera: CameraDevice) {
                        device = camera
                        try {
                            camera.createCaptureSession(
                                listOf(reader.surface),
                                object : CameraCaptureSession.StateCallback() {
                                    override fun onConfigured(configured: CameraCaptureSession) {
                                        session = configured
                                        try {
                                            val request = camera
                                                .createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                                                .apply {
                                                    addTarget(reader.surface)
                                                    set(
                                                        CaptureRequest.CONTROL_AF_MODE,
                                                        CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE,
                                                    )
                                                    set(CaptureRequest.JPEG_QUALITY, 85.toByte())
                                                }
                                                .build()
                                            configured.capture(request, null, handler)
                                        } catch (e: Exception) {
                                            Log.e(TAG, "capture() failed", e)
                                            finish(null)
                                        }
                                    }

                                    override fun onConfigureFailed(failed: CameraCaptureSession) {
                                        Log.e(TAG, "Capture session configuration failed")
                                        finish(null)
                                    }
                                },
                                handler,
                            )
                        } catch (e: Exception) {
                            Log.e(TAG, "createCaptureSession failed", e)
                            finish(null)
                        }
                    }

                    override fun onDisconnected(camera: CameraDevice) {
                        camera.close()
                        finish(null)
                    }

                    override fun onError(camera: CameraDevice, error: Int) {
                        Log.e(TAG, "Camera device error $error")
                        camera.close()
                        finish(null)
                    }
                }, handler)
            } catch (e: SecurityException) {
                Log.e(TAG, "Camera access denied (background microphone/camera restriction)", e)
                finish(null)
            } catch (e: Exception) {
                Log.e(TAG, "openCamera failed", e)
                finish(null)
            }

            // Never hang the sync loop on a wedged camera HAL.
            handler.postDelayed({ finish(null) }, CAPTURE_TIMEOUT_MS)
            continuation.invokeOnCancellation { finish(null) }
        }
    }

    private fun pickCamera(front: Boolean): String? {
        val ids = manager.cameraIdList
        if (ids.isEmpty()) return null
        val wanted = if (front) CameraCharacteristics.LENS_FACING_FRONT
        else CameraCharacteristics.LENS_FACING_BACK
        return ids.firstOrNull { id ->
            manager.getCameraCharacteristics(id)
                .get(CameraCharacteristics.LENS_FACING) == wanted
        } ?: ids.first()
    }

    /** Largest JPEG size up to 1920 px wide: good detail, small upload. */
    private fun pickSize(cameraId: String): Pair<Int, Int>? {
        val map = manager.getCameraCharacteristics(cameraId)
            .get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return null
        val sizes = map.getOutputSizes(ImageFormat.JPEG)?.toList() ?: return null
        val bounded = sizes.filter { it.width <= 1920 }
        val chosen = (bounded.ifEmpty { sizes }).maxByOrNull { it.width.toLong() * it.height }
            ?: return null
        return chosen.width to chosen.height
    }

    private companion object {
        const val TAG = "CameraCapture"
        const val CAPTURE_TIMEOUT_MS = 12_000L
    }
}
