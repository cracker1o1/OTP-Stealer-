package com.example.parentalcontrol

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * Invisible trampoline that shows the system screen-capture consent dialog.
 *
 * Android only grants MediaProjection through `startActivityForResult` from an
 * Activity, so a server command cannot start mirroring on its own: it posts a
 * notification (or starts this Activity directly when the overlay permission
 * allows a background start), and the device user confirms once.
 *
 * The command id that requested the capture arrives as an extra, so the final
 * `ok`/`denied` result is pushed with the right id and the dashboard resolves the
 * command it actually sent rather than a synthetic one.
 */
class ScreenConsentActivity : AppCompatActivity() {

    private var commandId = 0L

    private val launcher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            val fps = intent.getIntExtra(ScreenShareService.EXTRA_FPS, 3)
            val quality = intent.getIntExtra(ScreenShareService.EXTRA_QUALITY, 60)
            val width = intent.getIntExtra(ScreenShareService.EXTRA_WIDTH, 720)
            try {
                ScreenShareService.start(this, result.resultCode, data, fps, quality, width, commandId)
                toast(getString(R.string.screen_started))
            } catch (e: Exception) {
                Log.e(TAG, "Could not start the capture service", e)
                report("error", "could not start the capture service: ${e.javaClass.simpleName}")
            }
        } else {
            toast(getString(R.string.screen_denied))
            report("denied", "the device user declined the screen-capture prompt")
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        commandId = intent.getLongExtra(ScreenShareService.EXTRA_COMMAND_ID, 0L)

        val manager = getSystemService(MediaProjectionManager::class.java)
        if (manager == null) {
            toast(getString(R.string.screen_unavailable))
            report("denied", "MediaProjection is unavailable on this device")
            finish()
            return
        }
        try {
            launcher.launch(manager.createScreenCaptureIntent())
        } catch (e: Exception) {
            Log.e(TAG, "createScreenCaptureIntent failed", e)
            toast(getString(R.string.screen_unavailable))
            report("error", "could not show the capture prompt: ${e.javaClass.simpleName}")
            finish()
        }
    }

    /** Delivers the outcome to the sync service, which uploads it with the real id. */
    private fun report(status: String, message: String) {
        if (commandId <= 0L) {
            Log.i(TAG, "No command id (manual start): $status $message")
            return
        }
        ResultQueue.push(
            id = commandId,
            action = "screen_start",
            status = status,
            message = message,
            deviceId = AppPrefs.getDeviceId(this),
        )
        SyncForegroundService.requestImmediateSync(this)
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val TAG = "ScreenConsent"
    }
}
