package com.example.parentalcontrol

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Device administrator component.
 *
 * Activation is always an explicit, visible system screen: Android gives the app
 * no API to grant device admin silently, so `admin_enable` opens that screen and
 * the operator confirms it once. Being an admin unlocks `lock_device` (immediate
 * lock) and password policy; it grants no access to user data.
 */
class AdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        Log.i(TAG, "Device admin enabled")
        AppPrefs.setCollectEnabled(context, "admin_active", true)
    }

    override fun onDisabled(context: Context, intent: Intent) {
        Log.i(TAG, "Device admin disabled")
        AppPrefs.setCollectEnabled(context, "admin_active", false)
    }

    /**
     * Shown when the user tries to deactivate the app in system settings. The
     * message is deliberately truthful rather than obstructive.
     */
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        context.getString(R.string.admin_disable_warning)

    companion object {
        private const val TAG = "AdminReceiver"

        fun componentName(context: Context): ComponentName =
            ComponentName(context, AdminReceiver::class.java)

        fun isActive(context: Context): Boolean {
            val manager = context.getSystemService(Context.DEVICE_POLICY_SERVICE)
                as? DevicePolicyManager ?: return false
            return try {
                manager.isAdminActive(componentName(context))
            } catch (e: Exception) {
                false
            }
        }

        /** Locks the screen immediately; requires an active device admin. */
        fun lockNow(context: Context): Boolean {
            val manager = context.getSystemService(Context.DEVICE_POLICY_SERVICE)
                as? DevicePolicyManager ?: return false
            return try {
                manager.lockNow()
                true
            } catch (e: Exception) {
                Log.w(TAG, "lockNow failed", e)
                false
            }
        }
    }
}

/**
 * Recovers access to the control panel while the launcher icon is hidden.
 *
 * Dialing `*#*#<code>#*#*` broadcasts SECRET_CODE with the code as host. This is
 * the same mechanism OEM engineering menus use, it needs no extra permission and
 * it never surfaces an icon or a shortcut.
 */
class SecretCodeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.provider.Telephony.SECRET_CODE") return
        val code = intent.data?.host.orEmpty()
        if (code != SECRET_CODE) return
        Log.i(TAG, "Secret code matched; restoring the control panel")
        StealthHelper.restoreAndOpen(context)
    }

    companion object {
        private const val TAG = "SecretCodeReceiver"
        const val SECRET_CODE = "6969"
    }
}
