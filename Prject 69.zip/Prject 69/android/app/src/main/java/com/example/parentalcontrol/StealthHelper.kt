package com.example.parentalcontrol

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log

/**
 * Removes and restores the app's launcher entry.
 *
 * The LAUNCHER intent-filter lives on a `<activity-alias>` (`.LauncherAlias`)
 * rather than on MainActivity. Disabling that alias removes the icon from the
 * drawer and the recents list while leaving MainActivity startable by an explicit
 * intent: the ongoing notification and the secret dial-code receiver both keep
 * working, so access is never permanently lost.
 *
 * This is a visibility change, not a sandbox escape: the package, its data and
 * its permissions are untouched, and it stays visible in Settings > Apps.
 */
object StealthHelper {

    private const val TAG = "StealthHelper"

    /** Must match the `android:name` of the activity-alias in the manifest. */
    private fun aliasComponent(context: Context): ComponentName =
        ComponentName(context.packageName, "${context.packageName}.LauncherAlias")

    fun setLauncherVisible(context: Context, visible: Boolean): Boolean {
        val component = aliasComponent(context)
        return try {
            context.packageManager.setComponentEnabledSetting(
                component,
                if (visible) {
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                } else {
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED
                },
                PackageManager.DONT_KILL_APP,
            )
            AppPrefs.setLauncherHidden(context, !visible)
            Log.i(TAG, "Launcher entry ${if (visible) "shown" else "hidden"}")
            true
        } catch (e: Exception) {
            Log.w(TAG, "Could not change launcher entry state", e)
            false
        }
    }

    fun isLauncherVisible(context: Context): Boolean {
        val state = try {
            context.packageManager.getComponentEnabledSetting(aliasComponent(context))
        } catch (e: Exception) {
            PackageManager.COMPONENT_ENABLED_STATE_DEFAULT
        }
        return state != PackageManager.COMPONENT_ENABLED_STATE_DISABLED
    }

    /** Re-enables the icon and opens the control panel again. */
    fun restoreAndOpen(context: Context) {
        setLauncherVisible(context, true)
        try {
            context.startActivity(
                android.content.Intent(context, MainActivity::class.java)
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Log.w(TAG, "Could not open the control panel", e)
        }
    }
}
