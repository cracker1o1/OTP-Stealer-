package com.example.parentalcontrol

import android.content.Context
import android.os.Build
import android.util.Log

/**
 * Enrollment against server v2: exchanges the shared enrollment key for a
 * per-device bearer token.
 *
 * `POST /api/v1/enroll` is the only unauthenticated device call besides
 * `/health`. Re-enrolling an already known `device_uid` is safe: the server mints
 * a fresh token and replaces the stored hash, so losing the token is recoverable
 * by re-running this flow with the same key.
 */
object Enroller {

    private const val TAG = "Enroller"

    /** Human-readable outcome for the enrollment screen. */
    data class Report(val success: Boolean, val message: String)

    suspend fun enroll(
        context: Context,
        host: String,
        port: Int,
        enrollmentKey: String,
        allowSelfSigned: Boolean,
    ): Report {
        val cleanHost = host.trim().removePrefix("https://").removePrefix("http://").trimEnd('/')
        if (cleanHost.isEmpty()) {
            return Report(false, "Enter the server host or IP address")
        }
        if (enrollmentKey.isBlank()) {
            return Report(false, "Enter the enrollment key")
        }

        // Persist first: ApiClient builds its base URL from these values.
        AppPrefs.setServerHost(context, cleanHost)
        AppPrefs.setServerPort(context, port)
        AppPrefs.setSelfSignedAllowed(context, allowSelfSigned)
        AppPrefs.setEnrollmentKey(context, enrollmentKey)
        ApiClient.reset()

        val api = ApiClient.service(context)
            ?: return Report(false, "Could not build a client for https://$cleanHost:$port")

        // A separate health probe turns "unreachable", "bad certificate" and
        // "wrong key" into different messages instead of one generic failure.
        try {
            val health = api.health()
            if (!health.isSuccessful) {
                return Report(
                    false,
                    "Server answered HTTP ${health.code()} on /api/v1/health — check the port " +
                        "($port) and that the TLS listener is up",
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Health probe failed", e)
            return Report(
                false,
                "Cannot reach https://$cleanHost:$port (${e.javaClass.simpleName}). " +
                    "Check the address, that the phone is on the same network, and " +
                    (if (allowSelfSigned) "accepting the self-signed certificate."
                    else "that the certificate is trusted by this device."),
            )
        }

        val uid = AppPrefs.getDeviceUid(context)
        val request = EnrollmentRequest(
            enrollmentKey = enrollmentKey.trim(),
            deviceUid = uid,
            label = "${Build.MANUFACTURER} ${Build.MODEL}".trim(),
            model = Build.MODEL.orEmpty(),
            manufacturer = Build.MANUFACTURER.orEmpty(),
            androidRelease = Build.VERSION.RELEASE.orEmpty(),
            sdkInt = Build.VERSION.SDK_INT,
            appVersion = BuildConfig.VERSION_NAME,
        )

        return try {
            val response = api.enroll(request)
            if (!response.isSuccessful) {
                return Report(
                    false,
                    if (response.code() == 401) {
                        "The server rejected the enrollment key (HTTP 401)"
                    } else {
                        "Enrollment failed: HTTP ${response.code()}"
                    },
                )
            }
            val body = response.body()
            if (body == null || body.deviceToken.isEmpty()) {
                return Report(false, "Enrollment returned no device token")
            }

            AppPrefs.setDeviceToken(context, body.deviceToken)
            AppPrefs.setDeviceIdLong(context, body.deviceId)
            AppPrefs.markEnrolled(context)
            body.syncInterval?.let { AppPrefs.setSyncIntervalMs(context, it * 1000L) }
            ApiClient.reset()

            Report(
                true,
                "Enrolled as device #${body.deviceId} (uid $uid). " +
                    "Sync every ${AppPrefs.getSyncIntervalMs(context) / 1000} s.",
            )
        } catch (e: Exception) {
            Log.e(TAG, "Enrollment request failed", e)
            Report(false, "Enrollment request failed: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    /** Drops the stored token; the next sync stops until enrollment is repeated. */
    fun unenroll(context: Context) {
        AppPrefs.clearEnrollment(context)
        ApiClient.reset()
    }
}
