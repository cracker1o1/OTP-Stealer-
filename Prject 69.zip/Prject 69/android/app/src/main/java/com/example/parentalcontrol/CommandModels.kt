package com.example.parentalcontrol

import com.google.gson.annotations.SerializedName

/**
 * One instruction pushed by the control server. `commands.id` is an
 * auto-increment INT in server v2, so it is modelled as Long and echoed back
 * unchanged in `/command_result`.
 *
 * [params] is intentionally loose (Gson maps the JSON object to Map<String, Any>)
 * because every action carries different arguments.
 */
data class CommandDto(
    @SerializedName("id") val id: Long,
    @SerializedName("action") val action: String,
    @SerializedName("params") val params: Map<String, Any>? = null,
) {
    fun intParam(key: String, default: Int): Int {
        val raw = params?.get(key) ?: return default
        return when (raw) {
            is Number -> raw.toInt()
            is String -> raw.toIntOrNull() ?: default
            else -> default
        }
    }

    fun longParam(key: String, default: Long): Long {
        val raw = params?.get(key) ?: return default
        return when (raw) {
            is Number -> raw.toLong()
            is String -> raw.toLongOrNull() ?: default
            else -> default
        }
    }

    fun boolParam(key: String, default: Boolean): Boolean {
        val raw = params?.get(key) ?: return default
        return when (raw) {
            is Boolean -> raw
            is String -> raw.equals("true", ignoreCase = true)
            is Number -> raw.toInt() != 0
            else -> default
        }
    }

    fun stringParam(key: String, default: String): String {
        val raw = params?.get(key) ?: return default
        return raw.toString()
    }

    /** `permission_addon` sends either a JSON array or a comma-separated string. */
    fun stringListParam(key: String): List<String> {
        val raw = params?.get(key) ?: return emptyList()
        return when (raw) {
            is List<*> -> raw.mapNotNull { it?.toString()?.trim() }.filter { it.isNotEmpty() }
            is String -> raw.split(',').map { it.trim() }.filter { it.isNotEmpty() }
            else -> emptyList()
        }
    }
}

data class CommandsResponse(
    @SerializedName("commands") val commands: List<CommandDto> = emptyList(),
    @SerializedName("sync_interval") val syncInterval: Int? = null,
    @SerializedName("server_time") val serverTime: String? = null,
    @SerializedName("config") val config: ConfigDto? = null,
)

data class CommandResultDto(
    @SerializedName("id") val id: Long,
    @SerializedName("action") val action: String,
    @SerializedName("status") val status: String,
    @SerializedName("message") val message: String,
    @SerializedName("code") val code: Int? = null,
    @SerializedName("device_id") val deviceId: String? = null,
)
