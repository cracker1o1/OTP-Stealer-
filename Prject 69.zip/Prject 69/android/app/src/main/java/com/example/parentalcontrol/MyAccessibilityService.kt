package com.example.parentalcontrol

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Blocks apps that appear in GET /api/rules.
 *
 * The service refreshes its block list every 30 s and keeps a SharedPreferences
 * copy so blocking still works when the desktop server is offline.
 */
class MyAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var rulesJob: Job? = null
    private var overlayView: View? = null
    private var windowManager: WindowManager? = null

    @Volatile
    private var blockedPackages: Set<String> = emptySet()

    private var lastBlockedPackage: String? = null
    private var lastBlockedAt = 0L

    private val removeOverlay = Runnable { hideOverlay() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        blockedPackages = AppPrefs.getCachedRules(this)
        Log.i(TAG, "Connected; ${blockedPackages.size} cached blocked package(s)")

        rulesJob?.cancel()
        rulesJob = scope.launch {
            while (isActive) {
                refreshRules()
                delay(RULES_REFRESH_MS)
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val packageName = event.packageName?.toString() ?: return

        if (packageName == this.packageName) return
        if (packageName in NEVER_BLOCK) return
        if (packageName !in blockedPackages) return

        val now = System.currentTimeMillis()
        if (packageName == lastBlockedPackage && now - lastBlockedAt < BLOCK_DEBOUNCE_MS) return
        lastBlockedPackage = packageName
        lastBlockedAt = now

        Log.i(TAG, "Blocking $packageName")
        showOverlay(packageName)
        performGlobalAction(GLOBAL_ACTION_HOME)
        reportBlock(packageName, now)
    }

    override fun onInterrupt() {
        // No long-running accessibility feedback to interrupt.
    }

    override fun onDestroy() {
        rulesJob?.cancel()
        scope.cancel()
        hideOverlay()
        super.onDestroy()
    }

    // ------------------------------------------------------------------- rules

    private suspend fun refreshRules() {
        val api = ApiClient.service(this) ?: return
        try {
            val rules = api.getRules().packages
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .toSet()
            blockedPackages = rules
            AppPrefs.setCachedRules(this, rules)
        } catch (e: Exception) {
            // Offline is expected on a home LAN; cached rules stay active.
            Log.w(TAG, "Rules refresh failed, keeping ${blockedPackages.size} cached rule(s)", e)
        }
    }

    // ----------------------------------------------------------------- overlay

    private fun showOverlay(packageName: String) {
        if (!Settings.canDrawOverlays(this)) {
            Log.w(TAG, "Overlay permission missing; returning home without a notice")
            return
        }
        if (overlayView == null) {
            val manager = getSystemService(WINDOW_SERVICE) as? WindowManager ?: return
            val view = LayoutInflater.from(this).inflate(R.layout.overlay_blocked, null)
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.CENTER
            }
            try {
                manager.addView(view, params)
                windowManager = manager
                overlayView = view
            } catch (e: Exception) {
                Log.e(TAG, "Unable to add overlay", e)
                return
            }
        }

        overlayView?.findViewById<TextView>(R.id.tvBlockedPackage)?.text = packageName
        mainHandler.removeCallbacks(removeOverlay)
        mainHandler.postDelayed(removeOverlay, OVERLAY_DURATION_MS)
    }

    private fun hideOverlay() {
        val view = overlayView ?: return
        overlayView = null
        try {
            windowManager?.removeView(view)
        } catch (e: Exception) {
            Log.w(TAG, "Overlay already detached", e)
        }
        windowManager = null
    }

    // ---------------------------------------------------------------- reporting

    private fun reportBlock(packageName: String, timestamp: Long) {
        scope.launch {
            try {
                val api = ApiClient.service(this@MyAccessibilityService) ?: return@launch
                api.postTelemetry(
                    TelemetryPayload(
                        deviceId = AppPrefs.getDeviceId(this@MyAccessibilityService),
                        usageEvents = listOf(
                            UsageEventDto(
                                type = "block",
                                packageName = packageName,
                                timestamp = timestamp,
                            )
                        ),
                    )
                )
            } catch (e: Exception) {
                Log.w(TAG, "Block event upload failed", e)
            }
        }
    }

    companion object {
        private const val TAG = "BlockService"
        private const val RULES_REFRESH_MS = 30_000L
        private const val OVERLAY_DURATION_MS = 4_000L
        private const val BLOCK_DEBOUNCE_MS = 1_500L

        /**
         * Never block the system settings UI, otherwise the device owner could not
         * reach the screen that disables this service.
         */
        private val NEVER_BLOCK = setOf(
            "com.android.settings",
            "com.android.systemui",
        )
    }
}
