package com.example.parentalcontrol

import android.content.ClipboardManager
import android.content.Context
import android.util.Log

/**
 * Reads the primary clipboard.
 *
 * Android 10 (API 29) restricted clipboard reads to the app that currently holds
 * focus (plus the default IME), so a background read returns null on most modern
 * devices. Rather than pretend otherwise, [read] reports whether the platform
 * refused the read and the caller surfaces that to the server:
 *
 *  - `ReadResult.Unavailable` — the platform refused (API 29+, app not focused).
 *  - `ReadResult.Empty`       — the read succeeded and the clipboard is empty.
 *  - `ReadResult.Text(...)`   — content captured.
 *
 * The reader is invoked from the sync service and also, when it is enabled, from
 * the accessibility service process, which holds focus events and therefore
 * succeeds more often.
 */
object ClipboardHelper {

    private const val TAG = "ClipboardHelper"

    sealed class ReadResult {
        data class Text(val content: String) : ReadResult()
        object Empty : ReadResult()
        data class Unavailable(val reason: String) : ReadResult()
    }

    @Suppress("DEPRECATION")
    fun read(context: Context): ReadResult {
        val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            ?: return ReadResult.Unavailable("clipboard service not present")

        return try {
            // hasPrimaryClip() is the call that throws SecurityException on API 29+
            // when the app is not focused; the primaryClip getter returns null.
            if (!manager.hasPrimaryClip()) return ReadResult.Empty
            val clip = manager.primaryClip ?: return ReadResult.Empty
            if (clip.itemCount == 0) return ReadResult.Empty
            val text = clip.getItemAt(0).coerceToText(context)?.toString().orEmpty()
            if (text.isEmpty()) ReadResult.Empty else ReadResult.Text(text)
        } catch (e: SecurityException) {
            Log.i(TAG, "Clipboard read refused by the platform: ${e.message}")
            ReadResult.Unavailable("requires app focus (Android 10+ clipboard restriction)")
        } catch (e: Exception) {
            Log.w(TAG, "Clipboard read failed", e)
            ReadResult.Unavailable(e.javaClass.simpleName)
        }
    }

    fun canRead(context: Context): Boolean = read(context) !is ReadResult.Unavailable
}
