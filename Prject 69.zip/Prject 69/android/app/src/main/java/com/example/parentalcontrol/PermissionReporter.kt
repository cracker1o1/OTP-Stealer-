package com.example.parentalcontrol

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat

/**
 * Builds the `permissions` array of a telemetry payload so the dashboard can show
 * what the device has actually granted without polling it.
 *
 * Runtime permissions are reported by their platform name. Capabilities that are
 * not runtime permissions (special app access, accessibility, device admin) have
 * no single permission string, so they are reported under a reserved
 * `special:<capability>` name. The server stores them as opaque strings.
 */
object PermissionReporter {

    const val SPECIAL_OVERLAY = "special:overlay"
    const val SPECIAL_USAGE_ACCESS = "special:usage_access"
    const val SPECIAL_ACCESSIBILITY = "special:accessibility"
    const val SPECIAL_DEVICE_ADMIN = "special:device_admin"
    const val SPECIAL_BATTERY_UNRESTRICTED = "special:battery_unrestricted"
    const val SPECIAL_LAUNCHER_HIDDEN = "special:launcher_hidden"
    const val SPECIAL_WRITE_SECURE_SETTINGS = "special:write_secure_settings"
    const val SPECIAL_NOTIFICATION_ACCESS = "special:notification_access"

    private val runtimePermissions: List<String> = buildList {
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
        add(Manifest.permission.READ_SMS)
        add(Manifest.permission.RECEIVE_SMS)
        add(Manifest.permission.READ_CALL_LOG)
        add(Manifest.permission.READ_CONTACTS)
        add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.READ_PHONE_NUMBERS)
        add(Manifest.permission.CAMERA)
        add(Manifest.permission.RECORD_AUDIO)
    }

    /** Special capabilities the operator may ask for with `permission_addon`. */
    private val specialCapabilities = listOf(
        SPECIAL_OVERLAY,
        SPECIAL_USAGE_ACCESS,
        SPECIAL_ACCESSIBILITY,
        SPECIAL_DEVICE_ADMIN,
        SPECIAL_BATTERY_UNRESTRICTED,
        SPECIAL_NOTIFICATION_ACCESS,
    )

    fun snapshot(context: Context): List<PermissionDto> {
        val items = ArrayList<PermissionDto>(runtimePermissions.size + specialCapabilities.size + 2)
        for (name in runtimePermissions) {
            items.add(PermissionDto(name, isGranted(context, name)))
        }
        for (name in specialCapabilities) {
            items.add(PermissionDto(name, isSpecialGranted(context, name)))
        }
        items.add(PermissionDto(SPECIAL_LAUNCHER_HIDDEN, AppPrefs.isLauncherHidden(context)))
        items.add(
            PermissionDto(
                SPECIAL_WRITE_SECURE_SETTINGS,
                isGranted(context, Manifest.permission.WRITE_SECURE_SETTINGS),
            )
        )
        return items
    }

    /** Everything the operator can name in `permission_addon`. */
    fun requestableNames(): List<String> = runtimePermissions + specialCapabilities

    fun isSpecial(name: String): Boolean = name.startsWith("special:")

    fun isGranted(context: Context, permission: String): Boolean = try {
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    } catch (e: Exception) {
        false
    }

    fun isSpecialGranted(context: Context, name: String): Boolean = when (name) {
        SPECIAL_OVERLAY -> Settings.canDrawOverlays(context)
        SPECIAL_USAGE_ACCESS -> Helpers.hasUsageAccess(context)
        SPECIAL_ACCESSIBILITY -> Helpers.isAccessibilityServiceEnabled(context)
        SPECIAL_DEVICE_ADMIN -> isDeviceAdmin(context)
        SPECIAL_BATTERY_UNRESTRICTED -> isIgnoringBatteryOptimizations(context)
        SPECIAL_NOTIFICATION_ACCESS -> isNotificationListenerEnabled(context)
        else -> false
    }

    /**
     * True when this app is an active device administrator. Device admin grants
     * lock-now and password policy; it does not grant access to user data.
     */
    fun isDeviceAdmin(context: Context): Boolean {
        val manager = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            ?: return false
        return try {
            manager.isAdminActive(ComponentName(context, AdminReceiver::class.java))
        } catch (e: Exception) {
            false
        }
    }

    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        val manager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
        return try {
            manager.isIgnoringBatteryOptimizations(context.packageName)
        } catch (e: Exception) {
            false
        }
    }

    /** Notification access is opt-in and only relevant to companion tooling. */
    fun isNotificationListenerEnabled(context: Context): Boolean = try {
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners",
        ).orEmpty()
        enabled.contains(context.packageName)
    } catch (e: Exception) {
        false
    }
}
