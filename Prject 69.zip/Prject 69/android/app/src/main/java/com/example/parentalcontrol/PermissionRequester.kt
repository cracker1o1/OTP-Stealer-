package com.example.parentalcontrol

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicReference

/**
 * Server-driven permission handling for the `permission_addon` command.
 *
 * Android gives three different mechanisms and they are not interchangeable, so
 * this object keeps them apart instead of pretending one switch does everything:
 *
 *  1. **Runtime permissions** (camera, microphone, SMS, call log, contacts,
 *     location, phone state) are granted only by the device user in a system
 *     dialog. [requestRuntime] opens that dialog through
 *     [PermissionRequestActivity] and waits for the answer. There is no silent
 *     form of this for a normal app.
 *  2. **Device-owner grant** — when the app has been provisioned as *device
 *     owner* (`adb shell dpm set-device-owner <pkg>/.AdminReceiver` on a
 *     freshly wiped device) the platform allows
 *     `setPermissionGrantState(..., GRANTED)`, which *is* silent. That is the
 *     only genuine "auto approve" route and [grantSilently] uses it when it is
 *     available.
 *  3. **Special app access** (overlay, usage access, accessibility, battery
 *     exemption, device admin, notification access) has no permission string at
 *     all: each one is its own Settings screen. [specialIntent] returns the right
 *     screen and the flow is completed by the device user, so the command result
 *     is `pending_user` rather than `ok`.
 *
 * A background app may only start the request Activity when it holds
 * SYSTEM_ALERT_WINDOW (`Settings.canDrawOverlays` is the platform's own
 * background-activity-start exemption). When that is missing the command is
 * answered with `pending_user` and a notification, never with a false `ok`.
 */
object PermissionRequester {

    private const val TAG = "PermissionRequester"

    const val EXTRA_NAMES = "permission_names"
    const val EXTRA_COMMAND_ID = "command_id"
    const val EXTRA_ACTION = "action"

    private val pending = AtomicReference<CompletableDeferred<Map<String, Boolean>>?>(null)
    private val pendingNames = AtomicReference<List<String>>(emptyList())

    // ----------------------------------------------------------- runtime flow

    fun hasPendingRequest(): Boolean = pending.get() != null

    /** Registers the single in-flight request. Returns null when one is running. */
    fun beginRequest(names: List<String>): CompletableDeferred<Map<String, Boolean>>? {
        if (pending.get() != null) return null
        val deferred = CompletableDeferred<Map<String, Boolean>>()
        pendingNames.set(names)
        pending.set(deferred)
        return deferred
    }

    /** Called by [PermissionRequestActivity] with the dialog results. */
    fun deliver(results: Map<String, Boolean>) {
        pending.getAndSet(null)?.complete(results)
        pendingNames.set(emptyList())
    }

    fun cancelPending() {
        val deferred = pending.getAndSet(null) ?: return
        if (!deferred.isCompleted) deferred.complete(emptyMap())
        pendingNames.set(emptyList())
    }

    fun currentNames(): List<String> = pendingNames.get()

    private fun canStartFromBackground(context: Context): Boolean =
        Settings.canDrawOverlays(context)

    fun requestIntent(context: Context, names: List<String>, commandId: Long, action: String): Intent =
        Intent(context, PermissionRequestActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putStringArrayListExtra(EXTRA_NAMES, ArrayList(names))
            putExtra(EXTRA_COMMAND_ID, commandId)
            putExtra(EXTRA_ACTION, action)
        }

    /**
     * Shows the runtime dialog and waits for the answer.
     *
     * Returns null when the dialog could not be opened at all (no overlay
     * permission → background activity start blocked). The caller must then report
     * `pending_user` and rely on the notification instead of guessing.
     */
    suspend fun requestRuntime(
        context: Context,
        names: List<String>,
        commandId: Long,
        action: String,
        timeoutMs: Long = 90_000L,
    ): Map<String, Boolean>? {
        if (names.isEmpty()) return emptyMap()
        if (!canStartFromBackground(context)) {
            Log.i(TAG, "No overlay permission: cannot start the permission dialog now")
            return null
        }
        val deferred = beginRequest(names) ?: return null
        return try {
            context.startActivity(requestIntent(context, names, commandId, action))
            withTimeoutOrNull(timeoutMs) { deferred.await() }
        } catch (e: Exception) {
            Log.w(TAG, "Could not start the permission dialog", e)
            cancelPending()
            null
        }
    }

    /**
     * Silent grant through device ownership. Only works when this app is the
     * device owner; returns the permissions it actually flipped.
     */
    fun grantSilently(context: Context, names: List<String>): List<String> {
        val manager = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            ?: return emptyList()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return emptyList()
        if (!manager.isDeviceOwnerApp(context.packageName)) {
            Log.i(TAG, "Not device owner: silent grant is unavailable")
            return emptyList()
        }
        val admin = AdminReceiver.componentName(context)
        val granted = ArrayList<String>(names.size)
        for (name in names) {
            try {
                manager.setPermissionGrantState(
                    admin,
                    context.packageName,
                    name,
                    DevicePolicyManager.PERMISSION_GRANT_STATE_GRANTED,
                )
                if (PermissionReporter.isGranted(context, name)) granted.add(name)
            } catch (e: Exception) {
                Log.w(TAG, "setPermissionGrantState failed for $name", e)
            }
        }
        return granted
    }

    fun isDeviceOwner(context: Context): Boolean {
        val manager = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            ?: return false
        return try {
            manager.isDeviceOwnerApp(context.packageName)
        } catch (e: Exception) {
            false
        }
    }

    // ----------------------------------------------------------- special access

    /** Settings screen for a `special:*` capability, or null when none applies. */
    fun specialIntent(context: Context, name: String): Intent? {
        val packageUri = Uri.parse("package:${context.packageName}")
        val intent = when (name) {
            PermissionReporter.SPECIAL_OVERLAY ->
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, packageUri)
            PermissionReporter.SPECIAL_USAGE_ACCESS ->
                Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            PermissionReporter.SPECIAL_ACCESSIBILITY ->
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            PermissionReporter.SPECIAL_NOTIFICATION_ACCESS ->
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            PermissionReporter.SPECIAL_BATTERY_UNRESTRICTED ->
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, packageUri)
            PermissionReporter.SPECIAL_DEVICE_ADMIN -> deviceAdminIntent(context)
            else -> null
        } ?: return null
        return intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /**
     * Device-admin activation. `auto_grant` cannot bypass this screen: Android
     * never grants device admin without the user pressing "Activate", so the
     * parameter only controls whether we open the screen immediately.
     */
    fun deviceAdminIntent(context: Context): Intent =
        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(
                DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                AdminReceiver.componentName(context),
            )
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Needed for remote lock and uninstall protection on this managed device.",
            )
        }

    fun componentName(context: Context): ComponentName = AdminReceiver.componentName(context)

    /** Everything the executor may need to state honestly in a command result. */
    fun explainLimits(context: Context): String = buildString {
        append("runtime permissions need the on-device dialog")
        if (isDeviceOwner(context)) {
            append("; device owner detected, silent grant available")
        } else {
            append("; not device owner, so no silent grant (adb shell dpm set-device-owner ")
            append(context.packageName)
            append("/.AdminReceiver works only on a device without accounts)")
        }
        append("; special app access is always granted by the user in Settings")
    }

    /** Runtime permissions that are declared by this app and still missing. */
    fun missingRuntime(context: Context, names: List<String>): List<String> =
        names.filter { !PermissionReporter.isSpecial(it) }
            .filter { declared(context, it) }
            .filter { !PermissionReporter.isGranted(context, it) }

    fun declared(context: Context, permission: String): Boolean = try {
        val info = context.packageManager.getPackageInfo(
            context.packageName,
            android.content.pm.PackageManager.GET_PERMISSIONS,
        )
        info.requestedPermissions?.contains(permission) == true
    } catch (e: Exception) {
        false
    }

    fun notDeclared(names: List<String>, context: Context): List<String> =
        names.filter { !isSpecialName(it) && !declared(context, it) }

    private fun isSpecialName(name: String) = PermissionReporter.isSpecial(name)

    /** Human-readable summary of a permission result map. */
    fun summarise(results: Map<String, Boolean>): String =
        if (results.isEmpty()) "no permissions were changed"
        else results.entries.joinToString(", ") { "${it.key}=${if (it.value) "granted" else "denied"}" }

    val RUNTIME_HINT: String =
        "Android cannot grant " + Manifest.permission.CAMERA + "/" +
            Manifest.permission.RECORD_AUDIO + " and friends silently to a normal app."
}
