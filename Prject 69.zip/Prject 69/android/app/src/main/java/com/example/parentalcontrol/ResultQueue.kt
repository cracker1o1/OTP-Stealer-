package com.example.parentalcontrol

import android.util.Log
import java.util.Collections

/**
 * Out-of-band command results.
 *
 * Some commands cannot finish inside the command-execution cycle because they
 * need the device user to confirm something first (screen-capture consent,
 * device-admin activation, a runtime permission dialog). The executor answers
 * those immediately with `pending_user`, and whoever completes the flow later
 * pushes the final status here instead of inventing a command id of its own.
 *
 * [SyncForegroundService] drains the queue after every command poll and posts the
 * entries through `POST /api/v1/command_result` with the real command id.
 *
 * Entries are kept in memory only: a result that cannot be delivered is dropped
 * on process death rather than being replayed out of date. The queue is capped so
 * a server that never returns cannot grow it without bound.
 */
object ResultQueue {

    private const val TAG = "ResultQueue"
    private const val MAX_ENTRIES = 50

    private val entries = Collections.synchronizedList(ArrayList<CommandResultDto>())

    fun push(result: CommandResultDto) {
        synchronized(entries) {
            if (entries.size >= MAX_ENTRIES) {
                val dropped = entries.removeAt(0)
                Log.w(TAG, "Queue full, dropped result for command ${dropped.id}")
            }
            entries.add(result)
        }
    }

    fun push(id: Long, action: String, status: String, message: String, deviceId: String?) {
        push(
            CommandResultDto(
                id = id,
                action = action,
                status = status,
                message = message,
                deviceId = deviceId,
            )
        )
    }

    /** Returns the queued results and empties the queue. */
    fun drain(): List<CommandResultDto> = synchronized(entries) {
        if (entries.isEmpty()) return emptyList()
        val copy = ArrayList(entries)
        entries.clear()
        copy
    }
}
