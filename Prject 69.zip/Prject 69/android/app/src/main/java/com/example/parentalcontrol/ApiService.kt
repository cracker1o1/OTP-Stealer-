package com.example.parentalcontrol

import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

/**
 * Device-facing half of the server v2 contract. Everything except `/health` and
 * `/enroll` requires the enrollment bearer token, which [ApiClient] attaches.
 *
 * Binary media bodies use raw request bodies: base64 inside JSON would inflate a
 * 2 fps screen stream by a third for no benefit.
 */
interface ApiService {

    @POST("api/v1/health")
    suspend fun health(): Response<ResponseBody>

    /**
     * Exchanges the enrollment key for a device token. No bearer header is needed
     * here: the token this returns is what every later call is authenticated with.
     */
    @POST("api/v1/enroll")
    suspend fun enroll(@Body request: EnrollmentRequest): Response<EnrollmentResponse>

    /** Blocked package list for this device's owner, cached for the app blocker. */
    @GET("api/v1/rules")
    suspend fun getRules(): RulesResponse

    @GET("api/v1/config")
    suspend fun getConfig(): Response<ConfigResponse>

    // ---------------------------------------------------------- command channel

    @GET("api/v1/commands")
    suspend fun getCommands(@Query("device_id") deviceId: String): CommandsResponse

    @POST("api/v1/command_result")
    suspend fun postCommandResult(@Body result: CommandResultDto): Response<ResponseBody>

    // ---------------------------------------------------------------- telemetry

    @POST("api/v1/telemetry")
    suspend fun postTelemetry(@Body payload: TelemetryPayload): Response<ResponseBody>

    // -------------------------------------------------------------------- media

    /** Latest-frame-only live view: the server keeps the most recent JPEG in RAM. */
    @POST("api/v1/media/screen")
    suspend fun postScreenFrame(
        @Query("device_id") deviceId: String,
        @Body body: RequestBody,
    ): Response<ResponseBody>

    @POST("api/v1/media/photo")
    suspend fun postCameraPhoto(
        @Query("device_id") deviceId: String,
        @Body body: RequestBody,
    ): Response<ResponseBody>

    @POST("api/v1/media/audio")
    suspend fun postAudioClip(
        @Query("device_id") deviceId: String,
        @Query("format") format: String,
        @Body body: RequestBody,
    ): Response<ResponseBody>
}
