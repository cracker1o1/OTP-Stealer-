package com.example.parentalcontrol

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.util.Log

/**
 * Partial wake lock plus the battery state the dashboard shows.
 *
 * The lock is a PARTIAL_WAKE_LOCK: it keeps the CPU alive so the 60 s sync and
 * the command poll keep running while the screen is off. It deliberately does not
 * hold the screen on, and it is released in onDestroy so a stopped service cannot
 * keep draining the battery.
 */
object WakeLockHelper {

    private const val TAG = "WakeLockHelper"
    private const val LOCK_TAG = "parental-control:sync"

    private var wakeLock: PowerManager.WakeLock? = null

    @Synchronized
    fun acquire(context: Context): Boolean {
        if (wakeLock?.isHeld == true) return true
        val manager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
        return try {
            val lock = manager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, LOCK_TAG).apply {
                setReferenceCounted(false)
            }
            lock.acquire()
            wakeLock = lock
            AppPrefs.setWakeLockEnabled(context, true)
            Log.i(TAG, "Partial wake lock acquired")
            true
        } catch (e: Exception) {
            Log.w(TAG, "Could not acquire wake lock", e)
            false
        }
    }

    @Synchronized
    fun release() {
        val lock = wakeLock ?: return
        wakeLock = null
        try {
            if (lock.isHeld) lock.release()
            Log.i(TAG, "Partial wake lock released")
        } catch (e: Exception) {
            Log.w(TAG, "Could not release wake lock", e)
        }
    }

    @Synchronized
    fun isHeld(): Boolean = wakeLock?.isHeld == true

    // ------------------------------------------------------------- battery

    /** Battery percentage, or null when the sticky broadcast is unavailable. */
    fun batteryPercent(context: Context): Int? = try {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        if (level < 0 || scale <= 0) null else (level * 100 / scale)
    } catch (e: Exception) {
        Log.w(TAG, "Battery read failed", e)
        null
    }

    // ------------------------------------------------------------ device info

    fun deviceInfo(): DeviceInfoDto = DeviceInfoDto(
        model = Build.MODEL.orEmpty(),
        manufacturer = Build.MANUFACTURER.orEmpty(),
        androidRelease = Build.VERSION.RELEASE.orEmpty(),
        sdkInt = Build.VERSION.SDK_INT,
    )

    fun canWriteSecureSettings(context: Context): Boolean =
        Helpers.hasPermission(context, Manifest.permission.WRITE_SECURE_SETTINGS)
}
