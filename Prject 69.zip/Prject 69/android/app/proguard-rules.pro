# Retrofit + Gson: keep the generic signatures and the DTO field names.
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.example.parentalcontrol.TelemetryPayload { *; }
-keep class com.example.parentalcontrol.LocationDto { *; }
-keep class com.example.parentalcontrol.SmsDto { *; }
-keep class com.example.parentalcontrol.AppDto { *; }
-keep class com.example.parentalcontrol.UsageEventDto { *; }
-dontwarn okhttp3.**
-dontwarn retrofit2.**
