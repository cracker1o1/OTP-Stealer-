plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.parentalcontrol"
    // Android 17 (API 37). Target 37 so the app runs with the newest platform
    // behaviours; minSdk 26 keeps Android 8.0 (Oreo) as the floor.
    compileSdk = 37

    defaultConfig {
        applicationId = "com.example.parentalcontrol"
        minSdk = 26
        targetSdk = 37
        versionCode = 7
        versionName = "1.6"

        // The device-facing build speaks to one lab server; nothing else is
        // configurable at compile time.
        resourceConfigurations += setOf("en")
    }

    buildFeatures {
        viewBinding = true
        // BuildConfig.VERSION_NAME is sent to the server as `app_version`.
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    // Lab signing key so `assembleRelease` produces a directly installable APK.
    // Replace the keystore and move the credentials out of the repo for real use.
    signingConfigs {
        create("poc") {
            storeFile = rootProject.file("keystore/poc-release.jks")
            storePassword = "PocParental2024"
            keyAlias = "pocrelease"
            keyPassword = "PocParental2024"
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("poc")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    packaging {
        resources.excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*")
    }

    lint {
        // The lab build ships permission-heavy code on purpose; a lint failure
        // must not block `assembleRelease`.
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("com.google.android.material:material:1.12.0")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")

    implementation("com.google.android.gms:play-services-location:21.3.0")
}
