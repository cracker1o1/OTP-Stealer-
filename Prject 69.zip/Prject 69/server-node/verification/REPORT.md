# server-node focused change verification (child worker report)

Host: Windows / MSYS (Git-Bash). Deliverable: `C:/Users/Dell/Desktop/Prject 69/server-node/`
MariaDB: 127.0.0.1:3307 (PID 3404), DB `pc69`, client `/tmp/pc69-db/mariadb/mariadb-11.4.4-winx64/bin/mariadb.exe`
Server: `node src/index.js`, HTTPS 8443, PID 24452 (left running), log `server-node/server_http.log`

## Files changed

### 1. `src/index.js` (lines 23-26)
    -app.set('trust proxy', true);
    +// Numeric hop count (single reverse proxy) instead of `true`:
    +// keeps X-Forwarded-Proto honoured by the TLS gate while avoiding
    +// express-rate-limit ERR_ERL_PERMISSIVE_TRUST_PROXY.
    +app.set('trust proxy', 1);
Nothing else in the file touched.

### 2. `src/routes/device.js` (after the `/config` handler, before `module.exports`)
Added `GET /rules` with `deviceAuth`, same style as `/config`:

    router.get('/rules', deviceAuth, async (req, res) => {
      try {
        const rows = await query(
          'SELECT package FROM app_rules WHERE user_id=? ORDER BY package ASC',
          [req.device.user_id]
        );
        res.json({ packages: rows.map((r) => r.package) });
      } catch (err) {
        console.error('[rules] lookup failed:', err.message);   // contract: always 200
        res.json({ packages: [] });
      }
    });

Design note: the catch branch answers 200 with an empty array to honour the
"Always 200" contract, and logs the failure to the server log. If the parent would
rather surface DB failures, change that branch to `next(err)`.

### 3./4. `src/routes/device.js` POST /telemetry
No change required. Already correct on inspection and proved at runtime.

## Exact commands run (abridged) and trimmed output

    node --check src/index.js            -> index.js OK
    node --check src/routes/device.js    -> device.js OK
    taskkill /PID 13644 /F               -> SUCCESS: PID 13644 terminated (old server)
    powershell -NoProfile -Command "Start-Process -FilePath 'cmd.exe' \
      -ArgumentList '/c','node src/index.js > server_http.log 2>&1' \
      -WorkingDirectory 'C:\Users\Dell\Desktop\Prject 69\server-node' -WindowStyle Hidden"
    -> node.exe PID 24452 LISTENING 0.0.0.0:8443

    curl -sk -X POST https://127.0.0.1:8443/api/v1/health
    -> HTTP 200 {"status":"ok","time":"2026-10-21T07:19:23.151Z","version":"2.0"}

    # enroll (ENROLLMENT_KEY read from .env via $ENROLLMENT_KEY, value never printed/echoed)
    curl -sk -X POST --data-urlencode "enrollment_key=$KEY" \
      --data-urlencode "device_uid=throwaway-rules-1792567180" \
      --data-urlencode "label=throwaway-verify" ... https://127.0.0.1:8443/api/v1/enroll
    -> HTTP 200 {"device_id":3,"device_token":"<redacted>","user_id":1,
                 "sync_interval":60,"server_time":"..."}   (token_len=64)

    # auth mechanism check: deviceAuth resolves the device by uid, token is only the credential
    curl -sk -H "Authorization: Bearer $TOKEN" https://127.0.0.1:8443/api/v1/rules
    -> HTTP 401 {"error":"device_id required"}      # same as /config and /commands
    curl -sk -H "Authorization: Bearer $TOKEN" \
      "https://127.0.0.1:8443/api/v1/rules?device_id=throwaway-rules-1792567180"
    -> HTTP 200 {"packages":[]}                      # empty array case
    # insert temp rule for the owner user, then re-check filtering
    mariadb -h 127.0.0.1 -P 3307 -u $DB_USER pc69 -e \
      "INSERT INTO app_rules (user_id,package) VALUES (1,'com.example.blocked') ON DUPLICATE KEY UPDATE package=VALUES(package);"
    -> user_id 1 | com.example.blocked
    curl -sk -H "Authorization: Bearer $TOKEN" \
      "https://127.0.0.1:8443/api/v1/rules?device_id=throwaway-rules-1792567180"
    -> HTTP 200 {"packages":["com.example.blocked"]}
    curl -sk -H "Authorization: Bearer deadbeef" \
      "https://127.0.0.1:8443/api/v1/rules?device_id=throwaway-rules-1792567180"
    -> HTTP 401 {"error":"invalid device token"}

    # telemetry POST 1 (battery/hidden/admin_active + permissions + installed_apps + location)
    curl -sk -X POST -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
      -d '{"device_id":"...","app_version":"2.1","battery":42,"hidden":true,"admin_active":true,
           "permissions":[{"name":"android.permission.CAMERA","granted":true},
                          {"name":"android.permission.RECORD_AUDIO","granted":false}],
           "installed_apps":[{"package":"com.example.throwaway","label":"Throwaway","version_name":"1.0"}],
           "location":{"lat":1.5,"lon":2.5,"accuracy":3,"timestamp":1700000000}}' \
      https://127.0.0.1:8443/api/v1/telemetry
    -> HTTP 200 {"status":"ok","stored":{"sms":0,"calls":0,"contacts":0,"clipboard":0,
                 "apps":1,"usage":0,"permissions":2,"location":true}}   (keys unchanged)
    # telemetry POST 2: battery only
    -> HTTP 200 {"status":"ok","stored":{...,"apps":0,...,"permissions":0,"location":false}}

    SELECT id,device_uid,battery,hidden,admin_active,is_online,app_version FROM devices ...
    -> id:3 battery:7 hidden:1 admin_active:1 is_online:1 app_version:2.1
       (battery 42 -> 7 on POST 2; hidden/admin_active kept their POST-1 values = selective update OK)

    perms | apps | locs
    2     | 1    | 1
    device_permissions: CAMERA=1, RECORD_AUDIO=0
    installed_apps: com.example.throwaway | Throwaway | 1.0
    locations: 1.5 | 2.5 | 3 | 1700000000

    # repeat POST with same permissions (CAMERA->false), same app, new location
    -> permissions rows still 2, CAMERA granted 1 -> 0 (upsert, not duplicate)
    -> installed_apps still 1 row, label/version updated (Throwaway2 / 2.0)

    # TLS gate still honours X-Forwarded-Proto (throwaway instance, port 8446, REQUIRE_TLS=true,
    # cert paths overridden to a non-existent file => plain HTTP mode; killed afterwards)
    curl -s -X POST http://127.0.0.1:8446/api/v1/health
    -> HTTP 403 {"error":"TLS required"}
    curl -s -H "X-Forwarded-Proto: https" -X POST http://127.0.0.1:8446/api/v1/health
    -> HTTP 200 {"status":"ok",...}

    rg -n "ERR_ERL|trust proxy|ValidationError|Warning" server_http.log
    -> no warning lines in server_http.log
    cat server_http.log
    -> pc69 server v2 listening on https://0.0.0.0:8443
       database connection OK

## Findings (honest)

1. Change 3 was already implemented in the current tree: the telemetry handler already
   persisted `battery` (INT->devices.battery), `hidden` and `admin_active` (boolean->TINYINT),
   each guarded by `!== undefined`. Verified end-to-end instead of re-adding code.
2. Change 4: `locations`, `installed_apps` and `device_permissions` all work. No bug in the
   write path. `device_permissions` really upserts (UNIQUE(device_id,permission)); `installed_apps`
   really upserts (UNIQUE(device_id,package)).
3. Observation (not fixed, no code change): `locations` is append-only - the schema has no
   unique key for it, so an identical re-POST with the same lat/lon/ts inserts another row
   (row count 2 -> 4 across repeated identical payloads; server-node/verification/db_location_repeat.txt).
   This is consistent with the schema (`INDEX(device_id,ts)`), but it does not match the SPEC
   verification wording "re-POST identical telemetry proving idempotency (row counts
   unchanged)" if that wording is meant to cover the location section. Flagged for the parent;
   changing it would alter the frozen /telemetry contract, so it was left alone.
4. The first `/rules` attempt returned 401 `{"error":"device_id required"}`: `deviceAuth`
   requires a device identifier (`device_id` query/body or `X-Device-Uid`) in addition to the
   Bearer token. This is the existing mechanism shared with `/config` and `/commands`, not a
   defect in the new handler.
5. `GET /rules`'s catch branch returns 200 `{"packages":[]}` (see design note above); no DB
   failure was induced, so that branch is untested at runtime.

## State left behind

- Server running: node.exe PID 24452, https://0.0.0.0:8443
- MariaDB running: mysqld.exe PID 3404, 127.0.0.1:3307. /tmp/pc69-db untouched.
- DB writes made for verification: device row `throwaway-rules-1792567180` (id 3) with its
  permissions/apps/locations rows, and app_rule `(user_id=1,'com.example.blocked')`.
  Cleanup SQL if unwanted:
    DELETE FROM app_rules WHERE user_id=1 AND package='com.example.blocked';
    DELETE FROM devices WHERE device_uid='throwaway-rules-1792567180';  -- cascades children

## Evidence files

All captures are in `server-node/verification/` (plain-text, credentials redacted; the raw
device token and unredacted enroll response were deleted on purpose):

- `server_http.log` - startup log of the running server (no ERR_ERL warning)
- `enroll_redacted.json` - enroll response with device_token masked
- `rules_empty.json` -> `{"packages":[]}`
- `rules_after.json` -> `{"packages":["com.example.blocked"]}`
- `rules_badtoken.json` -> 401 invalid device token
- `rules_noauth.json` -> 401 device_id required (auth mechanism note)
- `telemetry1.json`, `telemetry2.json`, `telemetry3.json` - POST /telemetry responses
- `db_devices.txt` - devices row (battery/hidden/admin_active)
- `db_children.txt` - device_permissions / installed_apps / locations rows
- `db_after_repeat.txt` - upsert proof after a repeat POST
- `db_location_repeat.txt` - location append-only observation
- `tlsgate_noxfp.json` (403) and `tlsgate_xfp.json` (200) - X-Forwarded-Proto gate proof
- `tlsgate.log` - startup log of the throwaway 8446 instance
- `app_rules_row.txt`, `device_uid.txt`, `user_id.txt`, `notes.txt` - identifiers used

Also kept: `C:/Users/Dell/Desktop/Prject 69/server-node/server_http.log` (live server log).


---

## Addendum - v1.3 per-device SMS cadence (2026-10-21)

Client build: `ParentalControl-v1.3-release.apk` (5,271,066 bytes, SHA-256
`d964baece078f53001a9a120c81b1c9edfb73110837d0506900d957f3c52ff20`, signed with the lab
release keystore `android/keystore/poc-release.jks`; APK Signing Block v2 verified with
`apksigner verify --print-certs`).

### What changed

- `devices.sms_interval_s` column added to the schema (`server-node/src/schema.sql`,
  applied as a migration to the live `pc69` database).
- `set_sms_interval` command action implemented server-side and in the Android command
  dispatcher; the value is persisted per device and returned in the config block of
  `GET /commands` and `GET /devices/:id`.
- Android SMS collection is now gated client-side by `AppPrefs.smsIntervalS` through
  `SyncForegroundService.isSmsSyncDue()` (last-run bookkeeping in `last_sms_sync_at`),
  independent of the 3 s command-polling loop.
- `sms_refresh` forces an immediate collection regardless of the cadence timer.

Cadence defaults: `SYNC_INTERVAL_S=3` (command polling, low latency),
`SMS_INTERVAL_S=60` (SMS collection, server default when the per-device override is unset).

### Smoke test - 56 passed, 0 failed

Full transcript archived at `server-node/verification/smoke-test-v1.3.log`. The eight
assertions added for this change are in section `[7b]`:

- `set_sms_interval` create -> HTTP 200, response value `30`
- device config -> HTTP 200, `config.sms_interval_s = 30`
- `sync_interval` unchanged by the SMS override -> `3`
- `GET /commands` config -> `sms_interval_s = 30`
- reset back to `60` -> HTTP 200, response value `60`
- enroll/commands defaults -> `config.sms_interval_s = 60`

Round-trip is therefore proven server-side: `set_sms_interval` -> persisted device row ->
config delivered to the client -> reset. Live SMS gating on the handset itself
(`isSmsSyncDue()`, `last_sms_sync_at`) is source-verified only and still needs confirmation
on a physical device.
