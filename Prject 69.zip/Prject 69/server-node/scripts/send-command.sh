#!/usr/bin/env bash
# Send a dashboard command to an enrolled device and follow its status to a terminal state.
#
# usage: scripts/send-command.sh <device_id> <action> [params-json]
#   e.g. scripts/send-command.sh 4 mic_start '{"segment_seconds":10,"segments":2}'
#
# Reads ADMIN_EMAIL / ADMIN_PASSWORD / PORT from .env. Accepts the lab's self-signed cert.
set -u
cd "$(dirname "$0")/.." || exit 1

PORT=$(grep '^PORT=' .env | cut -d= -f2-); PORT=${PORT:-8443}
EMAIL=$(grep '^ADMIN_EMAIL=' .env | cut -d= -f2-)
PASS=$(grep '^ADMIN_PASSWORD=' .env | cut -d= -f2-)
BASE="https://127.0.0.1:${PORT}"

DEV="$1"; ACTION="$2"; PARAMS="${3:-{\}}"

TOKEN=$(curl -sk --max-time 10 -X POST "$BASE/auth/login" \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"$EMAIL\",\"password\":\"$PASS\"}" | grep -o '"token":"[^"]*"' | cut -d'"' -f4)
[ -z "$TOKEN" ] && { echo "login failed"; exit 1; }

resp=$(curl -sk --max-time 10 -X POST "$BASE/devices/$DEV/commands" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d "{\"action\":\"$ACTION\",\"params\":$PARAMS,\"ttl_seconds\":180}")
echo "SEND device=$DEV $ACTION $PARAMS -> $resp"
id=$(echo "$resp" | grep -o '"id":[0-9]*' | head -1 | cut -d: -f2)
[ -z "$id" ] && { echo "no command id returned"; exit 1; }

for i in $(seq 1 30); do
  sleep 2
  st=$(curl -sk --max-time 10 "$BASE/devices/$DEV/commands?limit=10" \
    -H "Authorization: Bearer $TOKEN")
  line=$(echo "$st" | tr '{' '\n' | grep -E "\"id\":$id[,}]" | head -1)
  status=$(echo "$line" | grep -o '"status":"[^"]*"' | cut -d'"' -f4)
  echo "  t=$((i * 2))s status=$status"
  case "$status" in
    ok|error|denied|pending_user|expired)
      echo "  result: $line"
      break
      ;;
  esac
done
