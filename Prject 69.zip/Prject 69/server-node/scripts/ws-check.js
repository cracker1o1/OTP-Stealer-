'use strict';

// Verifies the wss:// endpoint: an authenticated node `ws` client must receive a
// `devices` broadcast, and an unauthenticated upgrade must be rejected.
// Usage: node scripts/ws-check.js   (reads BASE_URL / ADMIN_EMAIL / ADMIN_PASSWORD)

const WebSocket = require('ws');

const BASE = process.env.BASE_URL || 'https://127.0.0.1:8443';
const EMAIL = process.env.ADMIN_EMAIL || 'admin@example.com';
const PASSWORD = process.env.ADMIN_PASSWORD || 'ChangeMe123!';

function fail(code, msg) {
  console.error('FAIL: ' + msg);
  process.exit(code);
}

async function getToken() {
  const res = await fetch(BASE + '/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: EMAIL, password: PASSWORD }),
  });
  const j = await res.json();
  if (!j.token) fail(2, 'login did not return a token: ' + JSON.stringify(j));
  return j.token;
}

function checkRejectsWithoutToken() {
  return new Promise((resolve) => {
    const url = BASE.replace(/^http/, 'ws') + '/ws';
    const ws = new WebSocket(url, { rejectUnauthorized: false });
    const timer = setTimeout(() => {
      console.log('  note: no-token socket stayed open (no rejection observed)');
      try { ws.close(); } catch (e) {}
      resolve(false);
    }, 4000);
    ws.on('open', () => {
      clearTimeout(timer);
      try { ws.close(); } catch (e) {}
      resolve(true); // opened == bad
    });
    ws.on('unexpected-response', (req, res) => {
      clearTimeout(timer);
      console.log('  no-token upgrade rejected with HTTP ' + res.statusCode);
      resolve(false);
    });
    ws.on('error', () => {
      clearTimeout(timer);
      resolve(false);
    });
  });
}

async function main() {
  const token = await getToken();
  console.log('token acquired (len ' + token.length + ')');

  console.log('negative check: connect with no token');
  const openedWithoutToken = await checkRejectsWithoutToken();
  if (openedWithoutToken) fail(5, 'unauthenticated WS connection was accepted');
  console.log('  PASS: unauthenticated WS not accepted');

  const url = BASE.replace(/^http/, 'ws') + '/ws?token=' + encodeURIComponent(token);
  const ws = new WebSocket(url, { rejectUnauthorized: false });
  const timer = setTimeout(() => fail(3, 'TIMEOUT waiting for devices message'), 15000);

  ws.on('open', () => console.log('ws open to ' + url.replace(/token=.*/, 'token=<redacted>')));
  ws.on('message', (buf) => {
    let m;
    try {
      m = JSON.parse(buf.toString());
    } catch (e) {
      return;
    }
    if (m.type === 'devices') {
      clearTimeout(timer);
      console.log('received type=devices count=' + m.devices.length);
      if (m.devices.length > 0) {
        console.log('sample device: id=' + m.devices[0].id + ' online=' + m.devices[0].is_online);
      }
      console.log('PASS: wss devices broadcast received');
      ws.terminate();
      // let the socket close cleanly before exiting (avoids a Windows libuv
      // teardown assertion when process.exit races an in-flight close).
      setTimeout(() => process.exit(0), 250);
    } else {
      console.log('  (other message type=' + m.type + ')');
    }
  });
  ws.on('error', (e) => fail(4, 'ws error: ' + e.message));
}

main().catch((e) => fail(1, e.message));
