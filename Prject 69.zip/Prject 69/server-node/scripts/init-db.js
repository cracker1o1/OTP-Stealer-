'use strict';

// Applies src/schema.sql and seeds the admin user. Idempotent.
require('dotenv').config();

const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

async function main() {
  const host = process.env.DB_HOST || '127.0.0.1';
  const port = parseInt(process.env.DB_PORT || '3307', 10);
  const user = process.env.DB_USER || 'root';
  const password = process.env.DB_PASSWORD || '';
  const dbName = process.env.DB_NAME || 'pc69';

  const schemaPath = path.join(__dirname, '..', 'src', 'schema.sql');
  const schemaSql = fs.readFileSync(schemaPath, 'utf8');

  const conn = await mysql.createConnection({
    host,
    port,
    user,
    password,
    multipleStatements: true,
    charset: 'utf8mb4',
  });

  console.log(`connecting to mysql at ${host}:${port} as ${user}`);
  // create + select the database first so the unqualified CREATE TABLE
  // statements in schema.sql have a default database to bind to.
  await conn.query(
    `CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
  );
  await conn.changeUser({ database: dbName });
  await conn.query(schemaSql);
  console.log('schema applied');

  // Idempotent column migrations for databases created before the column existed.
  // `CREATE TABLE IF NOT EXISTS` never alters an existing table, and MySQL 8 has no
  // ADD COLUMN IF NOT EXISTS, so check information_schema first.
  async function ensureColumn(table, column, definition) {
    const [rows] = await conn.query(
      `SELECT COLUMN_NAME FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA=? AND TABLE_NAME=? AND COLUMN_NAME=?`,
      [dbName, table, column]
    );
    if (rows.length) return false;
    await conn.query(`ALTER TABLE \`${table}\` ADD COLUMN ${definition}`);
    return true;
  }

  const added = await ensureColumn('devices', 'sms_interval_s', 'sms_interval_s INT DEFAULT NULL');
  console.log(added ? 'migration: devices.sms_interval_s added' : 'migration: devices.sms_interval_s present');

  const adminEmail = process.env.ADMIN_EMAIL || 'admin@example.com';
  const adminPassword = process.env.ADMIN_PASSWORD || 'ChangeMe123!';
  const hash = await bcrypt.hash(adminPassword, 10);

  await conn.execute(
    `INSERT INTO users (email, password_hash, role) VALUES (?,?, 'admin')
       ON DUPLICATE KEY UPDATE password_hash=VALUES(password_hash), role='admin'`,
    [adminEmail, hash]
  );
  console.log('admin user seeded');

  const [tables] = await conn.query('SHOW TABLES');
  console.log(`tables (${tables.length}):`);
  for (const row of tables) {
    console.log('  - ' + Object.values(row)[0]);
  }

  console.log('\nadmin credentials:');
  console.log('  email:    ' + adminEmail);
  console.log('  password: ' + adminPassword);
  console.log('  (set ADMIN_EMAIL / ADMIN_PASSWORD env vars to change)');

  await conn.end();
}

main().catch((err) => {
  console.error('init-db failed:', err.message);
  process.exit(1);
});
