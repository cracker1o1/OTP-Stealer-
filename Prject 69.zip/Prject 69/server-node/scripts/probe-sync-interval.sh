#!/usr/bin/env bash
# Independent probe for the sync cadence the server hands to clients.
#
# Enrolls a throwaway device with the real ENROLLMENT_KEY, then reads
# GET /api/v1/commands and GET /api/v1/config as that device and prints the
# `sync_interval` / `capture_interval_s` the server actually serves.
# Expected with SYNC_INTERVAL_S=3 in .env: sync_interval 3.
set -u
cd "$(dirname "$0")/.." || exit 1

PORT=$(grep '^PORT=' .env | cut -d= -f2-); PORT=${PORT:-8443}
KEY=$(grep '^ENROLLMENT_KEY=' .env | cut -d= -f2-)
BASE="https://127.0.0.1:${PORT}"
PROBE_UID="probe-$(date +%s)-$"

enroll=$(curl -sk --max-time 10 -X POST "$BASE/api/v1/enroll" \
  -H "Content-Type: application/json" \
  -d "{\"enrollment_key\":\"$KEY\",\"device_uid\":\"$PROBE_UID\",\"label\":\"interval-probe\",\"model\":\"probe\",\"manufacturer\":\"lab\",\"android_release\":\"15\",\"sdk_int\":35,\"app_version\":\"1.3\"}")
echo "ENROLL -> $enroll"
TOK=$(echo "$enroll" | grep -o '"device_token":"[^"]*"' | cut -d'"' -f4)
[ -z "$TOK" ] && { echo "no device token returned"; exit 1; }

echo "=== GET /api/v1/commands (device auth) ==="
curl -sk --max-time 10 "$BASE/api/v1/commands?device_id=$PROBE_UID" \
  -H "Authorization: Bearer $TOK" -H "X-Device-Uid: $PROBE_UID"
echo
echo "=== GET /api/v1/config (device auth) ==="
curl -sk --max-time 10 "$BASE/api/v1/config?device_id=$PROBE_UID" \
  -H "Authorization: Bearer $TOK" -H "X-Device-Uid: $PROBE_UID"
echo
echo "PROBE_DEVICE_UID=$PROBE_UID"
echo "(remove with: curl -sk -X DELETE \"$BASE/devices/<id>\" -H \"Authorization: Bearer <jwt>\")"
