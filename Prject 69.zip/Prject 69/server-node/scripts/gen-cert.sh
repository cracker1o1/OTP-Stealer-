#!/usr/bin/env bash
# Generate a self-signed TLS cert into ./certs (825 days), SAN covers localhost + LAN IPs.
set -euo pipefail

cd "$(dirname "$0")/.."
mkdir -p certs

# Prevent MSYS/Git-Bash from rewriting openssl args like /CN=... into Windows paths.
export MSYS2_ARG_CONV_EXCL='*'
export MSYS_NO_PATHCONV=1

CN="${1:-${CERT_CN:-localhost}}"

# collect candidate IPs: explicit env, plus locally detected addresses
if [ "$CN" = "localhost" ]; then
  SANS="DNS:localhost,IP:127.0.0.1,IP:::1"
else
  SANS="DNS:localhost,DNS:${CN},IP:127.0.0.1,IP:::1"
fi

add_ip() {
  local ip="$1"
  [ -z "$ip" ] && return 0
  case "$SANS" in
    *"IP:${ip}"*) ;;
    *) SANS="${SANS},IP:${ip}" ;;
  esac
}

if [ -n "${CERT_IPS:-}" ]; then
  IFS=',' read -ra _ips <<< "$CERT_IPS"
  for ip in "${_ips[@]}"; do add_ip "$(echo "$ip" | tr -d ' ')"; done
fi

# try a few ways to find LAN IPs (best-effort; ignore failures)
for ip in $(hostname -I 2>/dev/null || true); do add_ip "$ip"; done
if command -v ipconfig >/dev/null 2>&1; then
  for ip in $(ipconfig 2>/dev/null | grep -a -oE '([0-9]{1,3}\.){3}[0-9]{1,3}' | grep -avE '^255\.|^0\.' | sort -u || true); do
    add_ip "$ip"
  done
fi

echo "generating self-signed cert (CN=${CN}, SAN=${SANS})"
rm -f certs/key.pem certs/cert.pem
openssl req -x509 -newkey rsa:2048 -nodes \
  -keyout certs/key.pem -out certs/cert.pem \
  -days 825 -subj "/CN=${CN}" \
  -addext "subjectAltName=${SANS}"

echo "wrote certs/key.pem and certs/cert.pem"
