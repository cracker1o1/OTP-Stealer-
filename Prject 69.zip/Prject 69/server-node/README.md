# Server v2 (pc69) — Node/Express + MySQL

Backend for an **authorized** parental-control / MDM deployment: a companion to an
Android client that enrolls a device and then syncs telemetry and receives commands.
Only use it on devices and users you are authorized to manage.

Stack: Node 24, Express 4, `mysql2` (promise pool), `ws`, `jsonwebtoken`, `bcryptjs`,
`helmet`, `express-rate-limit`, `cors`, `dotenv`, `uuid`. Binary media bodies use
`express.raw` (no multer).

## Layout

```
src/index.js          server bootstrap (TLS, helmet, cors, rate limit, static dashboard)
src/db.js             mysql2 promise pool
src/schema.sql        full MySQL schema (idempotent, InnoDB / utf8mb4)
src/auth.js           device-token hashing, JWT sign/verify
src/middleware.js     TLS gate, device auth, JWT auth, audit
src/ws.js             WebSocket server + devices broadcast
src/config.js         poll + SMS intervals + client config object
src/routes/device.js  /api/v1 device endpoints
src/routes/media.js   /api/v1/media screen/photo/audio
src/routes/admin.js   admin REST API + live frame/file streaming
public/index.html     self-contained dashboard (no build, no CDN)
scripts/gen-cert.sh   self-signed cert into ./certs
scripts/init-db.js    applies schema, seeds admin
scripts/smoke-test.sh end-to-end HTTPS smoke test
```

## Setup

```bash
npm install
cp .env.example .env        # then fill ENROLLMENT_KEY, JWT_SECRET, DB_*, ADMIN_*
node scripts/init-db.js     # creates schema + admin user, prints credentials
bash scripts/gen-cert.sh    # writes certs/key.pem + certs/cert.pem (825 days)
node src/index.js           # https://0.0.0.0:8443
```

Dashboard: open `https://127.0.0.1:8443/` and sign in with the seeded admin.

## Environment

See `.env.example`. Key vars: `PORT`, `PORT_HTTP`, `DB_HOST`, `DB_PORT`, `DB_USER`,
`DB_PASSWORD`, `DB_NAME`, `ENROLLMENT_KEY`, `JWT_SECRET`, `TLS_KEY`, `TLS_CERT`,
`REQUIRE_TLS`, `CORS_ORIGIN`, `STORAGE_DIR`, `SAVE_SCREEN_FRAMES`, `ONLINE_WINDOW_S`,
`SYNC_INTERVAL_S`, `SMS_INTERVAL_S`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`.

- `PORT_HTTP` > 0 starts a plain-HTTP listener that 308-redirects to HTTPS.
- `REQUIRE_TLS=true` rejects non-TLS requests with `403 {"error":"TLS required"}`.
- `ONLINE_WINDOW_S` (default 30) is the window used to compute `is_online`.

### Collection cadences (v1.3)

Two independent cadences, both clamped by `src/config.js`:

| Var | Default | Range | Meaning |
|---|---|---|---|
| `SYNC_INTERVAL_S` | 60 | 3..600 | Command-poll latency: how often the client hits `/commands` and posts telemetry. A lab can drop this to `3` for a near-real-time dashboard. |
| `SMS_INTERVAL_S` | 60 | 3..3600 | SMS inbox re-read cadence. Independent of the poll rate, so a 3 s poll does not turn into a hot inbox query. |

Both are handed to the client as `sync_interval` (top level) and `config.sms_interval_s` on
`/enroll`, `/commands` and `/config`. The client stores them separately and applies the SMS
gate itself; `POST /devices/:id/commands` with `{"action":"sms_refresh"}` raises a one-shot
flag that makes the next cycle read the inbox immediately, and
`{"action":"set_sms_interval","params":{"seconds":30}}` moves the SMS cadence without
touching the command poll interval.

## Device API — base `/api/v1`

Auth: `Authorization: Bearer <device_token>` (sha256 + timing-safe compare against
`device_token_hash`). The device is looked up by `device_uid` supplied in
`device_id` (body/query) or the `X-Device-Uid` header.

| Method | Path | Notes |
|---|---|---|
| POST | `/health` | no auth |
| POST | `/enroll` | enrollment key; mints a new device token |
| GET  | `/commands` | marks online; returns pending+delivered commands |
| POST | `/command_result` | ok/error/pending_user/denied |
| POST | `/telemetry` | one endpoint, every field optional, idempotent |
| POST | `/media/screen` | raw JPEG, latest frame kept in memory |
| POST | `/media/photo` | raw JPEG -> ./storage/photo/<uid>/ |
| POST | `/media/audio` | raw WAV/PCM -> ./storage/audio/<uid>/ |
| GET  | `/config` | sync interval + client config |

## Admin API (JWT)

`POST /auth/login`, `GET /auth/me`, `GET /devices`, `GET/DELETE /devices/:id`,
`GET/POST /devices/:id/commands`, `GET /devices/:id/data/:kind`,
`GET /media/frame/:deviceId`, `GET /media/file/:mediaFileId`,
`GET|POST|DELETE /rules`, `GET /audit`.

## WebSocket

`wss://host/ws?token=<jwt>`. Broadcasts: `devices` (every 5 s), `telemetry`,
`command_result`, `frame`, `command_created`. Devices use HTTP polling only.

## Verification

```bash
npm install
for f in $(find src scripts -name '*.js'); do node --check "$f"; done
node scripts/init-db.js
bash scripts/gen-cert.sh
node src/index.js &          # or in another shell
bash scripts/smoke-test.sh   # requires .env with ENROLLMENT_KEY + ADMIN_*
```

The smoke test covers health, enroll (+ wrong key -> 401, plus the two cadence
fields), empty commands, full telemetry, idempotency, admin login, command round
trip, live frame, photo/audio uploads and the online device list — 48 assertions,
all passing against the local MariaDB on `127.0.0.1:3307` and the self-signed cert.

## Security notes

- Never run with the default `JWT_SECRET` or empty `ENROLLMENT_KEY` in production.
- Use a real CA certificate (replace the self-signed one from `gen-cert.sh`).
- Keep `.env` out of version control.
