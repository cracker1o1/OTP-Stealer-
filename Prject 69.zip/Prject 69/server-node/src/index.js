'use strict';

require('dotenv').config();

const fs = require('fs');
const http = require('http');
const https = require('https');
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const { requireTls } = require('./middleware');
const deviceRouter = require('./routes/device');
const mediaRouter = require('./routes/media');
const adminRouter = require('./routes/admin');
const ws = require('./ws');
const { ping } = require('./db');

const app = express();
app.disable('x-powered-by');
// Numeric hop count (single reverse proxy) instead of `true`:
// keeps X-Forwarded-Proto honoured by the TLS gate while avoiding
// express-rate-limit ERR_ERL_PERMISSIVE_TRUST_PROXY.
app.set('trust proxy', 1);

// --- security middleware ----------------------------------------------------
app.use(
  helmet({
    contentSecurityPolicy: false, // inline dashboard
    crossOriginResourcePolicy: false,
  })
);
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: false }));

// global TLS gate (honours X-Forwarded-Proto via trust proxy)
app.use(requireTls);

// --- rate limiting ----------------------------------------------------------
const generalLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 600,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'too many requests' },
});
app.use(generalLimiter);

const strictLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'too many requests' },
});
app.use('/api/v1/enroll', strictLimiter);
app.use('/auth/login', strictLimiter);

// --- routes -----------------------------------------------------------------
app.use('/api/v1/media', mediaRouter);
app.use('/api/v1', deviceRouter);
app.use('/', adminRouter);

// --- dashboard --------------------------------------------------------------
const publicDir = path.join(__dirname, '..', 'public');
app.use(express.static(publicDir, { index: 'index.html' }));

// --- error handler ----------------------------------------------------------
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  const status = err.status || err.statusCode || 500;
  if (status >= 500) {
    console.error('[error]', err.message);
  }
  res.status(status).json({ error: err.message || 'internal error' });
});

// --- TLS / server bootstrap -------------------------------------------------
function resolveTls() {
  const keyPath = process.env.TLS_KEY || './certs/key.pem';
  const certPath = process.env.TLS_CERT || './certs/cert.pem';
  if (fs.existsSync(keyPath) && fs.existsSync(certPath)) {
    return { key: fs.readFileSync(keyPath), cert: fs.readFileSync(certPath) };
  }
  return null;
}

const PORT = parseInt(process.env.PORT || '8443', 10);
const PORT_HTTP = parseInt(process.env.PORT_HTTP || '0', 10);

const tls = resolveTls();
let server;
let scheme;
if (tls) {
  server = https.createServer(tls, app);
  scheme = 'https';
} else {
  server = http.createServer(app);
  scheme = 'http';
  console.warn('========================================================');
  console.warn(' WARNING: no TLS cert found (certs/key.pem + cert.pem).');
  console.warn(' Running in PLAIN HTTP mode. Do not use in production.');
  console.warn('========================================================');
}

ws.attach(server);

// optional plain-HTTP redirect listener
let redirectServer = null;
if (PORT_HTTP > 0) {
  redirectServer = http.createServer((req, res) => {
    const host = (req.headers.host || 'localhost').split(':')[0];
    const target = `https://${host}:${PORT}${req.url}`;
    res.writeHead(308, { Location: target });
    res.end();
  });
  redirectServer.listen(PORT_HTTP, () => {
    console.log(`HTTP redirect listener on :${PORT_HTTP} -> https://${PORT}`);
  });
}

server.listen(PORT, async () => {
  console.log(`pc69 server v2 listening on ${scheme}://0.0.0.0:${PORT}`);
  try {
    await ping();
    console.log('database connection OK');
  } catch (e) {
    console.error('database connection FAILED:', e.message);
  }
});

function shutdown(signal) {
  console.log(`\nreceived ${signal}, shutting down...`);
  ws.close();
  server.close(() => {
    if (redirectServer) redirectServer.close();
    process.exit(0);
  });
  setTimeout(() => process.exit(0), 3000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

module.exports = app;
