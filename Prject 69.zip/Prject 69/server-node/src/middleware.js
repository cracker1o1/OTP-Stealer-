'use strict';

const { query } = require('./db');
const { verifyDeviceToken, verifyUserToken } = require('./auth');

// --- TLS gate ----------------------------------------------------------------

function requireTls(req, res, next) {
  if (process.env.REQUIRE_TLS === 'true') {
    const proto = req.get('X-Forwarded-Proto');
    const secure = req.secure || proto === 'https';
    if (!secure) {
      return res.status(403).json({ error: 'TLS required' });
    }
  }
  next();
}

function clientIp(req) {
  const xf = req.get('X-Forwarded-For');
  if (xf) return xf.split(',')[0].trim();
  return (req.ip || req.socket.remoteAddress || '').replace(/^::ffff:/, '');
}

// --- device auth -------------------------------------------------------------

// Resolve the device by uid (body device_id / query device_id / X-Device-Uid),
// then verify the Bearer device token against its stored hash.
async function deviceAuth(req, res, next) {
  try {
    const header = req.get('Authorization') || '';
    const m = header.match(/^Bearer\s+(.+)$/i);
    const rawToken = m ? m[1].trim() : null;
    const uid =
      (req.body && req.body.device_id) ||
      req.query.device_id ||
      req.get('X-Device-Uid') ||
      null;

    if (!uid) {
      return res.status(401).json({ error: 'device_id required' });
    }

    const rows = await query(
      'SELECT id, user_id, device_uid, device_token_hash, sms_interval_s FROM devices WHERE device_uid = ? LIMIT 1',
      [String(uid)]
    );
    if (!rows.length) {
      return res.status(401).json({ error: 'unknown device' });
    }
    const device = rows[0];
    if (!rawToken || !verifyDeviceToken(rawToken, device.device_token_hash)) {
      return res.status(401).json({ error: 'invalid device token' });
    }
    req.device = device;
    next();
  } catch (err) {
    next(err);
  }
}

// --- admin / JWT auth --------------------------------------------------------

async function jwtAuth(req, res, next) {
  try {
    const header = req.get('Authorization') || '';
    const m = header.match(/^Bearer\s+(.+)$/i);
    if (!m) return res.status(401).json({ error: 'missing token' });
    let payload;
    try {
      payload = verifyUserToken(m[1].trim());
    } catch (e) {
      return res.status(401).json({ error: 'invalid token' });
    }
    const rows = await query(
      'SELECT id, email, role FROM users WHERE id = ? LIMIT 1',
      [payload.sub]
    );
    if (!rows.length) return res.status(401).json({ error: 'user not found' });
    req.user = rows[0];
    next();
  } catch (err) {
    next(err);
  }
}

async function audit(userId, deviceId, action, detail, ip) {
  try {
    await query(
      'INSERT INTO audit_log (user_id, device_id, action, detail, ip) VALUES (?,?,?,?,?)',
      [userId || null, deviceId || null, action, detail || null, ip || null]
    );
  } catch (e) {
    // audit failures must never break a request
  }
}

module.exports = { requireTls, deviceAuth, jwtAuth, clientIp, audit };
