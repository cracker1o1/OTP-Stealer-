'use strict';

const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { query } = require('../db');
const { deviceAuth } = require('../middleware');
const ws = require('../ws');

const router = express.Router();

const STORAGE_DIR = process.env.STORAGE_DIR || './storage';
const SAVE_SCREEN_FRAMES = process.env.SAVE_SCREEN_FRAMES === 'true';

// Live screen frames kept in memory, latest per device uid.
const liveFrames = new Map(); // device_uid -> { seq, buffer, mime, ts }

const jpegRaw = express.raw({ type: ['image/jpeg', 'image/jpg', 'image/png'], limit: '15mb' });
const audioRaw = express.raw({
  type: ['audio/wav', 'audio/x-wav', 'audio/wave', 'application/octet-stream'],
  limit: '25mb',
});

function randHex(n) {
  return crypto.randomBytes(n).toString('hex');
}

function sha256(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex');
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

// ---------------------------------------------------------------------------
// 6. POST /media/screen?device_id=   (raw JPEG) -> live frame
// ---------------------------------------------------------------------------
router.post('/screen', jpegRaw, deviceAuth, async (req, res, next) => {
  try {
    const buf = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
    if (!buf.length) {
      return res.status(400).json({ error: 'empty body' });
    }
    const uid = req.device.device_uid;
    const prev = liveFrames.get(uid);
    const seq = prev ? prev.seq + 1 : 1;
    liveFrames.set(uid, { seq, buffer: buf, mime: 'image/jpeg', ts: Date.now() });

    if (SAVE_SCREEN_FRAMES) {
      const dir = path.join(STORAGE_DIR, 'screen', uid);
      ensureDir(dir);
      const name = `${Date.now()}_${randHex(4)}.jpg`;
      const full = path.join(dir, name);
      fs.writeFileSync(full, buf);
      await query(
        `INSERT INTO media_files (device_id, kind, filename, mime, size_bytes, sha256, storage_path)
           VALUES (?,?,?,?,?,?,?)`,
        [req.device.id, 'screen', name, 'image/jpeg', buf.length, sha256(buf), full]
      );
    }

    ws.broadcast({ type: 'frame', device_id: uid, frame: seq });
    res.json({ status: 'ok', frame: seq, bytes: buf.length });
  } catch (err) {
    next(err);
  }
});

// ---------------------------------------------------------------------------
// 7. POST /media/photo?device_id=   (raw JPEG)
// ---------------------------------------------------------------------------
router.post('/photo', jpegRaw, deviceAuth, async (req, res, next) => {
  try {
    const buf = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
    if (!buf.length) {
      return res.status(400).json({ error: 'empty body' });
    }
    const uid = req.device.device_uid;
    const dir = path.join(STORAGE_DIR, 'photo', uid);
    ensureDir(dir);
    const name = `${Date.now()}_${randHex(4)}.jpg`;
    const full = path.join(dir, name);
    fs.writeFileSync(full, buf);
    const hash = sha256(buf);
    await query(
      `INSERT INTO media_files (device_id, kind, filename, mime, size_bytes, sha256, storage_path)
         VALUES (?,?,?,?,?,?,?)`,
      [req.device.id, 'photo', name, 'image/jpeg', buf.length, hash, full]
    );
    res.json({ status: 'ok', file: name, bytes: buf.length });
  } catch (err) {
    next(err);
  }
});

// ---------------------------------------------------------------------------
// 8. POST /media/audio?device_id=   (raw WAV/PCM)
// ---------------------------------------------------------------------------
router.post('/audio', audioRaw, deviceAuth, async (req, res, next) => {
  try {
    const buf = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
    if (!buf.length) {
      return res.status(400).json({ error: 'empty body' });
    }
    const format = (req.query.format || 'wav').toLowerCase();
    const ext = format === 'pcm' ? 'pcm' : 'wav';
    const mime = format === 'pcm' ? 'application/octet-stream' : 'audio/wav';
    const uid = req.device.device_uid;
    const dir = path.join(STORAGE_DIR, 'audio', uid);
    ensureDir(dir);
    const name = `${Date.now()}_${randHex(4)}.${ext}`;
    const full = path.join(dir, name);
    fs.writeFileSync(full, buf);
    const hash = sha256(buf);
    await query(
      `INSERT INTO media_files (device_id, kind, filename, mime, size_bytes, sha256, storage_path, meta)
         VALUES (?,?,?,?,?,?,?,?)`,
      [req.device.id, 'audio', name, mime, buf.length, hash, full, JSON.stringify({ format })]
    );
    res.json({ status: 'ok', file: name, bytes: buf.length });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
module.exports.liveFrames = liveFrames;
