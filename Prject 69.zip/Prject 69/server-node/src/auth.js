'use strict';

const crypto = require('crypto');
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-insecure-secret-change-me';
const JWT_EXPIRES_IN = '12h';

// --- device tokens -----------------------------------------------------------

function sha256Hex(value) {
  return crypto.createHash('sha256').update(String(value)).digest('hex');
}

function generateDeviceToken() {
  return crypto.randomBytes(32).toString('hex'); // 64 hex chars
}

// Constant-time comparison of two equal-length hex strings.
function timingSafeEqualHex(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const ba = Buffer.from(a, 'utf8');
  const bb = Buffer.from(b, 'utf8');
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

// Verify a raw device token against a stored sha256 hex hash.
function verifyDeviceToken(rawToken, storedHash) {
  if (!rawToken || !storedHash) return false;
  return timingSafeEqualHex(sha256Hex(rawToken), String(storedHash));
}

// --- JWT ---------------------------------------------------------------------

function signUserToken(user) {
  return jwt.sign(
    { sub: user.id, email: user.email, role: user.role },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

function verifyUserToken(token) {
  return jwt.verify(token, JWT_SECRET);
}

module.exports = {
  sha256Hex,
  generateDeviceToken,
  verifyDeviceToken,
  timingSafeEqualHex,
  signUserToken,
  verifyUserToken,
  JWT_SECRET,
  JWT_EXPIRES_IN,
};
