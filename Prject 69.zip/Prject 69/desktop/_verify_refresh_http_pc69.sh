#!/usr/bin/env bash
# Live checks against the running server (PC69 refresh/live-photo work).
# Saves every response to _tmp_pc69_http/ so the checks can be re-read without
# re-querying (and without queuing a second command on the phone).
set -u
cd "C:/Users/Dell/Desktop/Prject 69/desktop" || exit 1
BASE=https://127.0.0.1:8443
# Kept inside the project so Python (which does not share msys' /tmp) can read it.
OUT="./_tmp_pc69_http"
mkdir -p "$OUT"
rm -f "$OUT"/*.json "$OUT"/*.txt
JAR="$OUT/cookies.txt"

echo "--- 1. dashboard shell"
curl -sk --max-time 10 -o "$OUT/root.html" -w "root=%{http_code}\n" "$BASE/"

echo "--- 2. login"
curl -sk --max-time 10 -c "$JAR" -X POST -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"Pc69-91b871ea"}' \
  -o "$OUT/login.json" -w "login=%{http_code}\n" "$BASE/auth/login"

echo "--- 3. catalog (must expose refresh_actions)"
curl -sk --max-time 10 -b "$JAR" -o "$OUT/catalog.json" -w "catalog=%{http_code}\n" \
  "$BASE/api/v1/web/catalog"

echo "--- 4. device list"
curl -sk --max-time 10 -b "$JAR" -o "$OUT/devices.json" -w "devices=%{http_code}\n" \
  "$BASE/api/v1/web/devices"
DEV=$(sed -n 's/.*"id": *\([0-9][0-9]*\).*/\1/p' "$OUT/devices.json" | head -1)
echo "device_id=$DEV"

if [ -n "${DEV:-}" ]; then
  echo "--- 5. queue call_log_refresh (the Calls 'Fetch latest' button)"
  curl -sk --max-time 10 -b "$JAR" -X POST -H "Content-Type: application/json" \
    -d '{"action":"call_log_refresh"}' \
    -o "$OUT/command_calls.json" -w "command_calls=%{http_code}\n" \
    "$BASE/api/v1/web/command/$DEV"

  echo "--- 6. queue camera_photo (the 'Live photo' button)"
  curl -sk --max-time 10 -b "$JAR" -X POST -H "Content-Type: application/json" \
    -d '{"action":"camera_photo","params":{"camera":"back"}}' \
    -o "$OUT/command_photo.json" -w "command_photo=%{http_code}\n" \
    "$BASE/api/v1/web/command/$DEV"

  echo "--- 7. command log"
  curl -sk --max-time 10 -b "$JAR" -o "$OUT/commands.json" -w "commands=%{http_code}\n" \
    "$BASE/api/v1/web/commands/$DEV"

  echo "--- 8. data grids"
  for kind in Calls SMS Contacts Media; do
    curl -sk --max-time 10 -b "$JAR" -o "$OUT/data_$kind.json" \
      -w "data_$kind=%{http_code}\n" "$BASE/api/v1/web/data/$DEV/$kind"
  done

  echo "--- 9. unknown action must be refused"
  curl -sk --max-time 10 -b "$JAR" -X POST -H "Content-Type: application/json" \
    -d '{"action":"warp_drive"}' -o "$OUT/bad_action.json" -w "bad_action=%{http_code}\n" \
    "$BASE/api/v1/web/command/$DEV"
fi

echo "$DEV" > "$OUT/device_id.txt"
echo "--- done, responses in $OUT"
