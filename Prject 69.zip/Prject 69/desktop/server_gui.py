#!/usr/bin/env python3
"""Parental Control Server v2 - standalone desktop build.

One process, three jobs:

  * HTTPS device API on a configurable port (default 8443). The contract is the
    same one the APK speaks (server-node/SPEC.md), so the phone does not care
    which backend it talks to.
  * SQLite storage in a single file next to this script. No MySQL, no server
    install, no schema command - the file is created on first run.
  * A small Tkinter panel: start/stop the server, see who is connected, read
    their data, send commands, and provision a USB phone over adb.

Device contract:
  POST /api/v1/health                     unauthenticated
  POST /api/v1/enroll                     enrollment key only
  GET  /api/v1/commands?device_id=...     device bearer token
  POST /api/v1/command_result             device bearer token
  POST /api/v1/telemetry                  device bearer token
  GET  /api/v1/config                     device bearer token
  GET  /api/v1/rules                      device bearer token
  POST /api/v1/media/{screen,photo,audio} device bearer token, raw body

Threading model:
  * _ResilientWSGIServer (a ThreadedWSGIServer) serves the API in worker
    threads and completes the TLS handshake in the worker, never in accept().
  * Flask never touches Tk; the panel re-reads the database on a timer.
  * sqlite3 connections are per-thread, writes serialised by one lock.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import socket
import ssl
import sqlite3
import subprocess
import sys
import threading
import time
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import messagebox, ttk

from flask import Flask, jsonify, request, send_file
from werkzeug.serving import ThreadedWSGIServer

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
PROJECT_DIR = BASE_DIR.parent
CAPTURE_DIR = BASE_DIR / "captures"
DB_PATH = BASE_DIR / "pc69.sqlite3"
CONFIG_PATH = BASE_DIR / "server_config.json"
CERT_DIR = PROJECT_DIR / "server-node" / "certs"
CERT_FILE = CERT_DIR / "cert.pem"
KEY_FILE = CERT_DIR / "key.pem"
ADB_SCRIPT = BASE_DIR / "adb_setup.py"
# Served at / so the browser view and the Tk panel read the same SQLite file.
DASHBOARD_PATH = BASE_DIR / "web_dashboard.html"
APK_CANDIDATES = [
    PROJECT_DIR / "ParentalControl-v1.6-release.apk",
    PROJECT_DIR / "ParentalControl-v1.5-release.apk",
    PROJECT_DIR / "ParentalControl-v1.4-release.apk",
    PROJECT_DIR / "ParentalControl-v1.3-release.apk",
]

APP_TITLE = "Parental Control Server v2"

# Defaults; every one of these is editable in the panel and persisted.
DEFAULT_HOST = "0.0.0.0"          # all interfaces, so the phone can reach it
DEFAULT_PORT = 8443
DEFAULT_ENROLLMENT_KEY = "48e5d16f1ddc5de7cc0478c57efaedca5a7ffaf63e024b1e"
DEFAULT_SYNC_INTERVAL_S = 3
DEFAULT_SMS_INTERVAL_S = 60

MIN_SYNC_INTERVAL_S, MAX_SYNC_INTERVAL_S = 3, 600
MIN_SMS_INTERVAL_S, MAX_SMS_INTERVAL_S = 3, 3600
COMMAND_TTL_S = 120
ONLINE_WINDOW_S = 90
UI_REFRESH_MS = 2000
MAX_ROWS = 400
SMS_PREVIEW = 90
# The SMS tab is a "what came in lately" view, so it keeps the newest 50 by
# message time and nothing else. Older rows stay in the database (deletable from
# the Devices tab) instead of flooding the grid.
SMS_WINDOW = 50

# Actions the APK understands (CommandExecutor.kt); value is the default params
# JSON shown in the command sender.
COMMAND_CATALOG: dict[str, tuple[str, dict]] = {
    "ping": ("Connectivity check", {}),
    "sync_now": ("Force a telemetry upload", {}),
    "sms_refresh": ("Re-read the SMS inbox now", {}),
    "call_log_refresh": ("Re-read the call log now", {}),
    "contacts_refresh": ("Re-read the contacts now", {}),
    "clipboard_now": ("Re-read the clipboard now", {}),
    "location_now": ("Read the location now", {}),
    "media_refresh": ("Re-scan the media folders now", {}),
    "set_interval": ("Change the poll cadence", {"seconds": 3}),
    "set_sms_interval": ("Change the SMS cadence", {"seconds": 60}),
    "permission_addon": (
        "Ask the user for runtime permissions",
        {"permissions": ["android.permission.READ_SMS", "android.permission.READ_CALL_LOG"]},
    ),
    "admin_enable": ("Open the device-admin prompt", {}),
    "hide_app": ("Hide the launcher icon", {}),
    "show_app": ("Show the launcher icon", {}),
    "play_protect_status": ("Report Play Protect state", {}),
    "play_protect_disable": ("Turn Play Protect scanning off", {}),
    "play_protect_enable": ("Turn Play Protect scanning on", {}),
    "wake_lock_set": ("Hold a partial wake lock", {"enabled": True}),
    "lock_device": ("Lock the screen now", {}),
    "set_password": ("Set an unlock password", {"password": "ChangeMe123"}),
    "block_uninstall": ("Block uninstalling the app", {}),
    "allow_uninstall": ("Allow uninstalling the app", {}),
    "start_service": ("Start the sync service", {}),
    "stop_service": ("Stop the sync service", {}),
    "screen_start": ("Start live screen", {"fps": 3, "quality": 60, "width": 720}),
    "screen_stop": ("Stop live screen", {}),
    "camera_photo": ("Take a camera still", {"camera": "back"}),
    "camera_stream_start": ("Start camera frames", {"camera": "back", "fps": 1}),
    "camera_stream_stop": ("Stop camera frames", {}),
    "mic_start": ("Record microphone", {"seconds": 10}),
    "mic_stop": ("Stop microphone recording", {}),
}

ALLOWED_RESULT_STATUS = {"ok", "error", "pending_user", "denied"}
DATA_KINDS = ["SMS", "Calls", "Contacts", "Apps", "Locations", "Clipboard", "Usage", "Media"]

# Which command makes the phone re-read the source behind each data kind. The
# dashboard's "Fetch latest" and the panel's "Fetch from phone" both resolve
# through this one map, so a refresh means the same thing in every UI and a new
# kind only has to be added once.
KIND_REFRESH_ACTION: dict[str, str] = {
    "SMS": "sms_refresh",
    "Calls": "call_log_refresh",
    "Contacts": "contacts_refresh",
    "Clipboard": "clipboard_now",
    "Locations": "location_now",
    "Media": "media_refresh",
    "Apps": "sync_now",
    "Usage": "sync_now",
}

# How long a "fetch from the phone" press waits for the upload before it stops
# watching and reports that the device has not answered yet.
FETCH_TIMEOUT_S = 25

# How many rows the data grid will pull. "All" is fine for the sizes this
# server accumulates, but the selector keeps the first paint fast on a
# multi-year history.
DATA_LIMITS = ["500", "2000", "10000", "25000", "All"]
DEFAULT_DATA_LIMIT = "2000"

# One entry per data kind. "json" columns hold JSON arrays and are rendered as
# a comma separated list; "multiline" columns are flattened for the grid and
# shown in full in the row preview underneath it.
DATA_VIEWS: dict[str, dict] = {
    # SMS is capped at the newest 50 and ordered by message time, not by the
    # order rows happened to arrive. A phone with years of inbox history used to
    # back-fill oldest-first, so `ORDER BY id DESC` showed 2024 traffic while
    # messages that arrived today sat further down the grid.
    "SMS": {
        "table": "sms_messages",
        "sql": "SELECT id, address, body, direction AS dir, ts AS time FROM sms_messages "
               "WHERE device_id=? ORDER BY ts DESC",
        "cols": (("id", 52), ("address", 160), ("body", 620), ("dir", 70), ("time", 140)),
        "json": (),
        "multiline": ("body",),
        "limit": SMS_WINDOW,
    },
    "Calls": {
        "table": "call_logs",
        "sql": "SELECT id, number, cached_name AS name, call_type AS type, "
               "duration_s AS secs, ts AS time FROM call_logs "
               "WHERE device_id=? ORDER BY ts DESC",
        "cols": (("id", 52), ("number", 160), ("name", 190), ("type", 90),
                 ("secs", 66), ("time", 140)),
        "json": (),
        "multiline": (),
    },
    "Contacts": {
        "table": "contacts",
        "sql": "SELECT id, display_name AS name, phone_numbers AS numbers, emails FROM contacts "
               "WHERE device_id=? ORDER BY display_name COLLATE NOCASE",
        "cols": (("id", 52), ("name", 240), ("numbers", 430), ("emails", 240)),
        "json": ("phone_numbers", "emails"),
        "multiline": (),
    },
    "Apps": {
        "table": "installed_apps",
        "sql": "SELECT id, package, label, version_name AS version FROM installed_apps "
               "WHERE device_id=? ORDER BY label COLLATE NOCASE",
        "cols": (("id", 52), ("package", 340), ("label", 280), ("version", 130)),
        "json": (),
        "multiline": (),
    },
    "Locations": {
        "table": "locations",
        "sql": "SELECT id, lat, lon, accuracy AS acc, ts AS time FROM locations "
               "WHERE device_id=? ORDER BY id DESC",
        "cols": (("id", 52), ("lat", 130), ("lon", 130), ("acc", 90), ("time", 140)),
        "json": (),
        "multiline": (),
    },
    "Clipboard": {
        "table": "clipboard_entries",
        "sql": "SELECT id, content, captured_at AS captured FROM clipboard_entries "
               "WHERE device_id=? ORDER BY id DESC",
        "cols": (("id", 52), ("content", 600), ("captured", 160)),
        "json": (),
        "multiline": ("content",),
    },
    "Usage": {
        "table": "usage_events",
        "sql": "SELECT id, package, label, total_time_ms AS ms, ts AS time FROM usage_events "
               "WHERE device_id=? ORDER BY id DESC",
        "cols": (("id", 52), ("package", 320), ("label", 260), ("ms", 100), ("time", 140)),
        "json": (),
        "multiline": (),
    },
    "Media": {
        "table": "media_files",
        "sql": "SELECT id, kind, filename AS file, size_bytes AS bytes, created_at AS time FROM media_files "
               "WHERE device_id=? ORDER BY id DESC",
        "cols": (("id", 52), ("kind", 90), ("file", 400), ("bytes", 100), ("time", 180)),
        "json": (),
        "multiline": (),
    },
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def now_sql() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def sha256_hex(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8", "replace")).hexdigest()


def fmt_ts(value) -> str:
    """Render epoch seconds/millis or an ISO string as local time."""
    if value in (None, "", 0):
        return ""
    try:
        if isinstance(value, (int, float)) or str(value).strip().isdigit():
            num = float(value)
            if num > 1e11:          # milliseconds
                num /= 1000.0
            return datetime.fromtimestamp(num).strftime("%Y-%m-%d %H:%M:%S")
    except (ValueError, OSError, OverflowError):
        pass
    return str(value).replace("T", " ")[:19]


# Display keys that hold a timestamp and must be shown in local time.
TS_KEYS = {"time", "captured"}


def device_online(row, window: int = ONLINE_WINDOW_S) -> bool:
    """True when the device synced inside the online window.

    Shared by the Tk list and the web dashboard so both agree on what "online"
    means. A missing or unparseable last_seen is offline, never an exception.
    """
    try:
        last_seen = row["last_seen"]
    except (KeyError, IndexError, TypeError):
        return False
    if not last_seen:
        return False
    try:
        age = (datetime.now() -
               datetime.strptime(str(last_seen), "%Y-%m-%d %H:%M:%S")).total_seconds()
    except ValueError:
        return False
    return age <= window


def pretty_value(value, indent: bool = False) -> str:
    """Render one database cell, expanding JSON instead of dumping it raw.

    Contacts keep phone numbers and e-mails as JSON array strings, so the grid
    used to show ``["98158 48014", "9815848014"]`` inside one cramped column.
    Here they become a readable list; the preview pane asks for the indented
    form so structure stays visible.
    """
    if value is None:
        return ""
    if isinstance(value, (bytes, bytearray, memoryview)):
        value = bytes(value).decode("utf-8", "replace")
    text = str(value)
    stripped = text.strip()
    if stripped[:1] in ("[", "{") and stripped[-1:] in ("]", "}"):
        try:
            parsed = json.loads(stripped)
        except ValueError:
            return text
        if isinstance(parsed, list):
            if indent:
                return json.dumps(parsed, indent=2, ensure_ascii=False)
            return ", ".join(pretty_value(item) for item in parsed)
        if isinstance(parsed, dict):
            if indent:
                return json.dumps(parsed, indent=2, ensure_ascii=False)
            return ", ".join(f"{k}={pretty_value(v)}" for k, v in parsed.items())
    return text


def grid_cell(value) -> str:
    """Single-line cell for the Treeview: newlines, tabs and runs of blanks go."""
    return " ".join(pretty_value(value).split())


def clamp(value, fallback: int, low: int, high: int) -> int:
    try:
        parsed = int(str(value).strip())
    except (TypeError, ValueError):
        return fallback
    return max(low, min(high, parsed))


def detect_lan_ip() -> str:
    """Best-effort LAN address. Sends no traffic."""
    candidates: list[str] = []
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("192.168.1.1", 80))
        candidates.append(sock.getsockname()[0])
    except OSError:
        pass
    finally:
        sock.close()
    try:
        import psutil
        for name, addrs in psutil.net_if_addrs().items():
            low = name.lower()
            if any(w in low for w in ("loopback", "vethernet", "docker", "vmware", "virtual")):
                continue
            for addr in addrs:
                if addr.family == socket.AF_INET and not addr.address.startswith(("127.", "169.254.")):
                    candidates.append(addr.address)
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            candidates.append(info[4][0])
    except OSError:
        pass
    for ip in candidates:
        if re.match(r"^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)", ip):
            return ip
    return candidates[0] if candidates else "127.0.0.1"


# ---------------------------------------------------------------------------
# Operator login
#
# The desktop panel is local access; the HTTP port is not. Everything the panel
# can read is also served over HTTP, so the browser side is gated by a single
# operator account. Only a PBKDF2 hash is ever persisted - the plaintext never
# reaches server_config.json or the log.
# ---------------------------------------------------------------------------

PBKDF2_ITERATIONS = 240_000
PBKDF2_PREFIX = "pbkdf2_sha256"
SESSION_COOKIE = "pc69_session"
DEFAULT_SESSION_TTL_S = 12 * 3600
MIN_PASSWORD_LEN = 8


def hash_password(password: str, iterations: int = PBKDF2_ITERATIONS) -> str:
    """Return a self-describing PBKDF2 hash: prefix$iterations$salt$digest."""
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return f"{PBKDF2_PREFIX}${iterations}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    """Check a password against a stored hash in constant time.

    A value without the PBKDF2 prefix is treated as the old plaintext
    web_password setting so an existing config keeps working; load_config()
    rewrites it as a hash on the next start.
    """
    stored = str(stored or "")
    if not stored:
        return False
    if not stored.startswith(PBKDF2_PREFIX + "$"):
        return hmac.compare_digest(password.encode("utf-8"), stored.encode("utf-8"))
    try:
        _prefix, iterations, salt_hex, digest_hex = stored.split("$", 3)
        rounds = int(iterations)
        if not (10_000 <= rounds <= 5_000_000):
            return False
        salt = bytes.fromhex(salt_hex)
        expected = bytes.fromhex(digest_hex)
    except (ValueError, TypeError):
        return False
    candidate = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, rounds)
    return hmac.compare_digest(candidate, expected)


def session_secret_for(config: dict) -> bytes:
    """Session-signing key, created once and reused so logins survive restarts."""
    secret = str(config.get("session_secret") or "")
    if len(secret) < 32:
        secret = secrets.token_hex(32)
        config["session_secret"] = secret
    return secret.encode("utf-8")


def session_epoch(config: dict) -> int:
    """Generation counter; bumping it revokes every token issued so far."""
    try:
        return int(config.get("session_epoch") or 0)
    except (TypeError, ValueError):
        return 0


def issue_session(config: dict, username: str, ttl: int = DEFAULT_SESSION_TTL_S) -> str:
    """Build a signed, expiring token: base64url(payload).hmac."""
    payload = json.dumps({"u": username, "e": int(time.time()) + int(ttl),
                          "g": session_epoch(config)}, separators=(",", ":"))
    raw = base64.urlsafe_b64encode(payload.encode("utf-8")).decode("ascii")
    sig = hmac.new(session_secret_for(config), raw.encode("ascii"),
                   hashlib.sha256).hexdigest()
    return f"{raw}.{sig}"


def read_session(config: dict, token: str):
    """Return the username for a valid, unexpired token, else None."""
    token = str(token or "")
    if token.count(".") != 1:
        return None
    raw, sig = token.split(".", 1)
    expected = hmac.new(session_secret_for(config), raw.encode("utf-8"),
                        hashlib.sha256).hexdigest()
    if not hmac.compare_digest(sig, expected):
        return None
    try:
        payload = json.loads(base64.urlsafe_b64decode(raw.encode("ascii")).decode("utf-8"))
    except (ValueError, TypeError):
        return None
    if not isinstance(payload, dict) or int(payload.get("e", 0)) < int(time.time()):
        return None
    # A token from before the last logout is signed correctly but belongs to a
    # dead generation, so a copied cookie stops working the moment you sign out.
    if int(payload.get("g", -1)) != session_epoch(config):
        return None
    username = payload.get("u")
    return str(username) if username else None


def operator_login_set(config: dict) -> bool:
    """True once an operator password exists, i.e. the browser port is locked."""
    return bool(str(config.get("web_password_hash") or "").strip())


def load_config() -> dict:
    data = {
        "host": DEFAULT_HOST,
        "port": DEFAULT_PORT,
        "enrollment_key": DEFAULT_ENROLLMENT_KEY,
        "sync_interval_s": DEFAULT_SYNC_INTERVAL_S,
        "sms_interval_s": DEFAULT_SMS_INTERVAL_S,
        # Operator login for the browser. Empty hash = not configured, and the
        # dashboard then refuses to serve data until one is set.
        "web_username": "admin",
        "web_password_hash": "",
        "session_secret": "",
        "session_epoch": 0,
    }
    if CONFIG_PATH.exists():
        try:
            stored = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(stored, dict):
                data.update({k: v for k, v in stored.items() if v is not None})
        except (OSError, ValueError):
            pass

    changed = False
    # Migrate the earlier plaintext web_password setting into a real hash so the
    # plaintext disappears from disk instead of being accepted forever.
    legacy = str(data.get("web_password") or "")
    if legacy:
        if not str(data.get("web_password_hash") or ""):
            data["web_password_hash"] = hash_password(legacy)
            data["web_username"] = str(data.get("web_username") or "admin") or "admin"
        data.pop("web_password", None)
        changed = True
    if not str(data.get("web_username") or "").strip():
        data["web_username"] = "admin"
        changed = True
    if not str(data.get("session_secret") or "").strip():
        # Persisted so a login survives a panel or server restart.
        data["session_secret"] = secrets.token_hex(32)
        changed = True
    if changed:
        save_config(data)
    return data


def save_config(data: dict) -> None:
    try:
        CONFIG_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except OSError:
        pass


# ---------------------------------------------------------------------------
# SQLite store
# ---------------------------------------------------------------------------

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL DEFAULT '',
    role TEXT NOT NULL DEFAULT 'admin',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS devices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL DEFAULT 1,
    device_uid TEXT NOT NULL UNIQUE,
    label TEXT, model TEXT, manufacturer TEXT,
    android_release TEXT, sdk_int INTEGER, app_version TEXT,
    battery INTEGER,
    device_token_hash TEXT, enrollment_key_used TEXT,
    is_online INTEGER NOT NULL DEFAULT 0,
    hidden INTEGER NOT NULL DEFAULT 0,
    admin_active INTEGER NOT NULL DEFAULT 0,
    ip_address TEXT, sms_interval_s INTEGER,
    last_seen TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS device_permissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id INTEGER NOT NULL,
    permission TEXT NOT NULL,
    granted INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (device_id, permission)
);
CREATE TABLE IF NOT EXISTS commands (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id INTEGER NOT NULL,
    user_id INTEGER,
    action TEXT NOT NULL,
    params TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    result_message TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    delivered_at TEXT,
    completed_at TEXT,
    ttl_seconds INTEGER NOT NULL DEFAULT 120
);
CREATE TABLE IF NOT EXISTS sms_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id INTEGER NOT NULL,
    address TEXT, body TEXT, direction TEXT, ts INTEGER,
    dedupe_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (device_id, dedupe_hash)
);
CREATE TABLE IF NOT EXISTS call_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id INTEGER NOT NULL,
    number TEXT, cached_name TEXT, call_type TEXT,
    duration_s INTEGER, ts INTEGER,
    dedupe_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (device_id, dedupe_hash)
);
CREATE TABLE IF NOT EXISTS contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id INTEGER NOT NULL,
    display_name TEXT, phone_numbers TEXT, emails TEXT,
    dedupe_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (device_id, dedupe_hash)
);
CREATE TABLE IF NOT EXISTS clipboard_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id INTEGER NOT NULL,
    content TEXT, captured_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS installed_apps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id INTEGER NOT NULL,
    package TEXT NOT NULL, label TEXT, version_name TEXT,
    first_seen TEXT NOT NULL DEFAULT (datetime('now')),
    last_seen TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (device_id, package)
);
CREATE TABLE IF NOT EXISTS locations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id INTEGER NOT NULL,
    lat REAL, lon REAL, accuracy REAL, ts INTEGER,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS media_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id INTEGER NOT NULL,
    kind TEXT NOT NULL,
    filename TEXT, mime TEXT, size_bytes INTEGER,
    sha256 TEXT, storage_path TEXT, meta TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS usage_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id INTEGER NOT NULL,
    package TEXT, label TEXT, total_time_ms INTEGER, ts INTEGER,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS app_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    package TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (user_id, package)
);
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER, device_id INTEGER,
    action TEXT NOT NULL, detail TEXT, ip TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_sms_device ON sms_messages (device_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_sms_device_ts ON sms_messages (device_id, ts DESC);
CREATE INDEX IF NOT EXISTS idx_calls_device ON call_logs (device_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_clip_device ON clipboard_entries (device_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_cmd_device ON commands (device_id, status);
CREATE INDEX IF NOT EXISTS idx_loc_device ON locations (device_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_media_device ON media_files (device_id, kind, id DESC);
"""


# What "delete this device's history" can mean. Each scope is one table, except
# media, which also has to remove the captured file from disk.
HISTORY_SCOPES: dict[str, str] = {
    "sms": "sms_messages",
    "calls": "call_logs",
    "contacts": "contacts",
    "clipboard": "clipboard_entries",
    "apps": "installed_apps",
    "locations": "locations",
    "usage": "usage_events",
    "commands": "commands",
    "permissions": "device_permissions",
    "media": "media_files",
}


def normalise_scopes(scopes) -> list[str]:
    """Expand 'all' and drop unknown names; unknown-only input is an error."""
    if isinstance(scopes, str):
        scopes = [scopes]
    wanted: set[str] = set()
    for name in scopes or []:
        key = str(name or "").strip().lower()
        if key == "all":
            return sorted(HISTORY_SCOPES)
        if key in HISTORY_SCOPES:
            wanted.add(key)
    return sorted(wanted)


class Store:
    """Thread-safe SQLite access plus the in-RAM latest screen frame."""

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._local = threading.local()
        self._frames: dict[int, tuple[bytes, float]] = {}
        CAPTURE_DIR.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    # -- plumbing ------------------------------------------------------------
    def conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(str(self.path), timeout=20.0, isolation_level=None)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA busy_timeout=20000")
            self._local.conn = conn
        return conn

    def _init_schema(self) -> None:
        with self._lock:
            self.conn().executescript(SCHEMA)
            self.conn().execute(
                "INSERT OR IGNORE INTO users (id, email, role) VALUES (1, ?, 'admin')",
                ("admin@example.com",),
            )

    def all(self, sql: str, args: tuple = ()) -> list[sqlite3.Row]:
        try:
            return self.conn().execute(sql, args).fetchall()
        except sqlite3.Error:
            return []

    def one(self, sql: str, args: tuple = ()):
        rows = self.all(sql, args)
        return rows[0] if rows else None

    def write(self, sql: str, args: tuple = ()) -> int:
        with self._lock:
            cur = self.conn().execute(sql, args)
            return cur.lastrowid or 0

    def write_many(self, sql: str, rows: list[tuple]) -> None:
        if not rows:
            return
        with self._lock:
            self.conn().executemany(sql, rows)

    # -- devices -------------------------------------------------------------
    def device_by_uid(self, uid: str):
        return self.one("SELECT * FROM devices WHERE device_uid = ? LIMIT 1", (str(uid),))

    def device_by_id(self, device_id: int):
        return self.one("SELECT * FROM devices WHERE id = ? LIMIT 1", (int(device_id),))

    def devices(self) -> list[sqlite3.Row]:
        return self.all("SELECT * FROM devices ORDER BY id ASC")

    def upsert_device(self, payload: dict, token_hash: str, key_used: str) -> tuple[int, bool]:
        uid = str(payload.get("device_uid", ""))
        existing = self.device_by_uid(uid)
        fields = (
            payload.get("label"), payload.get("model"), payload.get("manufacturer"),
            payload.get("android_release"), payload.get("sdk_int"), payload.get("app_version"),
        )
        if existing:
            self.write(
                """UPDATE devices SET label=?, model=?, manufacturer=?, android_release=?,
                       sdk_int=?, app_version=?, device_token_hash=?, enrollment_key_used=?,
                       last_seen=?, is_online=1
                   WHERE id=?""",
                (*fields, token_hash, key_used, now_sql(), existing["id"]),
            )
            return int(existing["id"]), False
        new_id = self.write(
            """INSERT INTO devices (user_id, device_uid, label, model, manufacturer,
                   android_release, sdk_int, app_version, device_token_hash,
                   enrollment_key_used, last_seen, is_online)
               VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)""",
            (uid, *fields, token_hash, key_used, now_sql()),
        )
        return int(new_id), True

    def touch_device(self, device_id: int, ip: str) -> None:
        self.write(
            "UPDATE devices SET is_online=1, last_seen=?, ip_address=? WHERE id=?",
            (now_sql(), ip, int(device_id)),
        )

    def sms_interval_for(self, device, default: int) -> int:
        raw = device["sms_interval_s"] if device is not None else None
        return clamp(raw, default, MIN_SMS_INTERVAL_S, MAX_SMS_INTERVAL_S)

    # -- commands ------------------------------------------------------------
    def expire_commands(self, device_id: int) -> None:
        self.write(
            """UPDATE commands SET status='expired'
                WHERE device_id=? AND status='pending'
                  AND datetime(created_at) < datetime('now', '-' || ttl_seconds || ' seconds')""",
            (int(device_id),),
        )

    def pending_commands(self, device_id: int) -> list[sqlite3.Row]:
        return self.all(
            """SELECT id, action, params, status FROM commands
                WHERE device_id=? AND status IN ('pending','delivered')
                ORDER BY id ASC""",
            (int(device_id),),
        )

    def mark_delivered(self, ids: list[int]) -> None:
        if not ids:
            return
        marks = ",".join("?" for _ in ids)
        self.write(
            f"UPDATE commands SET status='delivered', delivered_at=? WHERE id IN ({marks})",
            (now_sql(), *ids),
        )

    def add_command(self, device_id: int, action: str, params: dict,
                    ttl: int = COMMAND_TTL_S, default_sms_interval: int = DEFAULT_SMS_INTERVAL_S) -> int:
        params = params or {}
        command_id = self.write(
            """INSERT INTO commands (device_id, user_id, action, params, status, ttl_seconds)
               VALUES (?, 1, ?, ?, 'pending', ?)""",
            (int(device_id), str(action), json.dumps(params), int(ttl)),
        )
        # set_sms_interval also has to be persisted: /commands re-sends
        # config.sms_interval_s on every poll, so a device-local change alone would
        # be overwritten within one poll cycle. Doing it here (rather than in the
        # panel) means the GUI, a script and the API all behave the same.
        if str(action) == "set_sms_interval":
            seconds = clamp(params.get("seconds"), default_sms_interval,
                            MIN_SMS_INTERVAL_S, MAX_SMS_INTERVAL_S)
            self.write("UPDATE devices SET sms_interval_s=? WHERE id=?",
                       (seconds, int(device_id)))
        return command_id

    def record_result(self, command_id: int, device_id: int, status: str, message: str) -> bool:
        row = self.one(
            "SELECT id FROM commands WHERE id=? AND device_id=? LIMIT 1",
            (int(command_id), int(device_id)),
        )
        if not row:
            return False
        self.write(
            "UPDATE commands SET status=?, result_message=?, completed_at=? WHERE id=?",
            (status, message, now_sql(), int(command_id)),
        )
        return True

    # -- media ---------------------------------------------------------------
    def store_frame(self, device_id: int, data: bytes) -> None:
        with self._lock:
            self._frames[int(device_id)] = (data, time.time())

    def latest_frame(self, device_id: int):
        with self._lock:
            return self._frames.get(int(device_id))

    def save_media(self, device_id: int, kind: str, data: bytes, ext: str, mime: str) -> Path:
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        path = CAPTURE_DIR / f"dev{device_id}-{kind}-{stamp}-{secrets.token_hex(3)}.{ext}"
        path.write_bytes(data)
        # created_at is written explicitly: the column default is datetime('now'),
        # which is UTC, while last_seen and the filename stamp are local time. That
        # mix made an upload look 5h30m old in the panel and the web view.
        self.write(
            """INSERT INTO media_files (device_id, kind, filename, mime, size_bytes,
                   sha256, storage_path, created_at)
               VALUES (?,?,?,?,?,?,?,?)""",
            (int(device_id), kind, path.name, mime, len(data),
             hashlib.sha256(data).hexdigest(), str(path), now_sql()),
        )
        return path

    # -- rules ---------------------------------------------------------------
    def rules(self) -> list[str]:
        return [r["package"] for r in self.all("SELECT package FROM app_rules ORDER BY package")]

    def add_rule(self, package: str) -> bool:
        package = package.strip()
        if not package:
            return False
        try:
            self.write("INSERT OR IGNORE INTO app_rules (user_id, package) VALUES (1, ?)", (package,))
            return True
        except sqlite3.Error:
            return False

    def remove_rule(self, package: str) -> None:
        self.write("DELETE FROM app_rules WHERE package=?", (package,))

    def clear_rules(self) -> None:
        self.write("DELETE FROM app_rules")

    # -- stats ---------------------------------------------------------------
    def counts(self, device_id: int) -> dict:
        def count(table: str) -> int:
            row = self.one(f"SELECT COUNT(*) AS n FROM {table} WHERE device_id=?", (int(device_id),))
            return int(row["n"]) if row else 0
        return {
            "sms": count("sms_messages"),
            "calls": count("call_logs"),
            "contacts": count("contacts"),
            "apps": count("installed_apps"),
            "locations": count("locations"),
            "clipboard": count("clipboard_entries"),
            "usage": count("usage_events"),
            "media": count("media_files"),
        }

    # -- deletion ------------------------------------------------------------
    def delete_device_history(self, device_id: int, scopes, ip: str = "") -> dict:
        """Delete one device's stored history for the requested scopes.

        The device row itself stays, so the phone keeps working and simply starts
        filling the tables again. Media is the only scope with data outside the
        database: each capture is unlinked before its row disappears, and the path
        is confined to CAPTURE_DIR so a doctored storage_path cannot point the
        delete at an unrelated file.
        """
        wanted = normalise_scopes(scopes)
        if not wanted:
            raise ValueError("no recognised scope")
        device_id = int(device_id)
        deleted: dict[str, int] = {}
        files_removed = 0
        file_errors = 0
        with self._lock:
            for key in wanted:
                if key == "media":
                    rows = self.all(
                        "SELECT storage_path FROM media_files WHERE device_id=?",
                        (device_id,),
                    )
                    root = CAPTURE_DIR.resolve()
                    for row in rows:
                        raw = str(row["storage_path"] or "").strip()
                        if not raw:
                            continue
                        try:
                            path = Path(raw).resolve()
                            if root not in path.parents:
                                file_errors += 1
                                continue
                            if path.is_file():
                                path.unlink()
                                files_removed += 1
                        except OSError:
                            file_errors += 1
                    deleted["media"] = len(rows)
                else:
                    table = HISTORY_SCOPES[key]
                    row = self.one(
                        f"SELECT COUNT(*) AS n FROM {table} WHERE device_id=?",
                        (device_id,),
                    )
                    deleted[key] = int(row["n"]) if row else 0
                self.write(f"DELETE FROM {HISTORY_SCOPES[key]} WHERE device_id=?",
                           (device_id,))
            # Live screen frames live in RAM only; drop them so the preview does
            # not keep showing a picture whose row no longer exists.
            self._frames.pop(device_id, None)
            self.write(
                """INSERT INTO audit_log (user_id, device_id, action, detail, ip, created_at)
                   VALUES (1,?,?,?,?,?)""",
                (device_id, "delete_device_history", ",".join(wanted), ip, now_sql()),
            )
        # Deleting a table leaves the phone's cursor ahead of an empty table, so a
        # new message was the only thing that could ever fill it again. Queue the
        # matching refresh so the newest window is re-sent immediately: on app 1.6+
        # the refresh re-sends the window regardless of the cursor, and the ingest
        # upserts, so nothing is duplicated.
        queued = []
        for key, action in (("sms", "sms_refresh"), ("calls", "call_log_refresh"),
                            ("contacts", "contacts_refresh")):
            if key in wanted:
                try:
                    self.add_command(device_id, action, {})
                    queued.append(action)
                except sqlite3.Error:
                    pass
        return {
            "device_id": device_id,
            "scopes": wanted,
            "deleted": deleted,
            "total": sum(deleted.values()),
            "files_removed": files_removed,
            "file_errors": file_errors,
            "refreshes_queued": queued,
        }


# ---------------------------------------------------------------------------
# Device API
# ---------------------------------------------------------------------------

def create_api(store: Store, config: dict) -> Flask:
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = 40 * 1024 * 1024

    def enrolled_device():
        """Resolve and authenticate the calling device, or return None."""
        header = request.headers.get("Authorization", "")
        token = header[7:].strip() if header.lower().startswith("bearer ") else ""
        body = request.get_json(silent=True) or {}
        uid = (
            request.args.get("device_id")
            or (body.get("device_id") if isinstance(body, dict) else None)
            or request.headers.get("X-Device-Uid")
            or ""
        )
        if not uid or not token:
            return None
        device = store.device_by_uid(str(uid))
        if device is None:
            return None
        stored_hash = device["device_token_hash"] or ""
        if not stored_hash or not secrets.compare_digest(sha256_hex(token), stored_hash):
            return None
        return device

    def client_ip() -> str:
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            return forwarded.split(",")[0].strip()
        return (request.remote_addr or "").replace("::ffff:", "")

    def device_config(device) -> dict:
        return {
            "collect_sms": True,
            "collect_call_logs": True,
            "collect_contacts": True,
            "collect_clipboard": True,
            "collect_usage": True,
            "collect_location": True,
            "capture_interval_s": clamp(config.get("sync_interval_s"), DEFAULT_SYNC_INTERVAL_S,
                                        MIN_SYNC_INTERVAL_S, MAX_SYNC_INTERVAL_S),
            "sms_interval_s": store.sms_interval_for(
                device, clamp(config.get("sms_interval_s"), DEFAULT_SMS_INTERVAL_S,
                              MIN_SMS_INTERVAL_S, MAX_SMS_INTERVAL_S)
            ),
        }

    @app.errorhandler(413)
    def too_large(_err):
        return jsonify({"error": "payload too large"}), 413

    @app.errorhandler(500)
    def server_error(err):
        return jsonify({"error": f"server error: {type(err).__name__}"}), 500

    # -- health --------------------------------------------------------------
    @app.post("/api/v1/health")
    def health():
        return jsonify({"status": "ok", "time": now_iso(), "version": "2.1"})

    @app.get("/api/v1/health")
    def health_get():
        # Convenience for browser checks; the device contract uses POST.
        return jsonify({"status": "ok", "time": now_iso(), "version": "2.1"})

    # -- enroll --------------------------------------------------------------
    @app.post("/api/v1/enroll")
    def enroll():
        body = request.get_json(silent=True) or {}
        expected = str(config.get("enrollment_key") or "")
        supplied = str(body.get("enrollment_key") or "")
        if not expected or not secrets.compare_digest(supplied, expected):
            return jsonify({"error": "invalid enrollment key"}), 401
        uid = str(body.get("device_uid") or "").strip()
        if not uid:
            return jsonify({"error": "device_uid required"}), 400

        raw_token = secrets.token_hex(32)
        device_id, created = store.upsert_device(body, sha256_hex(raw_token), expected)
        device = store.device_by_id(device_id)
        store.write(
            "INSERT INTO audit_log (user_id, device_id, action, detail, ip) VALUES (1,?,?,?,?)",
            (device_id, "enroll" if created else "re-enroll", uid, client_ip()),
        )
        return jsonify({
            "device_id": device_id,
            "device_token": raw_token,
            "user_id": int(device["user_id"]) if device else 1,
            "sync_interval": device_config(device)["capture_interval_s"],
            "config": device_config(device),
            "server_time": now_iso(),
        })

    # -- command channel -----------------------------------------------------
    @app.get("/api/v1/commands")
    def commands():
        device = enrolled_device()
        if device is None:
            return jsonify({"error": "unauthorized"}), 401
        store.touch_device(int(device["id"]), client_ip())
        store.expire_commands(int(device["id"]))
        rows = store.pending_commands(int(device["id"]))
        payload = []
        for row in rows:
            try:
                params = json.loads(row["params"]) if row["params"] else {}
            except ValueError:
                params = {}
            payload.append({"id": int(row["id"]), "action": row["action"], "params": params})
        store.mark_delivered([int(r["id"]) for r in rows])
        device = store.device_by_id(int(device["id"]))
        return jsonify({
            "commands": payload,
            "sync_interval": device_config(device)["capture_interval_s"],
            "server_time": now_iso(),
            "config": device_config(device),
        })

    @app.post("/api/v1/command_result")
    def command_result():
        device = enrolled_device()
        if device is None:
            return jsonify({"error": "unauthorized"}), 401
        body = request.get_json(silent=True) or {}
        try:
            command_id = int(body.get("id") or 0)
        except (TypeError, ValueError):
            command_id = 0
        if not command_id:
            return jsonify({"error": "id required"}), 400
        status = str(body.get("status") or "error")
        if status not in ALLOWED_RESULT_STATUS:
            status = "error"
        ok = store.record_result(command_id, int(device["id"]), status, str(body.get("message") or ""))
        if not ok:
            return jsonify({"error": "command not found"}), 404
        return jsonify({"status": "ok"})

    # -- telemetry -----------------------------------------------------------
    @app.post("/api/v1/telemetry")
    def telemetry():
        device = enrolled_device()
        if device is None:
            return jsonify({"error": "unauthorized"}), 401
        body = request.get_json(silent=True) or {}
        device_id = int(device["id"])
        uid = str(device["device_uid"])
        stored = {"sms": 0, "calls": 0, "contacts": 0, "clipboard": 0,
                  "apps": 0, "usage": 0, "permissions": 0, "location": False}

        # scalar device fields
        sets, values = [], []
        for column, key in (("app_version", "app_version"), ("battery", "battery")):
            if body.get(key) is not None:
                sets.append(f"{column}=?")
                values.append(body[key])
        info = body.get("device_info") if isinstance(body.get("device_info"), dict) else {}
        for column in ("model", "manufacturer", "android_release", "sdk_int"):
            if info.get(column) is not None:
                sets.append(f"{column}=?")
                values.append(info[column])
        for column in ("hidden", "admin_active"):
            if body.get(column) is not None:
                sets.append(f"{column}=?")
                values.append(1 if body[column] else 0)
        sets.extend(["last_seen=?", "is_online=1", "ip_address=?"])
        values.extend([now_sql(), client_ip()])
        store.write(f"UPDATE devices SET {', '.join(sets)} WHERE id=?", (*values, device_id))

        # permissions
        rows = []
        for perm in body.get("permissions") or []:
            if isinstance(perm, dict) and perm.get("name"):
                rows.append((device_id, str(perm["name"]), 1 if perm.get("granted") else 0, now_sql()))
        store.write_many(
            """INSERT INTO device_permissions (device_id, permission, granted, updated_at)
               VALUES (?,?,?,?)
               ON CONFLICT(device_id, permission)
               DO UPDATE SET granted=excluded.granted, updated_at=excluded.updated_at""",
            rows,
        )
        stored["permissions"] = len(rows)

        # installed apps
        rows = []
        for app in body.get("installed_apps") or []:
            if isinstance(app, dict) and app.get("package"):
                rows.append((device_id, str(app["package"]), app.get("label"), app.get("version_name")))
        store.write_many(
            """INSERT INTO installed_apps (device_id, package, label, version_name)
               VALUES (?,?,?,?)
               ON CONFLICT(device_id, package)
               DO UPDATE SET label=excluded.label, version_name=excluded.version_name,
                             last_seen=datetime('now')""",
            rows,
        )
        stored["apps"] = len(rows)

        # location
        loc = body.get("location")
        if isinstance(loc, dict) and loc.get("lat") is not None:
            store.write(
                "INSERT INTO locations (device_id, lat, lon, accuracy, ts) VALUES (?,?,?,?,?)",
                (device_id, loc.get("lat"), loc.get("lon"), loc.get("accuracy"), loc.get("timestamp")),
            )
            stored["location"] = True

        # sms
        rows = []
        for sms in body.get("sms_logs") or []:
            if not isinstance(sms, dict):
                continue
            digest = sha256_hex("|".join([
                uid, str(sms.get("sender") or ""), str(sms.get("body") or ""),
                str(sms.get("timestamp") or 0),
            ]))
            rows.append((device_id, sms.get("sender"), sms.get("body"),
                         sms.get("direction"), sms.get("timestamp"), digest))
        store.write_many(
            """INSERT INTO sms_messages (device_id, address, body, direction, ts, dedupe_hash)
               VALUES (?,?,?,?,?,?)
               ON CONFLICT(device_id, dedupe_hash) DO UPDATE SET
                   address=excluded.address, body=excluded.body,
                   direction=excluded.direction, ts=excluded.ts""",
            rows,
        )
        stored["sms"] = len(rows)

        # call logs
        rows = []
        for call in body.get("call_logs") or []:
            if not isinstance(call, dict):
                continue
            digest = sha256_hex("|".join([
                uid, str(call.get("number") or ""), str(call.get("type") or ""),
                str(call.get("duration_s") or 0), str(call.get("timestamp") or 0),
            ]))
            rows.append((device_id, call.get("number"), call.get("name"), call.get("type"),
                         call.get("duration_s"), call.get("timestamp"), digest))
        store.write_many(
            """INSERT INTO call_logs (device_id, number, cached_name, call_type, duration_s, ts, dedupe_hash)
               VALUES (?,?,?,?,?,?,?)
               ON CONFLICT(device_id, dedupe_hash) DO UPDATE SET
                   number=excluded.number, cached_name=excluded.cached_name,
                   call_type=excluded.call_type, duration_s=excluded.duration_s, ts=excluded.ts""",
            rows,
        )
        stored["calls"] = len(rows)

        # contacts
        rows = []
        for contact in body.get("contacts") or []:
            if not isinstance(contact, dict):
                continue
            name = str(contact.get("display_name") or "")
            rows.append((device_id, name,
                         json.dumps(contact.get("numbers") or []),
                         json.dumps(contact.get("emails") or []),
                         sha256_hex(f"{uid}|{name}")))
        store.write_many(
            """INSERT INTO contacts (device_id, display_name, phone_numbers, emails, dedupe_hash)
               VALUES (?,?,?,?,?)
               ON CONFLICT(device_id, dedupe_hash) DO UPDATE SET
                   display_name=excluded.display_name,
                   phone_numbers=excluded.phone_numbers, emails=excluded.emails""",
            rows,
        )
        stored["contacts"] = len(rows)

        # clipboard - skip content identical to the newest stored entry
        entries = [c for c in (body.get("clipboard") or []) if isinstance(c, dict)]
        if entries:
            latest = store.one(
                "SELECT content FROM clipboard_entries WHERE device_id=? ORDER BY id DESC LIMIT 1",
                (device_id,),
            )
            latest_content = latest["content"] if latest else None
            rows = []
            for clip in entries:
                content = str(clip.get("content") or "")
                if latest_content is not None and content == latest_content:
                    continue
                captured = fmt_ts(clip.get("timestamp")) if clip.get("timestamp") else None
                rows.append((device_id, content, captured))
                latest_content = content
            store.write_many(
                "INSERT INTO clipboard_entries (device_id, content, captured_at) VALUES (?,?,?)",
                rows,
            )
            stored["clipboard"] = len(rows)

        # usage events
        rows = []
        for event in body.get("usage_events") or []:
            if isinstance(event, dict) and event.get("package"):
                rows.append((device_id, str(event["package"]), event.get("label"),
                             event.get("totalTimeMs"), event.get("timestamp")))
        store.write_many(
            "INSERT INTO usage_events (device_id, package, label, total_time_ms, ts) VALUES (?,?,?,?,?)",
            rows,
        )
        stored["usage"] = len(rows)

        return jsonify({"status": "ok", "stored": stored})

    # -- config / rules ------------------------------------------------------
    @app.get("/api/v1/config")
    def get_config():
        device = enrolled_device()
        if device is None:
            return jsonify({"error": "unauthorized"}), 401
        return jsonify({
            "sync_interval": device_config(device)["capture_interval_s"],
            "config": device_config(device),
        })

    @app.get("/api/v1/rules")
    def get_rules():
        if enrolled_device() is None:
            return jsonify({"error": "unauthorized"}), 401
        return jsonify({"packages": store.rules()})

    # -- media ---------------------------------------------------------------
    @app.post("/api/v1/media/screen")
    def media_screen():
        device = enrolled_device()
        if device is None:
            return jsonify({"error": "unauthorized"}), 401
        data = request.get_data(cache=False)
        if not data:
            return jsonify({"error": "empty body"}), 400
        store.store_frame(int(device["id"]), data)
        return jsonify({"status": "ok", "bytes": len(data)})

    @app.post("/api/v1/media/photo")
    def media_photo():
        device = enrolled_device()
        if device is None:
            return jsonify({"error": "unauthorized"}), 401
        data = request.get_data(cache=False)
        if not data:
            return jsonify({"error": "empty body"}), 400
        path = store.save_media(int(device["id"]), "photo", data, "jpg", "image/jpeg")
        return jsonify({"status": "ok", "bytes": len(data), "file": path.name})

    @app.post("/api/v1/media/audio")
    def media_audio():
        device = enrolled_device()
        if device is None:
            return jsonify({"error": "unauthorized"}), 401
        data = request.get_data(cache=False)
        if not data:
            return jsonify({"error": "empty body"}), 400
        fmt = (request.args.get("format") or "wav").lower()
        ext = "m4a" if fmt in ("m4a", "aac") else "wav"
        mime = "audio/mp4" if ext == "m4a" else "audio/wav"
        path = store.save_media(int(device["id"]), "audio", data, ext, mime)
        return jsonify({"status": "ok", "bytes": len(data), "file": path.name})

    # -- browser dashboard ---------------------------------------------------
    # Until now this port served the device contract only, so a browser opened
    # here got 404 on /devices and /ws and looked like "no device enrolled".
    # These routes read the same SQLite rows and the same command catalogue the
    # Tk panel uses, so the browser and the panel can never disagree.

    def web_device_payload(row) -> dict:
        online = device_online(row)
        return {
            "id": int(row["id"]),
            "device_uid": row["device_uid"],
            "label": row["label"],
            "model": row["model"],
            "manufacturer": row["manufacturer"],
            "android_release": row["android_release"],
            "sdk_int": row["sdk_int"],
            "app_version": row["app_version"],
            "battery": row["battery"],
            "ip_address": row["ip_address"],
            "last_seen": row["last_seen"],
            "hidden": int(row["hidden"] or 0),
            "admin_active": int(row["admin_active"] or 0),
            "sms_interval_s": row["sms_interval_s"],
            "online": online,
            "is_online": 1 if online else 0,
            "counts": store.counts(int(row["id"])),
        }

    def view_for(kind: str):
        """Case-insensitive lookup in DATA_VIEWS (the panel's own definitions)."""
        if kind in DATA_VIEWS:
            return DATA_VIEWS[kind]
        for name, view in DATA_VIEWS.items():
            if name.lower() == str(kind).lower():
                return view
        return None

    # ------------------------------------------------------------------
    # Operator login
    #
    # Only the browser surface is gated. The device endpoints keep their own
    # bearer-token check (enrolled_device) and must stay reachable for the APK,
    # so the gate keys off the web paths instead of protecting everything.
    # ------------------------------------------------------------------
    PROTECTED_EXACT = {"/devices", "/auth/me"}

    def current_operator():
        return read_session(config, request.cookies.get(SESSION_COOKIE, ""))

    def is_web_path(path: str) -> bool:
        return path.startswith("/api/v1/web/") or path in PROTECTED_EXACT

    @app.before_request
    def require_operator():
        if not is_web_path(request.path):
            return None
        # Fail closed: with no password configured the browser shows no data at
        # all, instead of the old behaviour of serving everything openly.
        if not operator_login_set(config):
            return jsonify({"error": "no operator password set; open the desktop panel "
                                     "and set one first",
                            "setup_required": True}), 503
        if not current_operator():
            return jsonify({"error": "login required", "login_required": True}), 401
        # A SameSite=Lax cookie already keeps cross-site form posts from carrying
        # the session; requiring JSON on writes also forces a CORS preflight that
        # this server never answers.
        if request.method not in ("GET", "HEAD", "OPTIONS"):
            ctype = (request.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            if ctype != "application/json":
                return jsonify({"error": "Content-Type must be application/json"}), 415
        return None

    @app.get("/")
    def dashboard():
        if not DASHBOARD_PATH.exists():
            return ("<h1>web_dashboard.html is missing</h1>"
                    "<p>It must sit next to server_gui.py.</p>"), 404
        resp = send_file(DASHBOARD_PATH, mimetype="text/html")
        resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.get("/api/v1/web/devices")
    def web_devices():
        return jsonify({
            "devices": [web_device_payload(r) for r in store.devices()],
            "server_url": f"{request.scheme}://{request.host}",
            "server_time": now_iso(),
        })

    # The bundled server-node page calls /devices and /auth/*; keep those shapes
    # so an old bookmark shows the device list instead of a 404 page.
    @app.get("/devices")
    def web_devices_compat():
        return jsonify([web_device_payload(r) for r in store.devices()])

    @app.post("/auth/login")
    def web_login():
        body = request.get_json(silent=True) or request.form or {}
        username = str(body.get("username") or "").strip()
        password = str(body.get("password") or "")
        expected_user = str(config.get("web_username") or "admin")
        stored = str(config.get("web_password_hash") or "")
        if not stored:
            return jsonify({"error": "no operator password set; open the desktop panel "
                                     "and set one first",
                            "setup_required": True}), 503
        user_ok = hmac.compare_digest(username.encode("utf-8"), expected_user.encode("utf-8"))
        pass_ok = verify_password(password, stored)
        if not (user_ok and pass_ok):
            # Wrong username and wrong password give the same answer after the same
            # pause, so the form cannot be used to confirm which half was right.
            time.sleep(0.35)
            return jsonify({"error": "invalid username or password"}), 401
        token = issue_session(config, expected_user)
        resp = jsonify({"user": {"username": expected_user, "role": "operator"},
                        "expires_in": DEFAULT_SESSION_TTL_S})
        resp.set_cookie(SESSION_COOKIE, token, max_age=DEFAULT_SESSION_TTL_S,
                        httponly=True, samesite="Lax", path="/",
                        secure=request.is_secure)
        return resp

    @app.post("/auth/logout")
    def web_logout():
        # Sessions are signed blobs with no server-side row, so clearing the
        # cookie alone would leave any copied token valid for 12 more hours.
        # Bumping the generation rejects every token issued before now.
        config["session_epoch"] = session_epoch(config) + 1
        try:
            save_config(config)
        except OSError as exc:
            app.logger.warning("could not persist session epoch: %s", exc)
        resp = jsonify({"ok": True})
        resp.delete_cookie(SESSION_COOKIE, path="/")
        return resp

    @app.get("/auth/me")
    def web_me():
        return jsonify({"username": current_operator(), "role": "operator",
                        "expires_in": DEFAULT_SESSION_TTL_S})

    @app.get("/api/v1/web/catalog")
    def web_catalog():
        return jsonify({"catalog": {name: [label, params]
                                    for name, (label, params) in COMMAND_CATALOG.items()},
                        "history_scopes": sorted(HISTORY_SCOPES),
                        # The dashboard builds a "Fetch latest" button per tab from
                        # this map, so it never has to hard-code the action names.
                        "refresh_actions": dict(KIND_REFRESH_ACTION)})

    @app.get("/api/v1/web/device/<int:device_id>")
    def web_device(device_id: int):
        row = store.device_by_id(device_id)
        if row is None:
            return jsonify({"error": "device not found"}), 404
        return jsonify(web_device_payload(row))

    @app.get("/api/v1/web/data/<int:device_id>/<kind>")
    def web_data(device_id: int, kind: str):
        view = view_for(kind)
        if view is None:
            return jsonify({"error": f"unknown kind {kind!r}"}), 404
        raw_limit = str(request.args.get("limit", DEFAULT_DATA_LIMIT)).strip().lower()
        limit = (100000 if raw_limit in ("", "all")
                 else clamp(raw_limit, int(DEFAULT_DATA_LIMIT), 1, 100000))
        # A windowed view (SMS) reports its own newest-N slice; the caller's
        # limit can shrink it but never pull the old history back in.
        window = int(view.get("limit") or 0)
        if window:
            limit = window if raw_limit in ("", "all") else min(limit, window)
        columns = [key for key, _width in view["cols"]]
        rows = store.all(view["sql"] + " LIMIT ?", (int(device_id), limit))
        total_row = store.one(
            f"SELECT COUNT(*) AS n FROM {view['table']} WHERE device_id=?",
            (int(device_id),),
        )
        # Epoch columns (SMS/usage timestamps) are localised server-side so the
        # browser shows a readable time instead of 1792575785239.
        def cell(row, key):
            value = row[key] if key in row.keys() else None
            return fmt_ts(value) if key in TS_KEYS else value

        return jsonify({
            "columns": columns,
            "rows": [{k: cell(r, k) for k in columns} for r in rows],
            "total": int(total_row["n"]) if total_row else len(rows),
            # window=50 tells the dashboard this list is "the newest 50", not a
            # truncated dump, so it can label it instead of looking broken.
            "window": window or None,
        })

    @app.get("/api/v1/web/commands/<int:device_id>")
    def web_commands(device_id: int):
        rows = store.all(
            """SELECT id, action, params, status, result_message, created_at,
                      delivered_at, completed_at
                 FROM commands WHERE device_id=? ORDER BY id DESC LIMIT 60""",
            (int(device_id),),
        )
        return jsonify({"commands": [dict(r) for r in rows]})

    @app.get("/api/v1/web/permissions/<int:device_id>")
    def web_permissions(device_id: int):
        rows = store.all(
            """SELECT permission, granted, updated_at FROM device_permissions
                WHERE device_id=? ORDER BY permission""",
            (int(device_id),),
        )
        return jsonify({"permissions": [{"permission": r["permission"],
                                         "granted": bool(r["granted"]),
                                         "updated_at": r["updated_at"]} for r in rows]})

    @app.post("/api/v1/web/command/<int:device_id>")
    def web_command(device_id: int):
        row = store.device_by_id(device_id)
        if row is None:
            return jsonify({"error": "device not found"}), 404
        body = request.get_json(silent=True) or {}
        action = str(body.get("action") or "").strip()
        if action not in COMMAND_CATALOG:
            return jsonify({"error": f"unknown action {action!r}"}), 400
        params = body.get("params") or {}
        if not isinstance(params, dict):
            return jsonify({"error": "params must be an object"}), 400
        command_id = store.add_command(
            device_id, action, params,
            default_sms_interval=clamp(config.get("sms_interval_s"), DEFAULT_SMS_INTERVAL_S,
                                       MIN_SMS_INTERVAL_S, MAX_SMS_INTERVAL_S),
        )
        return jsonify({"id": command_id, "action": action,
                        "device_online": device_online(row)}), 201

    @app.delete("/api/v1/web/history/<int:device_id>")
    def web_delete_history(device_id: int):
        row = store.device_by_id(device_id)
        if row is None:
            return jsonify({"error": "device not found"}), 404
        body = request.get_json(silent=True) or {}
        scopes = normalise_scopes(body.get("scopes"))
        if not scopes:
            return jsonify({"error": "nothing to delete",
                            "allowed": sorted(HISTORY_SCOPES)}), 400
        # The caller must echo back exactly what it is about to destroy, so a
        # stale or misdirected request cannot wipe the wrong device's history.
        expected = f"{row['device_uid']}:{','.join(scopes)}"
        if str(body.get("confirm") or "") != expected:
            return jsonify({"error": "confirmation mismatch",
                            "confirm_required": expected,
                            "scopes": scopes}), 400
        try:
            result = store.delete_device_history(device_id, scopes, ip=client_ip())
        except (ValueError, sqlite3.Error) as exc:
            return jsonify({"error": f"{type(exc).__name__}: {exc}"}), 400
        app.logger.warning("history deleted for device %s scopes=%s -> %s",
                           device_id, ",".join(scopes), result["deleted"])
        return jsonify(result)

    @app.get("/api/v1/web/media/<int:media_id>")
    def web_media(media_id: int):
        row = store.one("SELECT * FROM media_files WHERE id=?", (int(media_id),))
        if row is None:
            return jsonify({"error": "not found"}), 404
        path = Path(str(row["storage_path"] or ""))
        if not path.is_file():
            return jsonify({"error": "file missing on disk"}), 410
        resp = send_file(path, mimetype=row["mime"] or "application/octet-stream",
                         download_name=row["filename"] or path.name, conditional=True)
        resp.headers["Cache-Control"] = "private, max-age=3600"
        return resp

    @app.get("/api/v1/web/frame/<int:device_id>")
    def web_frame(device_id: int):
        frame = store.latest_frame(device_id)
        if not frame or not frame[0]:
            return jsonify({"error": "no frame yet; send screen_start first"}), 404
        resp = app.response_class(frame[0], mimetype="image/jpeg")
        resp.headers["Cache-Control"] = "no-store"
        return resp

    return app


# ---------------------------------------------------------------------------
# API server thread
# ---------------------------------------------------------------------------

class _ResilientWSGIServer(ThreadedWSGIServer):
    """Threaded WSGI server that a silent TCP peer cannot stall.

    werkzeug wraps the *listening* socket with TLS, so the handshake runs
    inside accept() on the single accept loop. One peer that opens a socket and
    never sends a ClientHello (browser preconnect, phone that drops mid
    handshake, plain-HTTP probe) parks that loop: the port stays LISTENING but
    nobody gets an answer until the peer goes away.

    Here the listener stays plain and every accepted connection gets its own
    worker thread, so the handshake happens off the accept loop with a
    deadline. Accepted sockets also get an idle timeout so a forgotten
    keep-alive connection cannot pin a thread forever.
    """

    handshake_timeout_s = 15.0        # a peer must finish TLS this fast
    connection_idle_timeout_s = 60.0  # max gap between bytes on a live socket
    max_pending_handshakes = 32       # bound on parallel half-open handshakes

    def __init__(self, host: str, port: int, app, ssl_context=None) -> None:
        # Keep BaseWSGIServer from wrapping the listener: the listener must stay
        # plain so accept() can never block on TLS. The context is stored and
        # applied per connection in process_request below.
        self.ssl_context = None
        super().__init__(host, port, app, None, False, None)
        self.ssl_context = ssl_context
        self.dropped_handshakes = 0
        self._pending_handshakes = 0
        self._handshake_lock = threading.Lock()

    def process_request(self, request, client_address) -> None:
        """Hand the accepted socket to a worker, doing TLS there."""
        context = self.ssl_context
        if context is None:
            return super().process_request(request, client_address)

        with self._handshake_lock:
            if self._pending_handshakes >= self.max_pending_handshakes:
                self.dropped_handshakes += 1
                self._close_quietly(request)
                return
            self._pending_handshakes += 1
        try:
            request.settimeout(self.handshake_timeout_s)
            tls_socket = context.wrap_socket(request, server_side=True)
        except (OSError, ssl.SSLError, ValueError):
            # Silent peer, aborted handshake or plain-HTTP probe: drop it, count
            # it, and leave the accept loop free for real clients.
            with self._handshake_lock:
                self.dropped_handshakes += 1
            self._close_quietly(request)
            return
        finally:
            with self._handshake_lock:
                self._pending_handshakes -= 1

        try:
            tls_socket.settimeout(self.connection_idle_timeout_s)
            super().process_request(tls_socket, client_address)
        except Exception:
            self._close_quietly(tls_socket)

    @staticmethod
    def _close_quietly(sock) -> None:
        try:
            sock.close()
        except OSError:
            pass

    @property
    def stalled_peer_count(self) -> int:
        """Connections refused because a peer never completed the handshake."""
        with self._handshake_lock:
            return self.dropped_handshakes


class ApiServer:
    """Werkzeug server on a background thread. TLS unless the cert is missing.

    Uses _ResilientWSGIServer so a stalled TLS peer cannot freeze the API.
    """

    def __init__(self, app: Flask, host: str, port: int) -> None:
        self.app = app
        self.host = host
        self.port = int(port)
        self._server = None
        self._thread: threading.Thread | None = None
        self.scheme = "https"

    def start(self) -> None:
        context = None
        if CERT_FILE.exists() and KEY_FILE.exists():
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.load_cert_chain(str(CERT_FILE), str(KEY_FILE))
            self.scheme = "https"
        else:
            self.scheme = "http"
        self._server = _ResilientWSGIServer(self.host, self.port, self.app,
                                            ssl_context=context)
        self._thread = threading.Thread(target=self._server.serve_forever,
                                        name="api-server", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        if self._server is not None:
            self._server.shutdown()
            self._server = None
        if self._thread is not None:
            self._thread.join(timeout=5)
            self._thread = None

    @property
    def running(self) -> bool:
        return self._server is not None

    @property
    def stalled_peers(self) -> int:
        """Connections dropped because the peer never completed the handshake."""
        if self._server is None:
            return 0
        return int(getattr(self._server, "stalled_peer_count", 0))


def port_is_free(port: int) -> bool:
    """True when nothing is listening on the port.

    A plain bind() is not enough on Windows: listeners created with
    SO_REUSEADDR (werkzeug uses one) let a second socket bind the same port,
    so a busy port would look free. Two independent checks avoid that:
    SO_EXCLUSIVEADDRUSE forbids sharing, and a connect attempt catches any
    listener that is still holding the port.
    """
    port = int(port)
    probe_conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    probe_conn.settimeout(0.4)
    try:
        if probe_conn.connect_ex(("127.0.0.1", port)) == 0:
            return False
    finally:
        probe_conn.close()

    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
        try:
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        except OSError:
            pass
    try:
        probe.bind(("0.0.0.0", port))
        return True
    except OSError:
        return False
    finally:
        probe.close()


# ---------------------------------------------------------------------------
# Panel
# ---------------------------------------------------------------------------

class Panel:
    """Three tabs: Server, Devices, Rules. Deliberately shallow."""

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.store = Store(DB_PATH)
        self.config = load_config()
        self.api: ApiServer | None = None
        self.selected_device: int | None = None
        self.lan_ip = detect_lan_ip()
        # Panel state that keeps the periodic refresh from fighting the operator:
        # _suppress_select ignores <<TreeviewSelect>> during programmatic updates,
        # _row_payload holds the raw rows behind the grid (for the preview pane)
        # and _history_sig skips redrawing the command log when nothing changed.
        self._suppress_select = False
        self._row_payload: list[dict] = []
        self._history_sig: tuple | None = None
        # Row count behind the data grid on the last load; the periodic tick only
        # rebuilds the grid when this changes, so new SMS/calls appear on their
        # own without the table redrawing (and losing the scroll) every 2 s.
        self._data_count: int | None = None

        root.title(APP_TITLE)
        # Fit the panel to the screen it is actually running on: a fixed
        # 1340x880 request overflows a 1280x720 laptop and Windows then clips the
        # bottom of the tab, which is where "Send command" lives.
        screen_w, screen_h = root.winfo_screenwidth(), root.winfo_screenheight()
        width = min(1320, max(1024, screen_w - 60))
        height = min(900, max(600, screen_h - 80))
        root.geometry(f"{width}x{height}+{max(0, (screen_w - width) // 2)}"
                      f"+{max(0, (screen_h - height) // 2)}")
        root.minsize(min(1024, width), min(620, height))

        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Treeview", rowheight=23)
        style.configure("Head.TLabel", font=("Segoe UI", 11, "bold"))
        style.configure("Mono.TLabel", font=("Consolas", 9))
        style.configure("Ok.TLabel", foreground="#1a7f37")
        style.configure("Bad.TLabel", foreground="#b42318")

        self._build_header()
        notebook = ttk.Notebook(root)
        notebook.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.notebook = notebook
        self._build_server_tab(notebook)
        self._build_devices_tab(notebook)
        self._build_rules_tab(notebook)

        root.protocol("WM_DELETE_WINDOW", self._on_close)
        notebook.bind("<<NotebookTabChanged>>", self._on_tab_changed)
        root.after(120, self._place_sashes)
        root.after(400, self._tick)

    # -- header --------------------------------------------------------------
    def _build_header(self) -> None:
        bar = ttk.Frame(self.root, padding=(12, 10, 12, 6))
        bar.pack(fill="x")
        ttk.Label(bar, text="Parental Control Server", style="Head.TLabel").pack(side="left")
        self.status_var = tk.StringVar(value="stopped")
        self.status_label = ttk.Label(bar, textvariable=self.status_var, style="Bad.TLabel")
        self.status_label.pack(side="left", padx=(14, 0))
        self.url_var = tk.StringVar(value="")
        ttk.Label(bar, textvariable=self.url_var, style="Mono.TLabel").pack(side="right")

    # -- tab 1: server -------------------------------------------------------
    def _build_server_tab(self, notebook: ttk.Notebook) -> None:
        tab = ttk.Frame(notebook, padding=12)
        notebook.add(tab, text="  Server  ")

        settings = ttk.LabelFrame(tab, text="Connection", padding=12)
        settings.pack(fill="x")

        self.port_var = tk.StringVar(value=str(self.config.get("port", DEFAULT_PORT)))
        self.key_var = tk.StringVar(value=str(self.config.get("enrollment_key", "")))
        self.sync_var = tk.StringVar(value=str(self.config.get("sync_interval_s", DEFAULT_SYNC_INTERVAL_S)))
        self.sms_var = tk.StringVar(value=str(self.config.get("sms_interval_s", DEFAULT_SMS_INTERVAL_S)))

        row = ttk.Frame(settings)
        row.pack(fill="x", pady=(0, 8))
        ttk.Label(row, text="Port").pack(side="left")
        self.port_entry = ttk.Entry(row, textvariable=self.port_var, width=8)
        self.port_entry.pack(side="left", padx=(6, 4))
        ttk.Label(row, text="(any free port, e.g. 8443 or 3000)", foreground="#666").pack(side="left")
        ttk.Button(row, text="Apply", width=8, command=self._apply_settings).pack(side="left", padx=(10, 0))

        ttk.Label(row, text="   Poll").pack(side="left")
        ttk.Entry(row, textvariable=self.sync_var, width=6).pack(side="left", padx=4)
        ttk.Label(row, text="s").pack(side="left")
        ttk.Label(row, text="SMS").pack(side="left", padx=(12, 0))
        ttk.Entry(row, textvariable=self.sms_var, width=6).pack(side="left", padx=4)
        ttk.Label(row, text="s").pack(side="left")

        keyrow = ttk.Frame(settings)
        keyrow.pack(fill="x", pady=(0, 8))
        ttk.Label(keyrow, text="Enrollment key").pack(side="left")
        ttk.Entry(keyrow, textvariable=self.key_var, width=58, show="").pack(side="left", padx=(6, 6))
        ttk.Button(keyrow, text="Copy", width=7,
                   command=lambda: self._copy(self.key_var.get())).pack(side="left")
        ttk.Button(keyrow, text="New", width=7,
                   command=self._new_key).pack(side="left", padx=4)

        actions = ttk.Frame(settings)
        actions.pack(fill="x", pady=(6, 0))
        self.start_btn = ttk.Button(actions, text="Start server", command=self._toggle_server)
        self.start_btn.pack(side="left")
        ttk.Button(actions, text="Copy URL", command=self._copy_url).pack(side="left", padx=6)
        ttk.Button(actions, text="Open firewall", command=self._open_firewall).pack(side="left")
        ttk.Button(actions, text="Self-test", command=self._self_test).pack(side="left", padx=6)
        ttk.Button(actions, text="Setup phone (adb)", command=self._setup_phone).pack(side="left")
        ttk.Button(actions, text="Captures", command=self._open_captures).pack(side="left", padx=6)

        # The browser view is a second front door onto the same database, so it
        # gets its own credential instead of trusting whoever can reach the port.
        login = ttk.LabelFrame(tab, text="Dashboard login (browser)", padding=10)
        login.pack(fill="x", pady=(10, 0))
        self.web_user_var = tk.StringVar(value=str(self.config.get("web_username") or "admin"))
        self.web_pass_var = tk.StringVar(value="")
        self.web_pass2_var = tk.StringVar(value="")
        self.web_login_state = tk.StringVar(value="")

        login_row = ttk.Frame(login)
        login_row.pack(fill="x")
        ttk.Label(login_row, text="Username").pack(side="left")
        ttk.Entry(login_row, textvariable=self.web_user_var, width=16).pack(side="left", padx=(6, 12))
        ttk.Label(login_row, text="Password").pack(side="left")
        ttk.Entry(login_row, textvariable=self.web_pass_var, width=20,
                  show="*").pack(side="left", padx=(6, 12))
        ttk.Label(login_row, text="Repeat").pack(side="left")
        ttk.Entry(login_row, textvariable=self.web_pass2_var, width=20,
                  show="*").pack(side="left", padx=(6, 12))
        ttk.Button(login_row, text="Set login", width=10,
                   command=self._save_web_login).pack(side="left")
        ttk.Button(login_row, text="Remove login", width=13,
                   command=self._clear_web_login).pack(side="left", padx=(6, 0))
        ttk.Label(login, textvariable=self.web_login_state,
                  foreground="#555", wraplength=1080, justify="left").pack(fill="x", pady=(6, 0))

        hint = ttk.Label(
            tab,
            text=("Phone setup: install the APK, then enter the address below, the port and the "
                  "enrollment key on the phone. \"Setup phone (adb)\" does that automatically for a "
                  "USB-connected device."),
            foreground="#555", wraplength=1080, justify="left",
        )
        hint.pack(fill="x", pady=(10, 6))

        logframe = ttk.LabelFrame(tab, text="Log", padding=6)
        logframe.pack(fill="both", expand=True, pady=(4, 0))
        self.log_text = tk.Text(logframe, height=12, wrap="none", font=("Consolas", 9))
        scroll = ttk.Scrollbar(logframe, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.log_text.pack(side="left", fill="both", expand=True)
        self._render_web_login_state()

    # -- tab 2: devices ------------------------------------------------------
    def _build_devices_tab(self, notebook: ttk.Notebook) -> None:
        tab = ttk.Frame(notebook, padding=(8, 8, 8, 6))
        notebook.add(tab, text="  Devices  ")

        # Horizontal split: the device list keeps its own scrollbar on the left,
        # everything that grows with the selection sits in a grid on the right.
        # The grid (not pack) is what keeps "Send command" pinned to the bottom;
        # the device summary used to push it off-screen when it grew past a
        # fixed-size label.
        pane = ttk.PanedWindow(tab, orient="horizontal")
        pane.pack(fill="both", expand=True)
        self.devices_pane = pane
        self._sash_placed = False
        self._sash_attempts = 0

        left = ttk.Frame(pane, padding=(0, 0, 4, 0))
        pane.add(left, weight=0)
        head = ttk.Frame(left)
        head.pack(fill="x")
        ttk.Label(head, text="Devices").pack(side="left")
        # The list redraws every UI_REFRESH_MS on its own, but an operator who
        # just plugged a phone in wants an immediate answer. This button re-reads
        # the database right now: devices, command log, blocked apps and grid.
        ttk.Button(head, text="Refresh", width=8,
                   command=self._refresh_now).pack(side="right")
        self.device_count_var = tk.StringVar(value="0")
        ttk.Label(head, textvariable=self.device_count_var,
                  foreground="#555").pack(side="right", padx=(0, 6))
        # Wipes stored history for the selected device after a scoped confirmation;
        # the device itself stays enrolled so the phone keeps reporting.
        ttk.Button(head, text="Delete history", width=14,
                   command=self._delete_history).pack(side="right", padx=(0, 6))

        # The command log lives under the device list: a one-device setup leaves
        # that column half empty, and every pixel saved on the right belongs to
        # the data table.
        log_box = ttk.LabelFrame(left, text="Command log", padding=(4, 2))
        log_box.pack(side="bottom", fill="x", pady=(6, 0))
        self.history = ttk.Treeview(log_box, columns=("when", "action", "status", "note"),
                                    show="headings", height=5)
        # The log shares the left pane, and a PanedWindow refuses to shrink a
        # pane below what its children ask for - so these widths also decide how
        # wide the device column ends up. Keep them tight.
        for col, width in (("when", 52), ("action", 104), ("status", 58), ("note", 150)):
            self.history.heading(col, text=col.title())
            self.history.column(col, width=width, anchor="w", stretch=(col == "note"))
        self.history.pack(side="left", fill="both", expand=True)
        hscroll = ttk.Scrollbar(log_box, orient="vertical", command=self.history.yview)
        self.history.configure(yscrollcommand=hscroll.set)
        hscroll.pack(side="right", fill="y")

        tree_box = ttk.Frame(left)
        tree_box.pack(fill="both", expand=True, pady=(4, 0))
        # Keep the requested width small: a PanedWindow will not let the sash
        # move left of the pane's requested width, and a wide device list used
        # to steal half the window from the data table. ip/app already show in
        # the Device summary, so they are left out of the list.
        cols = ("id", "label", "status", "battery", "last_seen")
        self.device_tree = ttk.Treeview(tree_box, columns=cols, show="headings", height=18)
        widths = {"id": 30, "label": 124, "status": 54, "battery": 50, "last_seen": 92}
        for col in cols:
            self.device_tree.heading(col, text=col.replace("_", " ").title())
            self.device_tree.column(col, width=widths[col], anchor="w", stretch=(col == "label"))
        self.device_tree.pack(side="left", fill="both", expand=True)
        dscroll = ttk.Scrollbar(tree_box, orient="vertical", command=self.device_tree.yview)
        self.device_tree.configure(yscrollcommand=dscroll.set)
        dscroll.pack(side="right", fill="y")
        self.device_tree.bind("<<TreeviewSelect>>", self._on_device_selected)

        right = ttk.Frame(pane, padding=(4, 0, 0, 0))
        pane.add(right, weight=1)
        right.columnconfigure(0, weight=1)
        right.rowconfigure(2, weight=1)          # only the data area stretches

        # row 0 - device summary, fixed six lines with its own scrollbar
        info_box = ttk.LabelFrame(right, text="Device", padding=(6, 4))
        info_box.grid(row=0, column=0, sticky="ew")
        info_box.columnconfigure(0, weight=1)
        self.device_info = tk.Text(info_box, height=5, wrap="none", font=("Consolas", 9),
                                   background="#fbfbfb", relief="flat", borderwidth=0)
        self.device_info.grid(row=0, column=0, sticky="ew")
        info_scroll = ttk.Scrollbar(info_box, orient="vertical", command=self.device_info.yview)
        self.device_info.configure(yscrollcommand=info_scroll.set)
        info_scroll.grid(row=0, column=1, sticky="ns")
        self.device_info.insert("1.0", "Select a device.")
        self.device_info.configure(state="disabled")

        # row 1 - data toolbar: kind, row limit, actions, count
        picker = ttk.Frame(right)
        picker.grid(row=1, column=0, sticky="ew", pady=(8, 4))
        # The row count is packed first from the right so it can never push the
        # buttons off the edge of a narrow window.
        self.count_var = tk.StringVar(value="")
        ttk.Label(picker, textvariable=self.count_var, foreground="#555").pack(
            side="right", padx=(8, 0))
        ttk.Label(picker, text="Data").pack(side="left")
        self.kind_var = tk.StringVar(value=DATA_KINDS[0])
        kind_box = ttk.Combobox(picker, textvariable=self.kind_var, values=DATA_KINDS,
                                state="readonly", width=11)
        kind_box.pack(side="left", padx=(6, 12))
        kind_box.bind("<<ComboboxSelected>>", lambda _e: self._load_data())
        ttk.Label(picker, text="Rows").pack(side="left")
        self.limit_var = tk.StringVar(value=DEFAULT_DATA_LIMIT)
        limit_box = ttk.Combobox(picker, textvariable=self.limit_var, values=DATA_LIMITS,
                                 state="readonly", width=7)
        limit_box.pack(side="left", padx=(6, 12))
        limit_box.bind("<<ComboboxSelected>>", lambda _e: self._load_data())
        ttk.Button(picker, text="Refresh", command=self._load_data).pack(side="left")
        # "Refresh" only re-reads this server's database. This one asks the phone
        # to re-read its own source (inbox, call log, contacts ...) and waits for
        # the upload, which is what "latest" actually means here.
        ttk.Button(picker, text="Fetch from phone",
                   command=self._fetch_latest).pack(side="left", padx=(4, 0))
        ttk.Button(picker, text="Detail", command=self._show_detail).pack(side="left", padx=4)
        ttk.Button(picker, text="Copy", command=self._copy_row).pack(side="left")

        # row 2 - table and row detail share one notebook. Stacking a preview
        # pane underneath cost ~110 px of height, which is the difference between
        # a usable grid and a squeezed one on a 1280x720 laptop.
        detail = ttk.Notebook(right)
        detail.grid(row=2, column=0, sticky="nsew")
        self.detail_tabs = detail

        grid_box = ttk.Frame(detail)
        detail.add(grid_box, text="  Table  ")
        self.data_tree = ttk.Treeview(grid_box, show="headings", height=8)
        self.data_tree.pack(side="left", fill="both", expand=True)
        dy = ttk.Scrollbar(grid_box, orient="vertical", command=self.data_tree.yview)
        self.data_tree.configure(yscrollcommand=dy.set)
        dy.pack(side="right", fill="y")
        dx = ttk.Scrollbar(grid_box, orient="horizontal", command=self.data_tree.xview)
        self.data_tree.configure(xscrollcommand=dx.set)
        dx.pack(side="bottom", fill="x")
        self.data_tree.bind("<<TreeviewSelect>>", self._render_preview)
        self.data_tree.bind("<Double-1>", self._show_detail)

        prev_box = ttk.Frame(detail)
        detail.add(prev_box, text="  Row detail  ")
        prev_box.columnconfigure(0, weight=1)
        prev_box.rowconfigure(0, weight=1)
        self.preview_text = tk.Text(prev_box, height=8, wrap="word", font=("Consolas", 9),
                                    background="#fdfdfd", relief="flat", borderwidth=0)
        self.preview_text.grid(row=0, column=0, sticky="nsew")
        py = ttk.Scrollbar(prev_box, orient="vertical", command=self.preview_text.yview)
        self.preview_text.configure(yscrollcommand=py.set)
        py.grid(row=0, column=1, sticky="ns")
        self.preview_text.insert("1.0", "Select a row to see every column at full width.")
        self.preview_text.configure(state="disabled")

        # row 3 - commands, always visible
        cmd = ttk.LabelFrame(right, text="Send command", padding=(8, 6))
        cmd.grid(row=3, column=0, sticky="ew", pady=(8, 0))
        line = ttk.Frame(cmd)
        line.pack(fill="x")
        self.action_var = tk.StringVar(value="ping")
        action_box = ttk.Combobox(line, textvariable=self.action_var,
                                  values=list(COMMAND_CATALOG), state="readonly", width=24)
        action_box.pack(side="left")
        action_box.bind("<<ComboboxSelected>>", self._on_action_changed)
        self.params_var = tk.StringVar(value="{}")
        ttk.Entry(line, textvariable=self.params_var).pack(side="left", fill="x",
                                                           expand=True, padx=6)
        ttk.Button(line, text="Send", command=self._send_command).pack(side="left")
        # Live camera still: queues camera_photo and jumps the grid to Media so the
        # frame the phone just uploaded is visible without a second click.
        ttk.Button(line, text="Live photo",
                   command=self._live_photo).pack(side="left", padx=(4, 0))
        self.action_hint = tk.StringVar(value=COMMAND_CATALOG["ping"][0])
        ttk.Label(cmd, textvariable=self.action_hint, foreground="#555",
                  wraplength=780, justify="left").pack(anchor="w", pady=(4, 0))


    def _place_sashes(self) -> bool:
        """Pin the device list split once Tk knows the real widget sizes.

        Tk silently ignores sashpos() while the paned window is unmapped, and
        the Devices tab is not the tab selected at startup. Applying it once
        from a timer therefore left the sash at 0, which collapsed the device
        list and the command log to a one-pixel column: the tab looked empty
        even though the tree was full of rows. Retry until the pane is really
        laid out, and re-check when the operator opens the tab.
        """
        try:
            if self._sash_placed:
                return True
            if not self.devices_pane.winfo_ismapped() or self.devices_pane.winfo_width() <= 1:
                # Not on screen yet: try again shortly instead of giving up.
                if self._sash_attempts < 25:
                    self._sash_attempts += 1
                    self.root.after(200, self._place_sashes)
                return False
            width = self.devices_pane.winfo_width()
            self.devices_pane.sashpos(0, min(440, max(360, width // 4)))
            self._sash_placed = True
            return True
        except (tk.TclError, AttributeError):
            return False

    def _on_tab_changed(self, _event=None) -> None:
        """Position the split the first time the Devices tab is opened."""
        try:
            if self.notebook.index(self.notebook.select()) == 1:
                self._place_sashes()
        except (tk.TclError, AttributeError):
            pass

    def _refresh_now(self) -> None:
        """Operator-triggered refresh of every view that reads the database."""
        try:
            self._refresh_devices()
            self._refresh_history(force=True)
            self._refresh_rules()
            self._place_sashes()
            if self.selected_device is not None:
                self._load_data()
            self.log("Refreshed from database.")
        except Exception as exc:           # a button press must not kill the UI
            self.log(f"refresh failed: {type(exc).__name__}: {exc}")

    def _show_detail(self, _event=None) -> None:
        """Bring the wrapped, full-width row view to the front."""
        if self._row_payload:
            self.detail_tabs.select(1)

    def _set_device_info(self, text: str) -> None:
        self.device_info.configure(state="normal")
        self.device_info.delete("1.0", "end")
        self.device_info.insert("1.0", text)
        self.device_info.configure(state="disabled")

    def _set_preview(self, text: str) -> None:
        self.preview_text.configure(state="normal")
        self.preview_text.delete("1.0", "end")
        self.preview_text.insert("1.0", text)
        self.preview_text.configure(state="disabled")

    def _render_preview(self, _event=None) -> None:
        """Show the selected row in full, with JSON columns expanded."""
        selection = self.data_tree.selection()
        if not selection or not self._row_payload:
            return
        try:
            index = self.data_tree.index(selection[0])
        except tk.TclError:
            return
        if not (0 <= index < len(self._row_payload)):
            return
        record = self._row_payload[index]
        lines = [f"row {index + 1} of {len(self._row_payload):,}", ""]
        for key, value in record.items():
            cell = fmt_ts(value) if key in TS_KEYS else pretty_value(value, indent=True)
            lines.append(f"{key}:")
            lines.append(cell if cell.strip() else "(empty)")
            lines.append("")
        self._set_preview("\n".join(lines).rstrip() + "\n")

    def _copy_row(self) -> None:
        text = self.preview_text.get("1.0", "end").strip()
        if not text:
            return
        self._copy(text)
        self.log("Copied the selected row to the clipboard.")

    # -- tab 3: rules --------------------------------------------------------
    def _build_rules_tab(self, notebook: ttk.Notebook) -> None:
        tab = ttk.Frame(notebook, padding=12)
        notebook.add(tab, text="  Blocked apps  ")
        ttk.Label(tab, text="Packages the device blocks (GET /api/v1/rules).",
                  foreground="#555").pack(anchor="w")
        box = ttk.Frame(tab)
        box.pack(fill="both", expand=True, pady=8)
        self.rules_tree = ttk.Treeview(box, columns=("package",), show="headings", height=18)
        self.rules_tree.heading("package", text="Package")
        self.rules_tree.column("package", width=460, anchor="w")
        self.rules_tree.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(box, orient="vertical", command=self.rules_tree.yview)
        self.rules_tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")

        line = ttk.Frame(tab)
        line.pack(fill="x")
        self.rule_var = tk.StringVar()
        ttk.Entry(line, textvariable=self.rule_var, width=46).pack(side="left")
        ttk.Button(line, text="Add", command=self._add_rule).pack(side="left", padx=6)
        ttk.Button(line, text="Remove selected", command=self._remove_rule).pack(side="left")
        ttk.Button(line, text="Clear all", command=self._clear_rules).pack(side="left", padx=6)

    # -- logging -------------------------------------------------------------
    def log(self, message: str) -> None:
        stamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert("end", f"[{stamp}] {message}\n")
        self.log_text.see("end")

    def _copy(self, value: str) -> None:
        self.root.clipboard_clear()
        self.root.clipboard_append(value)

    def _copy_url(self) -> None:
        self._copy(self._url())
        self.log(f"Copied {self._url()}")

    def _url(self) -> str:
        scheme = "https" if CERT_FILE.exists() else "http"
        return f"{scheme}://{self.lan_ip}:{self.port_var.get().strip() or DEFAULT_PORT}"

    # -- settings ------------------------------------------------------------
    def _apply_settings(self) -> bool:
        raw_port = self.port_var.get().strip()
        if not raw_port.isdigit() or not (1 <= int(raw_port) <= 65535):
            messagebox.showerror(APP_TITLE, "Port must be a number between 1 and 65535.")
            return False
        new_port = int(raw_port)
        old_port = int(self.config.get("port", DEFAULT_PORT))
        key = self.key_var.get().strip()
        if len(key) < 8:
            messagebox.showerror(APP_TITLE, "The enrollment key must be at least 8 characters.")
            return False

        self.config["port"] = new_port
        self.config["enrollment_key"] = key
        self.config["sync_interval_s"] = clamp(self.sync_var.get(), DEFAULT_SYNC_INTERVAL_S,
                                               MIN_SYNC_INTERVAL_S, MAX_SYNC_INTERVAL_S)
        self.config["sms_interval_s"] = clamp(self.sms_var.get(), DEFAULT_SMS_INTERVAL_S,
                                              MIN_SMS_INTERVAL_S, MAX_SMS_INTERVAL_S)
        self.sync_var.set(str(self.config["sync_interval_s"]))
        self.sms_var.set(str(self.config["sms_interval_s"]))
        save_config(self.config)
        self._render_url()

        if new_port != old_port and self.api is not None and self.api.running:
            if messagebox.askyesno(APP_TITLE, f"Restart the server on port {new_port} now?"):
                self._stop_server()
                self._start_server()
            else:
                self.log(f"Port saved as {new_port}; restart the server to use it.")
        else:
            self.log(f"Settings saved (port {new_port}).")
        return True

    def _new_key(self) -> None:
        self.key_var.set(secrets.token_hex(24))
        self._apply_settings()

    def _render_url(self) -> None:
        port = self.port_var.get().strip() or str(DEFAULT_PORT)
        scheme = "https" if CERT_FILE.exists() else "http"
        self.url_var.set(f"{scheme}://{self.lan_ip}:{port}")

    # -- server lifecycle ----------------------------------------------------
    def _toggle_server(self) -> None:
        if self.api is not None and self.api.running:
            self._stop_server()
        else:
            self._start_server()

    def _start_server(self) -> None:
        if not self._apply_settings():
            return
        port = int(self.config["port"])
        if not port_is_free(port):
            messagebox.showerror(
                APP_TITLE,
                f"Port {port} is already in use. Pick another port, or stop whatever is "
                f"listening on it.",
            )
            self.log(f"Cannot start: port {port} is busy.")
            return
        app = create_api(self.store, self.config)
        self.api = ApiServer(app, "0.0.0.0", port)
        try:
            self.api.start()
        except Exception as exc:
            self.api = None
            messagebox.showerror(APP_TITLE, f"Could not start the server: {exc}")
            self.log(f"Start failed: {exc}")
            return
        self.status_var.set(f"running on {port}")
        self.status_label.configure(style="Ok.TLabel")
        self.start_btn.configure(text="Stop server")
        self.port_entry.configure(state="disabled")
        self._render_url()
        self.log(f"Server listening on {self.api.scheme}://0.0.0.0:{port} "
                 f"(LAN {self._url()})")
        if self.api.scheme == "http":
            self.log("WARNING: no certificate found, running plain HTTP. The APK requires HTTPS.")
        self.log(f"Enrollment key in use: {self.config['enrollment_key']}")

    def _stop_server(self) -> None:
        if self.api is not None:
            self.api.stop()
            self.api = None
        self.status_var.set("stopped")
        self.status_label.configure(style="Bad.TLabel")
        self.start_btn.configure(text="Start server")
        self.port_entry.configure(state="normal")
        self.log("Server stopped.")

    def _on_close(self) -> None:
        try:
            self._stop_server()
        finally:
            self.root.destroy()

    # -- helpers on the server tab -------------------------------------------
    def _open_firewall(self) -> None:
        port = self.port_var.get().strip() or str(DEFAULT_PORT)
        rule = f"ParentalControl-{port}"
        script = (
            f"netsh advfirewall firewall delete rule name=\"{rule}\" | Out-Null; "
            f"netsh advfirewall firewall add rule name=\"{rule}\" dir=in action=allow "
            f"protocol=TCP localport={port}"
        )
        try:
            subprocess.Popen(
                ["powershell", "-NoProfile", "-Command",
                 f"Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile','-Command',"
                 f"'{script}'"],
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            self.log(f"Firewall: asked for admin rights to allow TCP {port}.")
        except Exception as exc:
            self.log(f"Firewall failed: {exc}")

    def _self_test(self) -> None:
        port = self.port_var.get().strip() or str(DEFAULT_PORT)
        result = probe_health(self.lan_ip, int(port), bool(CERT_FILE.exists()))
        self.log(f"Self-test {self._url()}/api/v1/health -> {result}")

    def _setup_phone(self) -> None:
        if not ADB_SCRIPT.exists():
            messagebox.showerror(APP_TITLE, f"Missing {ADB_SCRIPT.name}.")
            return
        port = self.port_var.get().strip() or str(DEFAULT_PORT)
        args = [sys.executable, str(ADB_SCRIPT), "--host", self.lan_ip,
                "--port", port, "--key", self.config["enrollment_key"]]
        self.log("adb: starting phone setup...")

        def worker() -> None:
            try:
                proc = subprocess.run(args, capture_output=True, text=True, timeout=600)
                output = (proc.stdout or "") + (proc.stderr or "")
            except Exception as exc:
                output = f"{type(exc).__name__}: {exc}"
            for line in output.strip().splitlines():
                self.root.after(0, self.log, f"adb: {line}")

        threading.Thread(target=worker, daemon=True).start()

    def _open_captures(self) -> None:
        CAPTURE_DIR.mkdir(parents=True, exist_ok=True)
        try:
            os.startfile(str(CAPTURE_DIR))  # type: ignore[attr-defined]
        except Exception as exc:
            self.log(f"Could not open captures: {exc}")

    # -- device tab ----------------------------------------------------------
    def _tick(self) -> None:
        try:
            self._refresh_devices()
            self._refresh_history()
            self._reload_data_if_changed()
            self._watch_stalled_peers()
        except Exception as exc:                      # never kill the UI loop
            self.log(f"refresh error: {exc}")
        self.root.after(UI_REFRESH_MS, self._tick)

    def _watch_stalled_peers(self) -> None:
        """Report connections that hung in TLS instead of freezing the server."""
        if self.api is None:
            return
        stalled = self.api.stalled_peers
        if stalled != getattr(self, "_last_stalled_peers", 0):
            self._last_stalled_peers = stalled
            self.log(f"Dropped {stalled} connection(s) that never completed the TLS "
                     f"handshake; the server kept serving everyone else.")

    def _refresh_devices(self) -> None:
        rows = self.store.devices()
        seen = set()
        online_now = 0
        self._suppress_select = True
        try:
            for row in rows:
                device_id = int(row["id"])
                seen.add(str(device_id))
                last_seen = row["last_seen"] or ""
                online = device_online(row)
                if online:
                    online_now += 1
                # The list only has room for five columns; ip and app version
                # live in the Device summary on the right.
                values = (
                    device_id,
                    (row["label"] or row["device_uid"] or "")[:40],
                    "online" if online else "offline",
                    row["battery"] if row["battery"] is not None else "",
                    last_seen[5:16] if len(last_seen) >= 16 else last_seen,
                )
                if self.device_tree.exists(str(device_id)):
                    self.device_tree.item(str(device_id), values=values)
                else:
                    self.device_tree.insert("", "end", iid=str(device_id), values=values)
            for iid in list(self.device_tree.get_children()):
                if iid not in seen:
                    self.device_tree.delete(iid)
        finally:
            self._suppress_select = False
        self.device_count_var.set(f"{online_now} online / {len(rows)} total")
        if not rows and self.selected_device is None:
            self._set_device_info("No device enrolled yet.\n"
                                  "Connect the phone over USB and run the adb setup, or "
                                  "point the APK at this server's URL.")

    def _on_device_selected(self, _event=None) -> None:
        if self._suppress_select:           # timer refresh, not the operator
            return
        selection = self.device_tree.selection()
        if not selection:
            return
        try:
            device_id = int(selection[0])
        except (TypeError, ValueError):
            return
        self.selected_device = device_id
        self._history_sig = None            # force the command log to redraw
        row = self.store.device_by_id(self.selected_device)
        if row is None:
            return
        counts = self.store.counts(self.selected_device)
        summary = (
            f"#{row['id']}  {row['label'] or ''}\n"
            f"uid        {row['device_uid']}\n"
            f"model      {row['model'] or ''} / {row['manufacturer'] or ''} "
            f"(Android {row['android_release'] or '?'}, SDK {row['sdk_int'] or '?'})\n"
            f"app        {row['app_version'] or '?'}   battery {row['battery'] if row['battery'] is not None else '?'}%\n"
            f"ip         {row['ip_address'] or '-'}   last seen {row['last_seen'] or '-'}\n"
            f"flags      hidden={row['hidden']} admin={row['admin_active']} "
            f"sms_interval={row['sms_interval_s'] or 'default'}\n"
            f"stored     " + "  ".join(f"{k}={v}" for k, v in counts.items())
        )
        self._set_device_info(summary)
        self._load_data()
        # Redraw the command log immediately instead of waiting for the next
        # timer tick, so it never shows the previous device's commands.
        self._refresh_history(force=True)

    def _load_data(self) -> None:
        if self.selected_device is None:
            self.count_var.set("no device selected")
            return
        kind = self.kind_var.get()
        view = DATA_VIEWS.get(kind, DATA_VIEWS["SMS"])
        columns = view["cols"]
        raw_limit = (self.limit_var.get() or DEFAULT_DATA_LIMIT).strip()
        limit = (-1 if raw_limit.lower() == "all"
                 else clamp(raw_limit, int(DEFAULT_DATA_LIMIT), 1, 1_000_000))
        # Some views are deliberately a window, not a dump (SMS = newest 50), so
        # the limit selector can only narrow that window, never widen it.
        window = int(view.get("limit") or 0)
        if window:
            limit = window if limit < 0 else min(limit, window)

        rows = self.store.all(view["sql"] + " LIMIT ?", (self.selected_device, limit))
        total_row = self.store.one(
            f"SELECT COUNT(*) AS n FROM {view['table']} WHERE device_id=?",
            (self.selected_device,),
        )
        total = int(total_row["n"]) if total_row else len(rows)

        # Rebuild the grid from DATA_VIEWS so every column key exists in the row:
        # the old layout asked for "time"/"dir", which the SELECT never returned,
        # so those cells were always blank.
        self._row_payload = []
        self.data_tree.delete(*self.data_tree.get_children())
        self.data_tree.configure(columns=[key for key, _ in columns])
        for key, width in columns:
            self.data_tree.heading(key, text=key.replace("_", " ").title())
            self.data_tree.column(key, width=width, anchor="w", stretch=False)
        for row in rows:
            record = {key: (row[key] if key in row.keys() else None) for key, _ in columns}
            self._row_payload.append(record)
            cells = []
            for key, _ in columns:
                value = record[key]
                cells.append(grid_cell(fmt_ts(value) if key in TS_KEYS else value))
            self.data_tree.insert("", "end", values=cells)

        self._data_count = total
        if window:
            suffix = f" (newest {window})"
        else:
            suffix = "" if limit < 0 else f" (limit {limit:,})"
        self.count_var.set(f"showing {len(rows):,} of {total:,} {kind.lower()}{suffix}")
        children = self.data_tree.get_children()
        if children:
            self.data_tree.selection_set(children[0])
            self.data_tree.focus(children[0])
            self._render_preview()
        else:
            self._set_preview(f"No {kind.lower()} stored for this device yet.")

    # -- "latest from the phone" ----------------------------------------------
    def _queue_refresh(self, action: str, params: dict | None = None) -> int:
        """Queue one refresh/still command and return the command id."""
        return self.store.add_command(
            self.selected_device, action, params or {},
            default_sms_interval=clamp(self.config.get("sms_interval_s"), DEFAULT_SMS_INTERVAL_S,
                                       MIN_SMS_INTERVAL_S, MAX_SMS_INTERVAL_S),
        )

    def _row_count(self, kind: str) -> int:
        """Rows stored locally for the selected device and one data kind."""
        view = DATA_VIEWS.get(kind, DATA_VIEWS["SMS"])
        row = self.store.one(
            f"SELECT COUNT(*) AS n FROM {view['table']} WHERE device_id=?",
            (self.selected_device,),
        )
        return int(row["n"]) if row is not None else 0

    def _fetch_latest(self) -> None:
        """Ask the phone for fresh data for the kind on screen, then reload it.

        A refresh press used to look like nothing happened: the command went out
        and the upload only landed on a later tick. Waiting for the command (or
        for the row count to grow) and then redrawing makes the press explain
        itself.
        """
        if self.selected_device is None:
            messagebox.showinfo(APP_TITLE, "Select a device first.")
            return
        kind = self.kind_var.get()
        action = KIND_REFRESH_ACTION.get(kind, "sync_now")
        before = self._row_count(kind)
        command_id = self._queue_refresh(action)
        self.log(f"Command #{command_id} {action} queued: fetching latest {kind} from the phone.")
        self._refresh_history(force=True)
        self._watch_fetch(command_id, kind, before, time.time() + FETCH_TIMEOUT_S)

    def _watch_fetch(self, command_id: int, kind: str, before: int, deadline: float) -> None:
        """Follow one fetch command and reload the grid once it answers.

        Re-schedules itself with Tk's timer instead of blocking: the panel keeps
        drawing while the phone uploads. It stops as soon as the command is
        finished, the row count grows, or the deadline passes, so a phone that is
        offline cannot leave the button spinning forever.
        """
        if self.selected_device is None:
            return
        row = self.store.one(
            "SELECT status, result_message FROM commands WHERE id=?",
            (int(command_id),),
        )
        status = str(row["status"]) if row is not None and row["status"] else "pending"
        grew = self._row_count(kind) > before
        finished = status not in ("pending", "delivered")
        if not (finished or grew or time.time() >= deadline):
            self.root.after(1500,
                            lambda: self._watch_fetch(command_id, kind, before, deadline))
            return
        if self.kind_var.get() == kind:
            self._load_data()
        if finished:
            note = str(row["result_message"] or "") if row is not None else ""
            self.log(f"Command #{command_id} {status}: {note[:160] or kind + ' reloaded'}")
        elif grew:
            self.log(f"Command #{command_id} running; {kind} grew while waiting.")
        else:
            self.log(f"Command #{command_id} still {status}: reloaded {kind} anyway "
                     f"(the device may be offline).")
        self._refresh_history(force=True)

    def _live_photo(self) -> None:
        """Take a still on the phone right now and show it in the Media grid."""
        if self.selected_device is None:
            messagebox.showinfo(APP_TITLE, "Select a device first.")
            return
        before = self._row_count("Media")
        command_id = self._queue_refresh("camera_photo", {"camera": "back"})
        self.log(f"Command #{command_id} camera_photo queued: live photo from the back camera.")
        self.kind_var.set("Media")
        self._refresh_history(force=True)
        self._watch_fetch(command_id, "Media", before, time.time() + FETCH_TIMEOUT_S)

    def _reload_data_if_changed(self) -> None:
        """Keep the grid live without redrawing it on every tick.

        A blind reload each tick threw away the operator's selection and scroll
        position, so the local row count is compared first: a new SMS or call
        from the phone then appears on its own.
        """
        if self.selected_device is None:
            return
        if self._row_count(self.kind_var.get()) != self._data_count:
            self._load_data()

    def _on_action_changed(self, _event=None) -> None:
        action = self.action_var.get()
        label, params = COMMAND_CATALOG.get(action, (action, {}))
        self.action_hint.set(label)
        self.params_var.set(json.dumps(params))

    def _send_command(self) -> None:
        if self.selected_device is None:
            messagebox.showinfo(APP_TITLE, "Select a device first.")
            return
        action = self.action_var.get()
        raw = self.params_var.get().strip() or "{}"
        try:
            params = json.loads(raw)
            if not isinstance(params, dict):
                raise ValueError("params must be a JSON object")
        except ValueError as exc:
            messagebox.showerror(APP_TITLE, f"Params is not a JSON object: {exc}")
            return
        # add_command persists the SMS cadence for set_sms_interval, so the panel
        # only reports what was accepted instead of writing the same row twice.
        command_id = self.store.add_command(
            self.selected_device, action, params,
            default_sms_interval=clamp(self.config.get("sms_interval_s"), DEFAULT_SMS_INTERVAL_S,
                                       MIN_SMS_INTERVAL_S, MAX_SMS_INTERVAL_S),
        )
        if action == "set_sms_interval":
            device = self.store.device_by_id(self.selected_device)
            seconds = device["sms_interval_s"] if device is not None else None
            self.log(f"Command #{command_id} {action} queued (sms_interval_s={seconds}).")
        else:
            self.log(f"Command #{command_id} {action} queued for device {self.selected_device}.")
        self._refresh_history(force=True)

    def _refresh_history(self, force: bool = False) -> None:
        if self.selected_device is None:
            return
        rows = self.store.all(
            """SELECT id, action, status, result_message, created_at, completed_at
                 FROM commands WHERE device_id=? ORDER BY id DESC LIMIT 40""",
            (self.selected_device,),
        )
        # The panel re-reads this table on every UI_REFRESH_MS tick; redrawing all
        # 40 rows each time made the frame flicker and lost the scroll position.
        signature = tuple((row["id"], row["status"], row["completed_at"]) for row in rows)
        if not force and signature == self._history_sig:
            return
        self._history_sig = signature
        self.history.delete(*self.history.get_children())
        for row in rows:
            when = (row["completed_at"] or row["created_at"] or "")[11:19]
            note = (row["result_message"] or "")[:160]
            self.history.insert("", "end", values=(when, row["action"], row["status"], note))

    # -- operator login ------------------------------------------------------
    def _render_web_login_state(self) -> None:
        if operator_login_set(self.config):
            user = self.config.get("web_username") or "admin"
            self.web_login_state.set(
                f"Locked. The browser asks for user '{user}' plus its password; "
                f"a session lasts {DEFAULT_SESSION_TTL_S // 3600}h. The phone API is not affected."
            )
        else:
            self.web_login_state.set(
                "NOT LOCKED - no password is set, so the browser view refuses to show any "
                "data. Set a username and password here to open it again."
            )

    def _save_web_login(self) -> None:
        username = self.web_user_var.get().strip()
        password = self.web_pass_var.get()
        confirm = self.web_pass2_var.get()
        if not username:
            messagebox.showerror(APP_TITLE, "The username cannot be empty.")
            return
        if len(password) < MIN_PASSWORD_LEN:
            messagebox.showerror(APP_TITLE,
                                 f"Use at least {MIN_PASSWORD_LEN} characters for the password.")
            return
        if password != confirm:
            messagebox.showerror(APP_TITLE, "The two passwords do not match.")
            return
        self.config["web_username"] = username
        self.config["web_password_hash"] = hash_password(password)
        # The plaintext key from the first draft must not survive next to the hash.
        self.config.pop("web_password", None)
        session_secret_for(self.config)     # keep one signing key across restarts
        save_config(self.config)
        self.web_pass_var.set("")
        self.web_pass2_var.set("")
        self._render_web_login_state()
        self.log(f"Dashboard login set for user '{username}' (only the hash is stored).")

    def _clear_web_login(self) -> None:
        if not operator_login_set(self.config):
            messagebox.showinfo(APP_TITLE, "No dashboard password is set.")
            return
        if not messagebox.askyesno(
            APP_TITLE,
            "Remove the dashboard password?\n\n"
            "The browser view then refuses to show any data until a new password is set. "
            "The desktop panel and the phone API keep working.",
            icon="warning", default="no",
        ):
            return
        self.config["web_password_hash"] = ""
        save_config(self.config)
        self._render_web_login_state()
        self.log("Dashboard login removed; the browser view is locked until a password is set.")

    # -- delete one device's history -----------------------------------------
    def _delete_history(self, device_id: int | None = None) -> None:
        device_id = int(device_id or self.selected_device or 0)
        if not device_id:
            messagebox.showinfo(APP_TITLE, "Select a device in the list first.")
            return
        row = self.store.device_by_id(device_id)
        if row is None:
            messagebox.showerror(APP_TITLE, "That device is no longer in the database.")
            return
        who = str(row["label"] or row["model"] or row["device_uid"])
        counts = self.store.counts(device_id)
        for key, table in (("commands", "commands"), ("permissions", "device_permissions")):
            extra = self.store.one(f"SELECT COUNT(*) AS n FROM {table} WHERE device_id=?",
                                   (device_id,))
            counts[key] = int(extra["n"]) if extra else 0

        labels = {
            "commands": "Command log",
            "sms": "SMS",
            "calls": "Call log",
            "contacts": "Contacts",
            "clipboard": "Clipboard",
            "apps": "Installed apps",
            "locations": "Locations",
            "usage": "App usage",
            "media": "Photos / audio",
            "permissions": "Permission report",
        }
        order = list(labels)

        win = tk.Toplevel(self.root)
        win.title(f"Delete history - {who}")
        win.transient(self.root)
        win.resizable(False, False)
        body = ttk.Frame(win, padding=14)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text=f"{who}   (device #{device_id})", style="Head.TLabel").pack(anchor="w")
        ttk.Label(
            body,
            text=("Tick what to erase from this server. Nothing is deleted on the phone, and the "
                  "device stays enrolled - it simply starts filling these tables again."),
            foreground="#555", wraplength=470, justify="left",
        ).pack(anchor="w", pady=(4, 10))

        picks: dict[str, tk.BooleanVar] = {}
        grid = ttk.Frame(body)
        grid.pack(fill="x")
        for index, key in enumerate(order):
            # The permission snapshot is a diagnostic, not history; leave it alone
            # unless the operator asks for it.
            var = tk.BooleanVar(value=key != "permissions")
            picks[key] = var
            ttk.Checkbutton(grid, text=f"{labels[key]} ({counts.get(key, 0)})",
                            variable=var).grid(row=index // 2, column=index % 2,
                                               sticky="w", padx=(0, 20), pady=1)

        def set_all(value: bool) -> None:
            for var in picks.values():
                var.set(value)

        def run_delete() -> None:
            chosen = [key for key in order if picks[key].get()]
            if not chosen:
                messagebox.showinfo(APP_TITLE, "Tick at least one kind of history.", parent=win)
                return
            total = sum(counts.get(key, 0) for key in chosen)
            summary = "\n".join(f"  - {labels[key]}: {counts.get(key, 0)}" for key in chosen)
            if not messagebox.askyesno(
                APP_TITLE,
                f"Permanently delete {total} record(s) for {who}?\n\n{summary}\n\n"
                "Capture files for the media rows are deleted from disk as well. "
                "This cannot be undone.",
                icon="warning", default="no", parent=win,
            ):
                return
            try:
                result = self.store.delete_device_history(device_id, chosen, ip="desktop panel")
            except (ValueError, sqlite3.Error) as exc:
                messagebox.showerror(APP_TITLE, f"Delete failed: {exc}", parent=win)
                return
            win.destroy()
            parts = ", ".join(f"{key}={value}" for key, value in result["deleted"].items())
            self.log(f"Deleted history for device {device_id}: {parts}"
                     + (f" ({result['files_removed']} file(s) removed)"
                        if result["files_removed"] else ""))
            if result["file_errors"]:
                self.log(f"  {result['file_errors']} capture file(s) could not be removed.")
            if result.get("refreshes_queued"):
                self.log("  re-fetch queued: " + ", ".join(result["refreshes_queued"])
                         + " (the phone re-sends its newest window on app 1.6+)")
            self._refresh_now()

        buttons = ttk.Frame(body)
        buttons.pack(fill="x", pady=(12, 0))
        ttk.Button(buttons, text="All", width=6,
                   command=lambda: set_all(True)).pack(side="left")
        ttk.Button(buttons, text="None", width=6,
                   command=lambda: set_all(False)).pack(side="left", padx=(6, 0))
        ttk.Button(buttons, text="Cancel", command=win.destroy).pack(side="right")
        ttk.Button(buttons, text="Delete", command=run_delete).pack(side="right", padx=(0, 8))

        win.update_idletasks()
        win.geometry(f"+{self.root.winfo_rootx() + 90}+{self.root.winfo_rooty() + 110}")
        win.grab_set()

    # -- rules tab -----------------------------------------------------------
    def _refresh_rules(self) -> None:
        self.rules_tree.delete(*self.rules_tree.get_children())
        for package in self.store.rules():
            self.rules_tree.insert("", "end", values=(package,))

    def _add_rule(self) -> None:
        package = self.rule_var.get().strip()
        if not package:
            return
        if self.store.add_rule(package):
            self.rule_var.set("")
            self._refresh_rules()
            self.log(f"Blocked {package}")

    def _remove_rule(self) -> None:
        for iid in self.rules_tree.selection():
            package = self.rules_tree.item(iid, "values")[0]
            self.store.remove_rule(package)
            self.log(f"Unblocked {package}")
        self._refresh_rules()

    def _clear_rules(self) -> None:
        if messagebox.askyesno(APP_TITLE, "Remove every blocked package?"):
            self.store.clear_rules()
            self._refresh_rules()
            self.log("Cleared the block list.")


def probe_health(host: str, port: int, tls: bool) -> str:
    """One-shot health probe from the panel (accepts the lab certificate)."""
    import ssl as _ssl
    import urllib.error
    import urllib.request

    scheme = "https" if tls else "http"
    url = f"{scheme}://{host}:{port}/api/v1/health"
    context = _ssl._create_unverified_context() if tls else None
    req = urllib.request.Request(url, data=b"", method="POST")
    try:
        with urllib.request.urlopen(req, timeout=6, context=context) as resp:
            body = resp.read(200).decode("utf-8", "replace")
            return f"HTTP {resp.status} {body}"
    except urllib.error.HTTPError as exc:
        return f"HTTP {exc.code}"
    except Exception as exc:
        return f"{type(exc).__name__}: {exc}"


# ---------------------------------------------------------------------------
# Headless mode
# ---------------------------------------------------------------------------

def run_headless(port: int | None = None, host: str | None = None) -> None:
    """Serve the API without the Tk panel, for scripted or service use.

    The port resolution mirrors the panel exactly: CLI flag > server_config.json
    > built-in default, and the chosen value is written back so a later panel
    launch or adb provisioning run uses the same port.
    """
    config = load_config()
    bind = (host or config.get("host") or DEFAULT_HOST).strip()
    chosen = int(port if port is not None else config.get("port", DEFAULT_PORT))

    if port is not None:
        config["port"] = chosen
        config["host"] = bind
        save_config(config)

    if not (1 <= chosen <= 65535):
        raise SystemExit(f"port {chosen} is outside 1..65535")
    if not port_is_free(chosen):
        raise SystemExit(f"port {chosen} is already in use; pass --port N with a free port")

    store = Store(DB_PATH)
    app = create_api(store, config)
    server = ApiServer(app, bind, chosen)
    server.start()

    lan = detect_lan_ip()
    scheme = server.scheme
    print(f"{APP_TITLE} - headless")
    print(f"  database : {DB_PATH}")
    print(f"  listen   : {scheme}://{bind}:{chosen}")
    print(f"  phone    : {scheme}://{lan}:{chosen}")
    print(f"  enroll   : {config.get('enrollment_key')}")
    if scheme == "http":
        print("  WARNING  : no TLS certificate found; the APK refuses plain HTTP.")
    print("  Ctrl+C to stop.")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nstopping...")
    finally:
        server.stop()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description=f"{APP_TITLE} control panel")
    parser.add_argument(
        "--autostart",
        action="store_true",
        help="start the listener as soon as the panel opens (handy for scripting)",
    )
    parser.add_argument(
        "--port",
        type=int,
        metavar="N",
        help=f"listen port (overrides server_config.json; default {DEFAULT_PORT}). "
             "Use any free port, e.g. 8443 or 3000. The phone must be told the same port.",
    )
    parser.add_argument(
        "--host",
        default=None,
        metavar="ADDR",
        help=f"bind address (default {DEFAULT_HOST} = all interfaces)",
    )
    parser.add_argument(
        "--no-gui",
        action="store_true",
        help="run headless: start the listener and stay in the console",
    )
    args = parser.parse_args()

    if args.port is not None and not (1 <= args.port <= 65535):
        parser.error("--port must be between 1 and 65535")

    if args.no_gui:
        run_headless(port=args.port, host=args.host)
        return

    root = tk.Tk()
    panel = Panel(root)
    # A CLI port wins over the stored value and is written back so the panel and
    # the next adb provisioning run agree on it.
    if args.port is not None:
        panel.config["port"] = args.port
        save_config(panel.config)
        panel.port_var.set(str(args.port))
    if args.host is not None:
        panel.config["host"] = args.host
    panel._refresh_rules()
    panel._render_url()
    panel.log(f"Database: {DB_PATH}")
    panel.log(f"Panel ready. Default port {panel.config.get('port')} - press Start server.")
    if not (CERT_FILE.exists() and KEY_FILE.exists()):
        panel.log("No TLS certificate found; the server would run plain HTTP and the APK "
                  "will refuse it. Generate one first.")
    if args.autostart or args.port is not None:
        root.after(400, panel._start_server)
    root.mainloop()


if __name__ == "__main__":
    main()
