#!/usr/bin/env python3
"""Reads the saved live responses from _verify_refresh_http_pc69.sh and checks them."""

from __future__ import annotations

import json
import sys
from pathlib import Path

# Response directory: the shell script runs under msys, whose /tmp is not the
# same path Python sees, so the directory is passed in (or defaults next to this
# file) instead of being hard-coded.
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent / "_tmp_pc69_http"
FAILED: list[str] = []


def load(name: str):
    path = OUT / name
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except ValueError:
        return None


def check(ok: bool, label: str) -> None:
    print(("PASS  " if ok else "FAIL  ") + label)
    if not ok:
        FAILED.append(label)


def main() -> int:
    dev = (OUT / "device_id.txt").read_text().strip() if (OUT / "device_id.txt").exists() else ""
    if not dev:
        print("FAIL  no device id captured - the live server may not be answering")
        return 1

    cat = load("catalog.json") or {}
    refresh = cat.get("refresh_actions") or {}
    check(refresh.get("Calls") == "call_log_refresh" and refresh.get("SMS") == "sms_refresh"
          and refresh.get("Contacts") == "contacts_refresh",
          f"live catalog exposes refresh_actions ({json.dumps(refresh, sort_keys=True)})")
    check(refresh.get("Media") == "media_refresh" and refresh.get("Clipboard") == "clipboard_now"
          and refresh.get("Locations") == "location_now",
          "live catalog maps Media/Clipboard/Locations to their refresh actions")
    listed = cat.get("catalog") or {}
    check(all(a in listed for a in ("call_log_refresh", "contacts_refresh", "clipboard_now",
                                    "location_now", "media_refresh")),
          "live catalog lists the five new device actions")

    cmd = load("command_calls.json") or {}
    check(bool(cmd.get("id")) and cmd.get("action") == "call_log_refresh",
          f"live call_log_refresh queued (id={cmd.get('id')}, action={cmd.get('action')!r}, "
          f"device_online={cmd.get('device_online')})")

    photo = load("command_photo.json") or {}
    check(bool(photo.get("id")) and photo.get("action") == "camera_photo",
          f"live camera_photo queued (id={photo.get('id')}, action={photo.get('action')!r})")

    log = load("commands.json") or {}
    actions = [c.get("action") for c in log.get("commands") or []]
    check("call_log_refresh" in actions and "camera_photo" in actions,
          f"live command log shows both queued commands (newest: {actions[:4]})")

    for kind in ("Calls", "SMS", "Contacts", "Media"):
        grid = load(f"data_{kind}.json") or {}
        check(isinstance(grid.get("total"), int) and isinstance(grid.get("rows"), list),
              f"live {kind} grid answers with rows and a total (total={grid.get('total')})")

    calls = load("data_Calls.json") or {}
    check(not calls.get("rows") or not str((calls["rows"][0] or {}).get("time", "")).isdigit(),
          "live Calls rows carry a localised time, not a raw epoch")
    sms = load("data_SMS.json") or {}
    check(not sms.get("rows") or len(str(sms["rows"][0].get("body", ""))) >= 0,
          f"live SMS grid has {sms.get('total')} rows with a body column")

    bad = (OUT / "bad_action.json")
    check(bad.exists() and "unknown action" in bad.read_text(encoding="utf-8", errors="replace"),
          "live server still refuses an unknown action")

    print("-" * 72)
    print(f"{len(FAILED)} failed")
    return 1 if FAILED else 0


if __name__ == "__main__":
    sys.exit(main())
