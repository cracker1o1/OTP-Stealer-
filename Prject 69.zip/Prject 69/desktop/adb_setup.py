#!/usr/bin/env python3
"""One-command provisioning of a USB-attached Android phone for this server.

What it does, in order:

  1. checks that adb sees exactly one device (or the one named by --serial);
  2. checks that the control server answers on /api/v1/health;
  3. installs the release APK with every runtime permission pre-granted (-g);
  4. grants the remaining runtime permissions one by one (MIUI sometimes drops -g);
  5. applies the shell-grantable special grants: usage stats, overlay, accessibility
     service, battery whitelist, device admin;
  6. launches MainActivity with the provisioning extras (host, port, key, TLS), which
     stores the address and enrolls the device without a single tap;
  7. confirms the enrollment by reading the server's own SQLite database.

Usage:

    python adb_setup.py                  # auto host/port/key, install + provision
    python adb_setup.py --port 9443      # override the port
    python adb_setup.py --skip-install   # re-provision an already installed build
    python adb_setup.py --serial b891a816dac6

Nothing here needs root: every step uses the normal adb shell user.
"""

from __future__ import annotations

import argparse
import json
import shutil
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
ROOT_DIR = BASE_DIR.parent

APK_PATH = ROOT_DIR / "android" / "app" / "build" / "outputs" / "apk" / "release" / "app-release.apk"
CONFIG_PATH = BASE_DIR / "server_config.json"
DB_PATH = BASE_DIR / "pc69.sqlite3"

PACKAGE = "com.example.parentalcontrol"
ACTIVITY = f"{PACKAGE}/.MainActivity"
ACCESSIBILITY_SERVICE = f"{PACKAGE}/.MyAccessibilityService"
ADMIN_RECEIVER = f"{PACKAGE}/.AdminReceiver"

DEFAULT_PORT = 8443
DEFAULT_KEY = "48e5d16f1ddc5de7cc0478c57efaedca5a7ffaf63e024b1e"

# Dangerous permissions the app declares; `pm grant` works for all of them because
# they are requested at runtime in the manifest.
RUNTIME_PERMISSIONS = (
    "android.permission.CAMERA",
    "android.permission.RECORD_AUDIO",
    "android.permission.READ_SMS",
    "android.permission.RECEIVE_SMS",
    "android.permission.READ_CALL_LOG",
    "android.permission.READ_CONTACTS",
    "android.permission.READ_PHONE_STATE",
    "android.permission.READ_PHONE_NUMBERS",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.ACCESS_COARSE_LOCATION",
    "android.permission.POST_NOTIFICATIONS",
)


# --------------------------------------------------------------------------- output

class Report:
    """Collects PASS / WARN / FAIL lines so the run ends with one readable summary."""

    def __init__(self) -> None:
        self.rows: list[tuple[str, str, str]] = []

    def step(self, order: int, status: str, text: str) -> None:
        self.rows.append((status, str(order), text))
        marker = {"PASS": "PASS", "WARN": "WARN", "FAIL": "FAIL", "SKIP": "SKIP"}[status]
        print(f"[{marker}] {text}", flush=True)

    def passed(self, order: int, text: str) -> None:
        self.step(order, "PASS", text)

    def warn(self, order: int, text: str) -> None:
        self.step(order, "WARN", text)

    def failed(self, order: int, text: str) -> None:
        self.step(order, "FAIL", text)

    def skipped(self, order: int, text: str) -> None:
        self.step(order, "SKIP", text)

    def summary(self) -> str:
        counts = {"PASS": 0, "WARN": 0, "FAIL": 0, "SKIP": 0}
        for status, _, _ in self.rows:
            counts[status] += 1
        head = (f"{counts['PASS']} ok, {counts['WARN']} warning(s), "
                f"{counts['FAIL']} failure(s), {counts['SKIP']} skipped")
        hard = [text for status, _, text in self.rows if status == "FAIL"]
        lines = [head]
        if hard:
            lines.append("Blocking items:")
            lines.extend(f"  - {item}" for item in hard)
        return "\n".join(lines)


# --------------------------------------------------------------------------- helpers

def run(cmd: list[str], timeout: int = 120) -> tuple[int, str]:
    """Runs a command and returns (exit code, combined stdout+stderr)."""
    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            timeout=timeout,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        return proc.returncode, (proc.stdout or "").strip()
    except FileNotFoundError:
        return 127, f"{cmd[0]} not found on PATH"
    except subprocess.TimeoutExpired:
        return 124, f"{' '.join(cmd[:3])} timed out after {timeout}s"


def adb_path() -> str | None:
    return shutil.which("adb")


def adb(serial: str, *args: str, timeout: int = 120) -> tuple[int, str]:
    exe = adb_path()
    if exe is None:
        return 127, "adb not found on PATH"
    return run([exe, "-s", serial, *args], timeout=timeout)


def adb_shell(serial: str, command: str, timeout: int = 90) -> tuple[int, str]:
    return adb(serial, "shell", command, timeout=timeout)


def lan_ip() -> str:
    """Best-effort LAN address of this host, without sending any packets."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("8.8.8.8", 80))
        return probe.getsockname()[0]
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return "127.0.0.1"
    finally:
        probe.close()


def load_config() -> dict:
    data = {"port": DEFAULT_PORT, "enrollment_key": DEFAULT_KEY}
    if CONFIG_PATH.exists():
        try:
            stored = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(stored, dict):
                data.update({k: v for k, v in stored.items() if v is not None})
        except (OSError, ValueError):
            pass
    return data


def probe_health(host: str, port: int, timeout: float = 5.0) -> tuple[bool, str]:
    """POST /api/v1/health with the lab certificate accepted; no request body needed."""
    import ssl

    context = ssl._create_unverified_context()
    url = f"https://{host}:{port}/api/v1/health"
    request = urllib.request.Request(url, data=b"", method="POST")
    try:
        with urllib.request.urlopen(request, timeout=timeout, context=context) as resp:
            body = resp.read(200).decode("utf-8", "replace")
            return True, f"HTTP {resp.status} {body}"
    except urllib.error.HTTPError as exc:
        return False, f"HTTP {exc.code} from {url}"
    except Exception as exc:  # noqa: BLE001 - any transport failure means "not up"
        return False, f"{type(exc).__name__}: {exc}"


def pick_serial(requested: str | None, report: Report) -> str | None:
    exe = adb_path()
    if exe is None:
        report.failed(1, "adb is not installed or not on PATH")
        return None

    code, out = run([exe, "devices", "-l"])
    if code != 0:
        report.failed(1, f"adb devices failed: {out}")
        return None

    devices = []
    for line in out.splitlines()[1:]:
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) >= 2:
            devices.append((parts[0], parts[1], " ".join(parts[2:])))

    ready = [d for d in devices if d[1] == "device"]
    unauthorised = [d for d in devices if d[1] != "device"]

    if requested:
        match = [d for d in ready if d[0] == requested]
        if not match:
            report.failed(1, f"device {requested} is not attached and authorised")
            return None
        serial, _, detail = match[0]
        report.passed(1, f"device {serial} attached ({detail or 'no detail'})")
        return serial

    if not ready:
        if unauthorised:
            report.failed(
                1,
                "device present but not authorised — unlock the phone and accept the "
                "USB debugging prompt",
            )
        else:
            report.failed(1, "no device attached over USB")
        return None

    if len(ready) > 1:
        listing = ", ".join(d[0] for d in ready)
        report.failed(1, f"multiple devices attached ({listing}); pass --serial")
        return None

    serial, _, detail = ready[0]
    report.passed(1, f"device {serial} attached ({detail or 'no detail'})")
    return serial


def device_model(serial: str) -> str:
    code, out = adb_shell(serial, "getprop ro.product.model")
    return out.strip() if code == 0 and out.strip() else "unknown"


def shells_have_secure_settings(serial: str) -> bool:
    """True when the adb shell user may write secure settings (needed for accessibility)."""
    code, out = adb_shell(serial, "settings put secure pc69_probe 1")
    if code == 0 and "SecurityException" not in out and "denial" not in out:
        adb_shell(serial, "settings delete secure pc69_probe")
        return True
    return False


def stage_apk(serial: str, apk: Path, report: Report) -> None:
    """Puts the APK where the phone's own Files app can install it by hand."""
    remote = "/sdcard/Download/pc69-v1.4.apk"
    code, out = adb(serial, "push", str(apk), remote, timeout=300)
    if code != 0 or "1 file pushed" not in out:
        report.warn(3, f"could not stage the APK in Download: {out.splitlines()[-1] if out else 'no output'}")
        return
    report.warn(3, f"APK staged at {remote} — open Files > Downloads and tap it to install")
    adb_shell(serial, f"am start -a android.intent.action.VIEW -d file://{remote} "
                     f"-t application/vnd.android.package-archive")


def install_apk(serial: str, apk: Path, report: Report) -> bool:
    if not apk.exists():
        report.failed(2, f"APK missing at {apk} — run ./gradlew assembleRelease first")
        return False

    size_mb = apk.stat().st_size / (1024 * 1024)

    # `-g` is rejected outright by some OEM shells (HyperOS/MIUI answer with a
    # SecurityException about INSTALL_GRANT_RUNTIME_PERMISSIONS); fall back to a
    # plain install, then grant each permission explicitly in step 3.
    code, out = adb(serial, "install", "-r", "-g", str(apk), timeout=300)
    if code == 0 and "Success" in out:
        report.passed(2, f"installed {apk.name} ({size_mb:.1f} MB) with -g")
        return True

    if "INSTALL_FAILED_UPDATE_INCOMPATIBLE" in out:
        report.warn(2, "signature mismatch with an installed copy; uninstalling first")
        adb(serial, "uninstall", PACKAGE, timeout=120)
        code, out = adb(serial, "install", "-r", "-g", str(apk), timeout=300)
        if code == 0 and "Success" in out:
            report.passed(2, f"installed {apk.name} after uninstall")
            return True

    if "INSTALL_GRANT_RUNTIME_PERMISSIONS" in out or "INSTALL_FAILED_INVALID" not in out:
        code, out = adb(serial, "install", "-r", str(apk), timeout=300)
        if code == 0 and "Success" in out:
            report.warn(2, "installed without -g; runtime permissions granted in step 3")
            return True

    if "USER_RESTRICTED" in out:
        report.failed(
            2,
            "the phone refused the adb install (INSTALL_FAILED_USER_RESTRICTED). "
            "On HyperOS/MIUI enable Developer options > 'Install via USB' "
            "(and 'USB debugging (Security settings)' for the accessibility grant), "
            "then run this script again.",
        )
        stage_apk(serial, apk, report)
        return False

    tail = out.splitlines()[-1] if out else "no output"
    report.failed(2, f"adb install failed: {tail}")
    return False


def grant_runtime_permissions(serial: str, report: Report) -> None:
    granted, refused = 0, []
    for permission in RUNTIME_PERMISSIONS:
        code, out = adb_shell(serial, f"pm grant {PACKAGE} {permission}")
        if code == 0 and not out.strip():
            granted += 1
        else:
            refused.append(permission.rsplit(".", 1)[-1])

    if granted == len(RUNTIME_PERMISSIONS):
        report.passed(3, f"all {granted} runtime permissions granted")
    elif granted:
        report.warn(3, f"{granted}/{len(RUNTIME_PERMISSIONS)} granted; refused: "
                       f"{', '.join(refused)} (grant these from the panel)")
    else:
        report.failed(3, "no runtime permission could be granted — is the package installed?")


def grant_special_permissions(serial: str, report: Report) -> None:
    """Each grant is independent: one refusal must not stop the others."""
    checks: list[tuple[str, str]] = []

    code, out = adb_shell(serial, f"appops set {PACKAGE} GET_USAGE_STATS allow")
    checks.append(("usage access", "ok" if code == 0 else out.splitlines()[-1] if out else "refused"))

    code, out = adb_shell(serial, f"appops set {PACKAGE} SYSTEM_ALERT_WINDOW allow")
    checks.append(("display over other apps", "ok" if code == 0 else out.splitlines()[-1] if out else "refused"))

    if not shells_have_secure_settings(serial):
        checks.append((
            "accessibility service",
            "adb shell cannot write secure settings here; enable 'USB debugging "
            "(Security settings)' in Developer options or toggle it on the phone",
        ))
    else:
        code, out = adb_shell(serial, "settings get secure enabled_accessibility_services")
        current = out.strip()
        if "null" in current.lower() or current == "":
            current = ""
        entries = [item for item in current.split(":") if item]
        if ACCESSIBILITY_SERVICE not in entries:
            entries.append(ACCESSIBILITY_SERVICE)
        joined = ":".join(entries)
        code, out = adb_shell(
            serial,
            f"settings put secure enabled_accessibility_services '{joined}'",
        )
        ok = code == 0
        if ok:
            adb_shell(serial, "settings put secure accessibility_enabled 1")
        checks.append(("accessibility service", "ok" if ok else out.splitlines()[-1] if out else "refused"))

    code, out = adb_shell(serial, f"cmd deviceidle whitelist +{PACKAGE}")
    if code != 0 or "Error" in out:
        code, out = adb_shell(serial, f"dumpsys deviceidle whitelist +{PACKAGE}")
    checks.append(("battery whitelist", "ok" if code == 0 else out.splitlines()[-1] if out else "refused"))

    code, out = adb_shell(serial, f"dpm set-active-admin {ADMIN_RECEIVER}", timeout=120)
    admin_ok = code == 0 and "Success" in out
    if admin_ok:
        checks.append(("device admin", "ok"))
    else:
        tail = out.splitlines()[-1] if out else "refused"
        checks.append(("device admin", f"needs the on-screen prompt ({tail})"))

    for index, (label, result) in enumerate(checks):
        order = 40 + index
        if result == "ok":
            report.passed(order, f"{label}: granted over adb")
        else:
            report.warn(order, f"{label}: {result}")


def launch_provisioning(serial: str, host: str, port: int, key: str, report: Report) -> bool:
    """Starts MainActivity with the extras; the activity stores them and enrolls."""
    code, out = adb_shell(
        serial,
        "am start -W -n {act} --es provision_host {host} --ei provision_port {port} "
        "--es provision_key {key} --ez provision_self_signed true".format(
            act=ACTIVITY, host=host, port=port, key=key
        ),
        timeout=120,
    )
    if code != 0 or "Error" in out:
        report.failed(5, f"could not launch the panel: {out.splitlines()[-1] if out else 'no output'}")
        return False
    report.passed(5, f"panel launched with {host}:{port} and the enrollment key")
    return True


def read_devices(limit: int = 5) -> list[tuple]:
    """Reads the newest device rows; copies the database when the server holds a lock."""
    query = (
        "SELECT device_uid, model, android_release, app_version, last_seen, is_online "
        "FROM devices ORDER BY last_seen DESC LIMIT ?"
    )
    for attempt in range(2):
        target = DB_PATH
        cleanup = None
        if attempt == 1:
            # WAL readers can fail while the server writes; read a snapshot instead.
            tmpdir = tempfile.mkdtemp(prefix="pc69db_")
            target = Path(tmpdir) / "snapshot.sqlite3"
            for suffix in ("", "-wal", "-shm"):
                source = Path(str(DB_PATH) + suffix)
                if source.exists():
                    shutil.copy2(source, str(target) + suffix)
            cleanup = tmpdir
        try:
            uri = f"file:{target.as_posix()}?mode=ro"
            with sqlite3.connect(uri, uri=True, timeout=5) as conn:
                return conn.execute(query, (limit,)).fetchall()
        except sqlite3.Error:
            continue
        finally:
            if cleanup:
                shutil.rmtree(cleanup, ignore_errors=True)
    return []


def verify_enrollment(model: str, since: datetime) -> tuple[bool, str]:
    rows = read_devices()
    if not rows:
        return False, "no device row in the database yet (is the server running?)"

    for uid, row_model, release, version, last_seen, online in rows:
        if not last_seen:
            continue
        try:
            seen = datetime.strptime(str(last_seen)[:19], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        fresh = seen >= since - timedelta(seconds=5)
        same_model = model and str(row_model or "").lower() == str(model).lower()
        if fresh and same_model:
            return True, (
                f"{uid} enrolled as app v{version} on Android {release}; "
                f"last seen {last_seen} UTC, online={online}"
            )
    newest = rows[0]
    return False, (
        "no fresh row matched this phone; newest is "
        f"{newest[0]} (v{newest[3]}, last seen {newest[4]} UTC)"
    )


# --------------------------------------------------------------------------- main

def main() -> int:
    parser = argparse.ArgumentParser(
        description="Install and provision the control APK on a USB-attached phone.",
    )
    parser.add_argument("--host", help="server address the phone should use (default: this host's LAN IP)")
    parser.add_argument("--port", type=int, help=f"server port (default: from server_config.json or {DEFAULT_PORT})")
    parser.add_argument("--key", help="enrollment key (default: from server_config.json)")
    parser.add_argument("--serial", help="adb serial, needed only when several devices are attached")
    parser.add_argument("--apk", type=Path, default=APK_PATH, help="APK to install")
    parser.add_argument("--skip-install", action="store_true", help="do not install, only provision")
    parser.add_argument("--skip-grants", action="store_true", help="skip all permission grants")
    parser.add_argument("--skip-specials", action="store_true", help="skip usage/overlay/accessibility/admin grants")
    parser.add_argument("--skip-verify", action="store_true", help="do not confirm the enrollment in the database")
    parser.add_argument("--wait", type=int, default=25, help="seconds to wait for the enrollment (default 25)")
    args = parser.parse_args()

    config = load_config()
    host = (args.host or lan_ip()).strip()
    port = args.port or int(config.get("port") or DEFAULT_PORT)
    key = (args.key or str(config.get("enrollment_key") or DEFAULT_KEY)).strip()

    report = Report()
    started = datetime.now(timezone.utc)

    print("=" * 68)
    print(" PC69 phone provisioning")
    print(f" server  : https://{host}:{port}")
    print(f" package : {PACKAGE}")
    print(f" apk     : {args.apk}")
    print("=" * 68)

    serial = pick_serial(args.serial, report)
    if serial is None:
        print()
        print(report.summary())
        return 2

    model = device_model(serial)
    report.passed(10, f"model {model}")

    healthy, health_text = probe_health(host, port)
    if healthy:
        report.passed(11, f"server reachable at https://{host}:{port} ({health_text[:60]})")
    else:
        report.warn(11, f"server not answering on https://{host}:{port} ({health_text}) — "
                        "start it from the panel; enrollment is verified at the end")

    if args.skip_install:
        report.skipped(2, "install skipped (--skip-install)")
    elif not install_apk(serial, args.apk, report):
        print()
        print(report.summary())
        return 3

    if args.skip_grants:
        report.skipped(3, "runtime permissions skipped (--skip-grants)")
    else:
        grant_runtime_permissions(serial, report)

    if args.skip_specials or args.skip_grants:
        report.skipped(4, "special grants skipped")
    else:
        grant_special_permissions(serial, report)

    if not launch_provisioning(serial, host, port, key, report):
        print()
        print(report.summary())
        return 4

    if args.skip_verify:
        report.skipped(6, "enrollment check skipped (--skip-verify)")
    else:
        deadline = time.time() + max(args.wait, 5)
        result: tuple[bool, str] = (False, "not checked")
        while time.time() < deadline:
            result = verify_enrollment(model, started)
            if result[0]:
                break
            time.sleep(3)
        if result[0]:
            report.passed(6, f"enrollment confirmed: {result[1]}")
        else:
            report.warn(6, f"enrollment not confirmed yet: {result[1]}")
            report.warn(7, "open the panel on the phone and check the log line for the enroll result")

    print()
    print("-" * 68)
    print(report.summary())
    print("-" * 68)
    if any(status == "WARN" for status, _, _ in report.rows):
        print("Manual follow-up on the phone (adb cannot silently grant these):")
        print("  * Settings > Apps > Parental Control > Battery > No restrictions")
        print("  * Settings > Accessibility > Parental Control > enable, if step 4 warned")
        print("  * Device admin prompt, if step 4 warned")
        print("  * dial *#*#6969#*#* to reopen the panel after the launcher icon hides")
    return 0 if not any(status == "FAIL" for status, _, _ in report.rows) else 1


if __name__ == "__main__":
    sys.exit(main())
