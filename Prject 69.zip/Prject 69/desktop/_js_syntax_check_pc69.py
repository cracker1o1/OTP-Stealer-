#!/usr/bin/env python3
"""Extract the <script> body of web_dashboard.html so it can be syntax-checked.

The dashboard is one self-contained HTML file with no build step, so pulling the
script out and running `node --check` on it is the only way to catch a real
JavaScript syntax error before the browser shows a blank page.
"""
from __future__ import annotations

import re
from pathlib import Path

HTML = Path(__file__).resolve().parent / "web_dashboard.html"
OUT = Path(__file__).resolve().parent / "_dashboard_extract_pc69.js"


def main() -> int:
    html = HTML.read_text(encoding="utf-8")
    match = re.search(r"<script>(.*?)</script>", html, re.S)
    if not match:
        print("no <script> block found")
        return 2
    source = match.group(1)
    OUT.write_text(source, encoding="utf-8", newline="\n")
    print(f"wrote {len(source.splitlines())} lines to {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
