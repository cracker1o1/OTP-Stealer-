#!/usr/bin/env python3
"""Proves whether a silent TCP client can stall the server (PC69).

A client that opens a TCP connection to the TLS port and then sends nothing
(no ClientHello) leaves the accept loop waiting. This script opens a few such
connections and then checks whether a real HTTPS request still gets an answer.

Run it against the server before and after the fix: before, the health request
times out even though the port still shows as LISTENING; after, it answers.
"""

from __future__ import annotations

import socket
import ssl
import sys
import time
import urllib.error
import urllib.request

HOST = "127.0.0.1"
PORT = 8443


def https_get(path: str = "/api/v1/health", timeout: float = 6.0):
    ctx = ssl._create_unverified_context()
    url = f"https://{HOST}:{PORT}{path}"
    started = time.time()
    try:
        with urllib.request.urlopen(url, timeout=timeout, context=ctx) as resp:
            return resp.status, resp.read(120).decode("utf-8", "replace"), time.time() - started
    except Exception as exc:                      # noqa: BLE001 - report whatever happened
        return None, f"{type(exc).__name__}: {exc}", time.time() - started


def silent_conn():
    sock = socket.create_connection((HOST, PORT), timeout=5)
    return sock


def main() -> int:
    status, body, took = https_get()
    print(f"1. baseline health request          -> {status} ({body[:40]!r}) in {took:.1f}s")

    open_socks = []
    for _ in range(3):
        open_socks.append(silent_conn())
    print(f"2. opened {len(open_socks)} TCP connections and sent no TLS handshake")
    time.sleep(1.0)

    status_silent, body_silent, took_silent = https_get(timeout=8)
    print(f"3. health request while they idle  -> {status_silent} "
          f"({str(body_silent)[:60]!r}) in {took_silent:.1f}s")

    half = silent_conn()
    half.sendall(b"\x16\x03\x01\x00\x50")          # TLS record header, then stop
    open_socks.append(half)
    print("4. opened a connection that starts a handshake and stops mid-way")
    time.sleep(1.0)

    status_half, body_half, took_half = https_get(timeout=8)
    print(f"5. health request after that       -> {status_half} "
          f"({str(body_half)[:60]!r}) in {took_half:.1f}s")

    for sock in open_socks:
        try:
            sock.close()
        except OSError:
            pass
    time.sleep(0.5)
    status_after, _body_after, took_after = https_get(timeout=8)
    print(f"6. health request after closing    -> {status_after} in {took_after:.1f}s")

    survived = status == 200 and status_silent == 200 and status_half == 200
    print("RESULT: " + ("PASS - the server kept answering while silent clients idled"
                        if survived else
                        "FAIL - a silent TCP client stalled the server "
                        "(port still LISTENING, no request answered)"))
    return 0 if survived else 1


if __name__ == "__main__":
    sys.exit(main())
