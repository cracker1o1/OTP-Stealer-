#!/usr/bin/env python3
"""Checks for "fetch latest from the phone" and the live camera button (PC69).

Covers three layers of the same feature:
  * the API contract  - catalog mapping, refresh command round-trip, row growth
  * the media path    - camera_photo -> /api/v1/media/photo -> Media grid
  * the desktop panel - the button that queues the action and reloads the grid

Everything runs in-process against a throwaway database, capture directory and
config file, so the live pc69.sqlite3 and the photos the phone already uploaded
are untouched. The panel part is skipped (not failed) when no display is
available.
"""

from __future__ import annotations

import base64
import json
import secrets
import sys
import tempfile
import time
from pathlib import Path

import server_gui as S

PASSWORD = "test-pass-123"
UID = "UID-REFRESH-1"
ENROLL_KEY = "test-enroll-key"
MIN_JPEG = base64.b64decode(
    "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0a"
    "HBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCAABAAEBAREA/8QAFAABAAAAAAAA"
    "AAAAAAAAAAAACf/EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAD8AKp//2Q=="
)

CHECKS: list[tuple[bool, str]] = []
SKIPPED: list[str] = []


def check(ok: bool, label: str) -> None:
    CHECKS.append((bool(ok), label))
    print(("PASS  " if ok else "FAIL  ") + label)


def skip(label: str, why: str) -> None:
    SKIPPED.append(label)
    print(f"SKIP  {label} ({why})")


def catalog_payload(app, client) -> dict:
    resp = client.get("/api/v1/web/catalog")
    assert resp.status_code == 200, f"catalog -> {resp.status_code}"
    return resp.get_json() or {}


def main() -> int:
    tmp = Path(tempfile.mkdtemp(prefix="pc69-refresh-"))
    S.CAPTURE_DIR = tmp / "captures"
    S.CAPTURE_DIR.mkdir(parents=True, exist_ok=True)
    S.CONFIG_PATH = tmp / "server_config.json"
    S.DB_PATH = tmp / "test.sqlite3"          # the panel reads this global
    store = S.Store(S.DB_PATH)

    config = {
        "host": "0.0.0.0",
        "port": 8443,
        "enrollment_key": ENROLL_KEY,
        "sync_interval_s": 60,
        "sms_interval_s": 300,
        "web_username": "operator",
        "web_password_hash": S.hash_password(PASSWORD),
        "session_secret": secrets.token_hex(32),
    }
    S.CONFIG_PATH.write_text(json.dumps(config), encoding="utf-8")
    app = S.create_api(store, config)

    # -- the phone enrolls the way the APK does ----------------------------
    phone = app.test_client()
    r = phone.post("/api/v1/enroll", json={
        "enrollment_key": ENROLL_KEY, "device_uid": UID, "label": "Refresh test",
        "model": "Pixel 7", "manufacturer": "Google",
    })
    enrolled = r.get_json() or {}
    did, dev_token = enrolled.get("device_id"), enrolled.get("device_token")
    check(r.status_code == 200 and bool(dev_token), f"phone enrolls -> 200 (got {r.status_code})")
    DEV = {"Authorization": f"Bearer {dev_token}", "X-Device-Uid": UID}
    check(phone.get("/api/v1/commands", headers=DEV).status_code == 200,
          "device API still open to the enrolled phone (no browser login needed)")

    # -- operator logs in to the browser surface ---------------------------
    logged = app.test_client()
    r = logged.post("/auth/login", json={"username": "operator", "password": PASSWORD})
    check(r.status_code == 200, f"operator login -> 200 (got {r.status_code})")
    raw = logged.get_cookie(S.SESSION_COOKIE)
    logged.set_cookie(S.SESSION_COOKIE, str(getattr(raw, "value", raw)))

    # ======================================================================
    # A. catalog: one mapping drives the "Fetch latest" button in every UI
    # ======================================================================
    cat = catalog_payload(app, logged)
    refresh = cat.get("refresh_actions") or {}
    expected = {
        "SMS": "sms_refresh", "Calls": "call_log_refresh", "Contacts": "contacts_refresh",
        "Clipboard": "clipboard_now", "Locations": "location_now", "Media": "media_refresh",
        "Apps": "sync_now", "Usage": "sync_now",
    }
    check(refresh == expected, f"catalog refresh_actions = {json.dumps(refresh, sort_keys=True)}")
    check(all(S.DATA_KINDS) and set(refresh) == set(S.DATA_KINDS),
          "every data kind has a refresh action (no tab without a button)")
    check(all(action in S.COMMAND_CATALOG for action in refresh.values()),
          "every mapped refresh action is a real command in the catalog")
    listed = set(cat.get("catalog") or {})
    missing = {a for a in ("call_log_refresh", "contacts_refresh", "clipboard_now",
                           "location_now", "media_refresh") if a not in listed}
    check(not missing, f"catalog exposes the new device actions (missing: {sorted(missing) or 'none'})")

    # ======================================================================
    # B. command path: dashboard press -> phone polls -> result -> dashboard
    # ======================================================================
    r = logged.post(f"/api/v1/web/command/{did}", json={"action": "call_log_refresh"})
    check(r.status_code == 201, f"'Fetch latest' Calls queues call_log_refresh -> 201 (got {r.status_code})")
    cid = (r.get_json() or {}).get("id")
    check(isinstance(cid, int) and cid > 0, f"command id returned ({cid})")

    cmds = (logged.get(f"/api/v1/web/commands/{did}").get_json() or {}).get("commands") or []
    check(any(c["id"] == cid and c["action"] == "call_log_refresh" and c["status"] == "pending"
              for c in cmds), "dashboard shows the refresh command as pending")

    poll = phone.get("/api/v1/commands", headers=DEV).get_json() or {}
    got = [c for c in poll.get("commands") or [] if c["id"] == cid]
    check(bool(got) and got[0]["action"] == "call_log_refresh",
          "phone receives call_log_refresh on its next poll (this re-reads the call log)")

    r = phone.post("/api/v1/command_result",
                   json={"id": cid, "status": "ok", "message": "call log re-read"}, headers=DEV)
    check(r.status_code == 200, f"phone reports command_result -> 200 (got {r.status_code})")
    cmds = (logged.get(f"/api/v1/web/commands/{did}").get_json() or {}).get("commands") or []
    done = [c for c in cmds if c["id"] == cid]
    check(bool(done) and done[0]["status"] == "ok" and "call log re-read" in (done[0]["result_message"] or ""),
          "dashboard shows the finished refresh with the phone's message")

    for action, kind in (("sms_refresh", "SMS"), ("contacts_refresh", "Contacts"),
                         ("media_refresh", "Media"), ("clipboard_now", "Clipboard"),
                         ("location_now", "Locations")):
        resp = logged.post(f"/api/v1/web/command/{did}", json={"action": action})
        check(resp.status_code == 201, f"{kind} refresh action '{action}' accepted (got {resp.status_code})")

    r = logged.post(f"/api/v1/web/command/{did}", json={"action": "warp_drive"})
    check(r.status_code == 400, f"unknown action still rejected -> 400 (got {r.status_code})")

    other = app.test_client()
    other_uid = "UID-REFRESH-2"
    o = other.post("/api/v1/enroll", json={"enrollment_key": ENROLL_KEY, "device_uid": other_uid})
    other_token = (o.get_json() or {}).get("device_token")
    r = other.post("/api/v1/command_result", json={"id": cid, "status": "ok"},
                   headers={"Authorization": f"Bearer {other_token}", "X-Device-Uid": other_uid})
    check(r.status_code == 404, f"a second device cannot answer another device's command (got {r.status_code})")

    # ======================================================================
    # C. row growth: the upload that follows a refresh lands in the grid
    # ======================================================================
    def total(kind: str) -> int:
        return int((logged.get(f"/api/v1/web/data/{did}/{kind}").get_json() or {})["total"])

    def rows(kind: str) -> list[dict]:
        return (logged.get(f"/api/v1/web/data/{did}/{kind}").get_json() or {})["rows"]

    before = {k: total(k) for k in ("SMS", "Calls", "Contacts", "Media")}
    now_ms = int(time.time() * 1000)
    telemetry = {
        "sms_logs": [{"sender": "+15550001111", "body": "refresh test sms",
                      "direction": "in", "timestamp": now_ms}],
        "call_logs": [{"number": "+15550002222", "name": "Refresh Test", "type": "incoming",
                       "duration_s": 42, "timestamp": now_ms}],
        "contacts": [{"display_name": "Refresh Contact", "numbers": ["+15550003333"],
                      "emails": ["refresh@example.com"]}],
    }
    r = phone.post("/api/v1/telemetry", json=telemetry, headers=DEV)
    stored = (r.get_json() or {}).get("stored") or {}
    check(r.status_code == 200 and stored.get("calls") == 1 and stored.get("contacts") == 1
          and stored.get("sms") == 1,
          f"phone upload after the refresh is stored (stored={stored})")

    check(total("Calls") == before["Calls"] + 1, f"Calls grid grows {before['Calls']} -> {total('Calls')}")
    check(total("Contacts") == before["Contacts"] + 1,
          f"Contacts grid grows {before['Contacts']} -> {total('Contacts')}")
    check(total("SMS") == before["SMS"] + 1, f"SMS grid grows {before['SMS']} -> {total('SMS')}")

    call_rows = rows("Calls")
    check(bool(call_rows) and str(call_rows[0]["number"]) == "+15550002222",
          "the freshly read call log is row 1 (newest on top)")
    check(bool(call_rows) and dict(call_rows[0]) and call_rows[0]["time"] not in (None, "")
          and not str(call_rows[0]["time"]).isdigit(),
          f"call time is localised, not a raw epoch ({call_rows[0]['time'] if call_rows else 'n/a'})")
    check(any(str(c["name"]) == "Refresh Contact" for c in rows("Contacts")),
          "the freshly read contact is in the Contacts grid")
    sms_rows = rows("SMS")
    check(bool(sms_rows) and str(sms_rows[0]["address"]) == "+15550001111",
          "the freshly read SMS is row 1 (latest message on top)")

    # A second identical upload must not duplicate: "latest" stays latest.
    phone.post("/api/v1/telemetry", json=telemetry, headers=DEV)
    check(total("Calls") == before["Calls"] + 1 and total("Contacts") == before["Contacts"] + 1
          and total("SMS") == before["SMS"] + 1,
          "re-uploading the same rows does not duplicate them (dedupe holds)")

    # ======================================================================
    # D. live camera: camera_photo -> media/photo -> Media grid -> viewable
    # ======================================================================
    r = logged.post(f"/api/v1/web/command/{did}",
                    json={"action": "camera_photo", "params": {"camera": "front"}})
    check(r.status_code == 201, f"'Live photo' queues camera_photo -> 201 (got {r.status_code})")
    photo_cid = (r.get_json() or {}).get("id")
    poll = phone.get("/api/v1/commands", headers=DEV).get_json() or {}
    shots = [c for c in poll.get("commands") or [] if c["id"] == photo_cid and c["action"] == "camera_photo"]
    check(bool(shots) and (shots[0]["params"] or {}).get("camera") == "front",
          "phone receives camera_photo with the chosen camera")

    check(phone.post("/api/v1/media/photo", data=MIN_JPEG).status_code == 401,
          "photo upload still requires the device token")
    r = phone.post("/api/v1/media/photo", data=MIN_JPEG,
                   headers={**DEV, "Content-Type": "image/jpeg"})
    check(r.status_code == 200 and (r.get_json() or {}).get("bytes") == len(MIN_JPEG),
          f"phone uploads the still -> 200 (got {r.status_code})")

    check(total("Media") == before["Media"] + 1,
          f"Media grid grows {before['Media']} -> {total('Media')} after the still")
    media_rows = rows("Media")
    check(bool(media_rows) and media_rows[0]["kind"] == "photo",
          "the still is the newest Media row (kind=photo)")
    mid = media_rows[0]["id"] if media_rows else 0
    view = logged.get(f"/api/v1/web/media/{mid}")
    check(view.status_code == 200 and view.data == MIN_JPEG
          and (view.headers.get("Content-Type") or "").startswith("image/jpeg"),
          "the dashboard can display the new still (bytes and content-type match)")
    check(logged.get("/api/v1/web/media/999999").status_code in (404, 400),
          "an unknown media id is not served")
    landed = sorted(p.name for p in S.CAPTURE_DIR.glob("*.jpg"))
    check(len(landed) == 1 and landed[0].startswith(f"dev{did}-photo-"),
          f"the still is written under the capture dir ({landed})")

    # ======================================================================
    # E. desktop panel: the button queues the same actions and reloads
    # ======================================================================
    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
    except Exception as exc:                      # no display / no tk
        skip("desktop panel logic", f"tkinter unavailable: {exc!r}")
        root = None

    if root is not None:
        try:
            panel = S.Panel(root)
            panel.selected_device = did
            panel.kind_var.set("Calls")
            counts = store.counts(did)
            check(panel._row_count("Calls") == counts["calls"] and panel._row_count("SMS") == counts["sms"],
                  f"panel row counter matches the store (calls={counts['calls']}, sms={counts['sms']})")
            check(all(panel._row_count(k) == counts[key] for k, key in
                      (("SMS", "sms"), ("Calls", "calls"), ("Contacts", "contacts"),
                       ("Clipboard", "clipboard"), ("Locations", "locations"), ("Media", "media"))),
                  "panel row counter is correct for every kind it can show")

            def newest_command() -> dict | None:
                row = store.one("SELECT * FROM commands WHERE device_id=? ORDER BY id DESC LIMIT 1",
                                (int(did),))
                return dict(row) if row is not None else None

            for kind, action in (("Calls", "call_log_refresh"), ("Contacts", "contacts_refresh"),
                                 ("SMS", "sms_refresh"), ("Clipboard", "clipboard_now"),
                                 ("Locations", "location_now"), ("Media", "media_refresh")):
                panel.kind_var.set(kind)
                panel._fetch_latest()
                last = newest_command() or {}
                check(last.get("action") == action,
                      f"panel 'Fetch from phone' on {kind} queues {action} (got {last.get('action')!r})")

            log_text = lambda: panel.log_text.get("1.0", "end")           # noqa: E731
            panel.kind_var.set("Calls")
            panel._fetch_latest()
            check("call_log_refresh" in log_text(),
                  "panel writes the queued refresh into the command log")

            panel._live_photo()
            last = newest_command() or {}
            check(last.get("action") == "camera_photo"
                  and json.loads(last.get("params") or "{}") == {"camera": "back"},
                  f"panel 'Live photo' queues camera_photo back camera (got {last.get('action')!r})")
            check(panel.kind_var.get() == "Media",
                  "panel 'Live photo' switches the grid to Media so the still is visible")

            # A finished command reloads the grid without waiting for a tick.
            cid2 = store.add_command(int(did), "sms_refresh", {})
            panel.kind_var.set("SMS")
            before_rows = panel._row_count("SMS")
            store.record_result(cid2, int(did), "ok", "sms re-read")
            panel._watch_fetch(cid2, "SMS", before_rows, time.time() + S.FETCH_TIMEOUT_S)
            check(f"#{cid2} ok" in log_text(),
                  f"panel reports command #{cid2} as ok (waits for the answer, then reloads)")

            # Still pending -> it keeps waiting instead of declaring failure ...
            cid3 = store.add_command(int(did), "contacts_refresh", {})
            panel.kind_var.set("Contacts")
            panel._watch_fetch(cid3, "Contacts", panel._row_count("Contacts"),
                               time.time() + S.FETCH_TIMEOUT_S)
            check(f"#{cid3}" not in log_text(),
                  "panel keeps waiting while the command is pending (no premature timeout)")
            # ... and completes on its own Tk timer once the phone answers.
            store.record_result(cid3, int(did), "ok", "contacts re-read")
            deadline = time.time() + 5
            while time.time() < deadline and f"#{cid3} ok" not in log_text():
                root.update()
                time.sleep(0.1)
            check(f"#{cid3} ok" in log_text(),
                  "panel's own timer notices the answer and reloads without another press")

            # The periodic tick only redraws when the stored rows actually changed.
            panel.kind_var.set("Media")
            panel._load_data()
            stale = panel._row_count("Media")
            panel._data_count = stale
            phone.post("/api/v1/media/photo", data=MIN_JPEG, headers={**DEV, "Content-Type": "image/jpeg"})
            panel._reload_data_if_changed()
            check(panel._row_count("Media") == stale + 1 and panel._data_count == stale + 1,
                  f"the periodic reload picks up a new still ({stale} -> {panel._data_count})")
            panel._reload_data_if_changed()
            check(panel._data_count == stale + 1,
                  "a tick with no new rows leaves the grid alone (no redraw/scroll loss)")
        finally:
            root.destroy()

    # ======================================================================
    # results
    # ======================================================================
    failed = [label for ok, label in CHECKS if not ok]
    print("-" * 72)
    print(f"{len(CHECKS) - len(failed)}/{len(CHECKS)} checks passed"
          + (f", {len(SKIPPED)} skipped" if SKIPPED else ""))
    for label in failed:
        print(f"  FAILED: {label}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
