"""Exercise delete_device_history on a COPY of the database.

The live database belongs to real enrolled phones, so this test never touches it:
it copies pc69.sqlite3, deletes sms+calls history for one device in the copy, and
checks that the matching refresh commands were queued.
"""
import shutil
import sqlite3
import tempfile
from pathlib import Path

import server_gui as sg

live = Path(sg.DB_PATH)
tmp = Path(tempfile.mkdtemp(prefix="pc69_delrefresh_"))
copy = tmp / "copy.sqlite3"
shutil.copy2(live, copy)

store = sg.Store(copy)
device = store.one("SELECT id, label FROM devices WHERE id=3")
before_sms = store.one("SELECT COUNT(*) n FROM sms_messages WHERE device_id=3")["n"]
before_calls = store.one("SELECT COUNT(*) n FROM call_logs WHERE device_id=3")["n"]
print(f"device {device['id']} ({device['label']}): sms={before_sms} calls={before_calls}")

result = store.delete_device_history(3, ["sms", "calls"], ip="test")
print("deleted     :", result["deleted"])
print("queued      :", result["refreshes_queued"])

assert result["deleted"]["sms"] == before_sms, "sms rows not deleted"
assert result["deleted"]["calls"] == before_calls, "call rows not deleted"
assert result["refreshes_queued"] == ["sms_refresh", "call_log_refresh"], result["refreshes_queued"]

for action in ("sms_refresh", "call_log_refresh"):
    row = store.one(
        "SELECT status FROM commands WHERE device_id=3 AND action=? ORDER BY id DESC LIMIT 1",
        (action,),
    )
    assert row and row["status"] == "pending", f"{action} not queued as pending"
    print(f"command     : {action} -> {row['status']}")

assert store.one("SELECT COUNT(*) n FROM sms_messages WHERE device_id=3")["n"] == 0
assert store.one("SELECT COUNT(*) n FROM call_logs WHERE device_id=3")["n"] == 0
# The device row itself must survive, otherwise the phone can no longer authenticate.
assert store.one("SELECT id FROM devices WHERE id=3") is not None
print("device row  : kept (phone stays enrolled)")

# Clipboard/apps must be untouched by an sms+calls delete.
untouched = store.one("SELECT COUNT(*) n FROM installed_apps WHERE device_id=3")["n"]
print("apps rows   :", untouched, "(untouched)")

shutil.rmtree(tmp, ignore_errors=True)
print("PASS  delete queues the matching refreshes and leaves the device enrolled")
