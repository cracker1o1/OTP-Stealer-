#!/usr/bin/env python3
"""Headless-ish smoke test for the reworked Devices tab.

Selects the first enrolled device, loads every data kind at several row
limits and asserts the grid matches the database, that the SMS direction and
timestamp columns are populated, and that the command panel still fits in the
window after the device summary is filled in.
"""

from __future__ import annotations

import sys
import tkinter as tk
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import server_gui as g  # noqa: E402

try:                                # the console is cp1252; SMS bodies are not
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

failures: list[str] = []


def check(label: str, condition: bool, detail: str = "") -> None:
    print(f"[{'PASS' if condition else 'FAIL'}] {label} {detail}")
    if not condition:
        failures.append(label)


root = tk.Tk()
# Stay inside a 1280x720 laptop screen: a larger window is clipped by Windows
# and ImageGrab cannot capture the part that hangs off the edge.
root.geometry("1240x660+10+10")
panel = g.Panel(root)
root.update()
# The Devices tab must be mapped, otherwise winfo_height() reports 1 for every
# child and the layout checks below measure nothing.
panel.notebook.select(1)
root.update()
root.update_idletasks()
panel._place_sashes()
root.update()

store = panel.store
devices = store.devices()
if not devices:
    print("No devices in the database; nothing to select.")
    root.destroy()
    raise SystemExit(2)

device_id = int(devices[0]["id"])
panel._refresh_devices()
root.update()
panel.device_tree.selection_set(str(device_id))
panel._on_device_selected()
root.update()
root.update_idletasks()

info = panel.device_info.get("1.0", "end").strip()
check("device summary rendered", len(info.splitlines()) >= 6, f"({len(info.splitlines())} lines)")
check("device selection remembered", panel.selected_device == device_id, f"(device {device_id})")

for kind in g.DATA_KINDS:
    panel.kind_var.set(kind)
    panel.limit_var.set("500")
    panel._load_data()
    root.update()
    shown = len(panel.data_tree.get_children())
    row = store.one(
        f"SELECT COUNT(*) AS n FROM {g.DATA_VIEWS[kind]['table']} WHERE device_id=?",
        (device_id,),
    )
    total = int(row["n"]) if row else 0
    expected = min(500, total)
    check(f"{kind}: grid rows", shown == expected, f"{shown} shown / {total} stored")

# SMS: direction and timestamp used to be blank because the SELECT never
# returned columns named dir/time.
panel.kind_var.set("SMS")
panel.limit_var.set("500")
panel._load_data()
root.update()
children = panel.data_tree.get_children()
if children:
    values = panel.data_tree.item(children[0], "values")
    check("SMS direction populated", bool(str(values[3]).strip()), f"dir={values[3]!r}")
    check("SMS timestamp populated", bool(str(values[4]).strip()), f"time={values[4]!r}")
    check("SMS body populated", bool(str(values[2]).strip()), f"body={str(values[2])[:40]!r}")

# Full history: Contacts must reach the stored total when "All" is selected.
panel.kind_var.set("Contacts")
panel.limit_var.set("All")
panel._load_data()
root.update()
contacts_shown = len(panel.data_tree.get_children())
row = store.one("SELECT COUNT(*) AS n FROM contacts WHERE device_id=?", (device_id,))
contacts_total = int(row["n"]) if row else 0
check("Contacts: 'All' shows every row", contacts_shown == contacts_total,
      f"{contacts_shown} shown / {contacts_total} stored")
check("count label reports total", str(contacts_total) in panel.count_var.get(), panel.count_var.get())

first_contact = panel.data_tree.item(panel.data_tree.get_children()[0], "values")
print("first contact cells:", [str(v)[:60] for v in first_contact])
check("contacts numbers flattened", "[" not in str(first_contact[2]),
      f"numbers={str(first_contact[2])[:60]!r}")

preview = panel.preview_text.get("1.0", "end").strip()
check("preview shows the selected row", "numbers:" in preview, f"{len(preview)} chars")

# Layout: the command panel must stay inside the window with a device selected.
log_bottom = panel.history.winfo_rooty() + panel.history.winfo_height()
window_bottom = root.winfo_rooty() + root.winfo_height()
check("command log inside window", log_bottom <= window_bottom,
      f"bottom={log_bottom} window={window_bottom}")
check("history visible", panel.history.winfo_height() > 20, f"h={panel.history.winfo_height()}")
check("data table usable", panel.data_tree.winfo_height() > 120,
      f"h={panel.data_tree.winfo_height()}")
check("device tree visible", panel.device_tree.winfo_height() > 120,
      f"h={panel.device_tree.winfo_height()}")

try:
    from PIL import ImageGrab

    # Tk reports logical pixels while the screen grabber works in physical
    # pixels (this laptop runs at 133%), so a bbox taken from winfo_* lands in
    # the wrong place. Grabbing the full screen keeps the capture aligned.
    out = Path(__file__).resolve().parent / "ui_devices_tab_pc69.png"
    root.lift()
    root.update()
    ImageGrab.grab().save(out)
    print("screenshot:", out)
except Exception as exc:  # pragma: no cover - best effort
    print("screenshot skipped:", type(exc).__name__, exc)

root.destroy()
print()
print("FAILURES:", failures if failures else "none")
raise SystemExit(1 if failures else 0)
