"""A forced refresh re-sends the newest window; the ingest must stay idempotent.

Runs entirely in-process against a temp database (Flask test client, no network),
so no enrolled phone and no live row is involved.
"""
import json
import tempfile
from pathlib import Path

import server_gui as sg

tmp = Path(tempfile.mkdtemp(prefix="pc69_resend_"))
store = sg.Store(tmp / "t.sqlite3")
config = dict(sg.load_config())
config["enrollment_key"] = "test-key-pc69"
app = sg.create_api(store, config)
client = app.test_client()

r = client.post("/api/v1/enroll", json={"enrollment_key": "test-key-pc69",
                                        "device_uid": "test-uid-pc69",
                                        "label": "test phone", "app_version": "1.6"})
assert r.status_code in (200, 201), r.status_code
data = r.get_json()
uid, token, did = "test-uid-pc69", data["device_token"], data["device_id"]
auth = {"Authorization": f"Bearer {token}"}
print("enrolled:", uid, "device_id", did)

now = 1_790_000_000_000
sms = [{"sender": "BANK", "body": f"msg {i}", "timestamp": now - i * 60_000,
        "direction": "in"} for i in range(50)]
calls = [{"number": f"98765{i:05d}", "name": None, "type": "incoming",
          "duration_s": 30, "timestamp": now - i * 60_000} for i in range(50)]


def post():
    r = client.post("/api/v1/telemetry", headers=auth,
                    json={"device_id": uid, "sms_logs": sms, "call_logs": calls})
    assert r.status_code in (200, 201), (r.status_code, r.get_data(as_text=True)[:300])
    return r.get_json()


post()
first = (store.one("SELECT COUNT(*) n FROM sms_messages")["n"],
         store.one("SELECT COUNT(*) n FROM call_logs")["n"])
print("after 1st upload :", first)

post()
post()  # two more forced re-sends of the same window
again = (store.one("SELECT COUNT(*) n FROM sms_messages")["n"],
         store.one("SELECT COUNT(*) n FROM call_logs")["n"])
print("after 3 uploads  :", again)

assert first == (50, 50), first
assert again == first, f"re-send duplicated rows: {again}"

# The dashboard view must still show exactly the newest 50, newest first.
rows = store.all(sg.DATA_VIEWS["SMS"]["sql"] + " LIMIT ?", (did, sg.SMS_WINDOW))
assert len(rows) == 50 and rows[0]["time"] == now, rows[0]["time"]
print("sms view         :", len(rows), "rows, newest ts", rows[0]["time"])

import shutil
shutil.rmtree(tmp, ignore_errors=True)
print("PASS  repeated window uploads are idempotent (no duplicates, newest kept)")
