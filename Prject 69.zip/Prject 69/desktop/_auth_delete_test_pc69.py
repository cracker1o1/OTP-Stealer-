#!/usr/bin/env python3
"""Checks for the operator login and the scoped history delete (PC69).

Everything runs in-process against a throwaway database and capture directory,
so the live pc69.sqlite3 and the photos the phone already uploaded are untouched.
"""

from __future__ import annotations

import json
import secrets
import sys
import tempfile
from pathlib import Path

import server_gui as S

PASSWORD = "test-pass-123"
CHECKS: list[tuple[bool, str]] = []


def check(ok: bool, label: str) -> None:
    CHECKS.append((bool(ok), label))


def logged_in(app, config, user: str = "operator", password: str = PASSWORD):
    client = app.test_client()
    resp = client.post("/auth/login", json={"username": user, "password": password})
    assert resp.status_code == 200, f"login failed in setup: {resp.status_code}"
    return client


def main() -> int:
    tmp = Path(tempfile.mkdtemp(prefix="pc69-auth-"))
    S.CAPTURE_DIR = tmp / "captures"
    S.CONFIG_PATH = tmp / "server_config.json"
    store = S.Store(tmp / "test.sqlite3")

    config = {
        "host": "0.0.0.0",
        "port": 8443,
        "enrollment_key": "test-enroll-key",
        "sync_interval_s": 60,
        "sms_interval_s": 300,
        "web_username": "operator",
        "web_password_hash": S.hash_password(PASSWORD),
        "session_secret": secrets.token_hex(32),
    }
    app = S.create_api(store, config)
    anon = app.test_client()

    # -- the browser surface is closed until someone logs in ---------------
    r = anon.get("/api/v1/web/devices")
    check(r.status_code == 401, f"anonymous device list -> 401 (got {r.status_code})")
    check(anon.get("/devices").status_code == 401, "anonymous /devices -> 401")
    check(anon.get("/api/v1/web/catalog").status_code == 401, "anonymous catalog -> 401")
    check(anon.get("/auth/me").status_code == 401, "anonymous /auth/me -> 401")
    check(anon.get("/").status_code == 200, "dashboard shell itself loads without a session")

    r = anon.post("/auth/login", json={"username": "operator", "password": "wrong-pass"})
    check(r.status_code == 401, f"wrong password -> 401 (got {r.status_code})")
    r = anon.post("/auth/login", json={"username": "nobody", "password": PASSWORD})
    check(r.status_code == 401, f"wrong username -> 401 (got {r.status_code})")
    check("pc69_session" not in "".join(r.headers.getlist("Set-Cookie")),
          "a failed login hands out no cookie")

    r = anon.post("/auth/login", json={"username": "operator", "password": PASSWORD})
    check(r.status_code == 200, f"correct credentials -> 200 (got {r.status_code})")
    cookie = r.headers.get("Set-Cookie", "")
    check(S.SESSION_COOKIE in cookie and "HttpOnly" in cookie,
          "session cookie is set and HttpOnly")
    raw_cookie = anon.get_cookie(S.SESSION_COOKIE)
    token = getattr(raw_cookie, "value", raw_cookie)
    check(bool(token) and token.count(".") == 1, "session token is payload.signature")
    check(S.read_session(config, token or "") == "operator", "token verifies server-side")

    client = app.test_client()
    client.set_cookie(S.SESSION_COOKIE, str(token))
    r = client.get("/api/v1/web/devices")
    check(r.status_code == 200, f"logged-in device list -> 200 (got {r.status_code})")
    check((client.get("/auth/me").get_json() or {}).get("username") == "operator",
          "/auth/me reports the logged-in user")

    # -- a session cannot be forged or kept past its expiry ----------------
    forged = app.test_client()
    forged.set_cookie(S.SESSION_COOKIE, (token or "")[:-6] + "abcdef")
    check(forged.get("/api/v1/web/devices").status_code == 401, "tampered signature -> 401")
    forged.set_cookie(S.SESSION_COOKIE, S.issue_session({"session_secret": secrets.token_hex(32)},
                                                       "operator"))
    check(forged.get("/api/v1/web/devices").status_code == 401,
          "token signed with another key -> 401")
    expired = app.test_client()
    expired.set_cookie(S.SESSION_COOKIE, S.issue_session(config, "operator", ttl=-60))
    check(expired.get("/api/v1/web/devices").status_code == 401, "expired token -> 401")

    # -- logout clears it ---------------------------------------------------
    r = client.post("/auth/logout")
    check(r.status_code == 200, "logout accepted")
    check(client.get("/api/v1/web/devices").status_code == 401,
          "after logout the dashboard is closed again")

    # -- the phone side is untouched ---------------------------------------
    check(anon.post("/api/v1/health").status_code == 200, "device health stays open")
    r = anon.post("/api/v1/enroll", json={"enrollment_key": "test-enroll-key",
                                         "device_uid": "TEST-UID-1",
                                         "model": "Pixel 7",
                                         "manufacturer": "Google"})
    check(r.status_code == 200, f"device can still enroll without a cookie (got {r.status_code})")
    payload = r.get_json() or {}
    device_id = int(payload.get("device_id") or 0)
    device_token = str(payload.get("device_token") or "")
    check(device_id > 0 and len(device_token) == 64, "enroll returned an id and a device token")
    poll = anon.get("/api/v1/commands?device_id=TEST-UID-1",
                    headers={"Authorization": f"Bearer {device_token}"})
    check(poll.status_code == 200, f"device command poll works unauthenticated (got {poll.status_code})")

    # -- seed some history to delete ---------------------------------------
    store.write("""INSERT INTO sms_messages (device_id, address, body, ts, dedupe_hash)
                   VALUES (?,'+911111111111','hello',1,'h-sms')""", (device_id,))
    store.write("""INSERT INTO call_logs (device_id, number, call_type, dedupe_hash)
                   VALUES (?,'+912222222222','incoming','h-call')""", (device_id,))
    store.write("""INSERT INTO contacts (device_id, display_name, dedupe_hash)
                   VALUES (?,'Alice','h-contact')""", (device_id,))
    store.add_command(device_id, "camera_photo", {}, default_sms_interval=300)
    media_file = store.save_media(device_id, "photo", b"\xff\xd8\xff\xe0fake-jpeg", "jpg", "image/jpeg")
    check(media_file.is_file(), "seed capture file exists on disk")
    counts = store.counts(device_id)
    check(counts["sms"] == 1 and counts["calls"] == 1 and counts["contacts"] == 1,
          "seed history rows are in place")

    client = logged_in(app, config)

    # -- the delete endpoint refuses sloppy or unconfirmed calls -----------
    r = client.delete(f"/api/v1/web/history/{device_id}", json={"scopes": ["sms"]})
    check(r.status_code == 400, f"no confirmation echo -> 400 (got {r.status_code})")
    r = client.delete(f"/api/v1/web/history/{device_id}",
                      json={"scopes": ["sms"], "confirm": "wrong"})
    check(r.status_code == 400, f"wrong confirmation echo -> 400 (got {r.status_code})")
    r = client.delete(f"/api/v1/web/history/{device_id}",
                      json={"scopes": ["bogus"], "confirm": "TEST-UID-1:bogus"})
    check(r.status_code == 400, f"unknown scope -> 400 (got {r.status_code})")
    r = client.delete("/api/v1/web/history/9999", json={"scopes": ["sms"], "confirm": "x"})
    check(r.status_code == 404, f"unknown device -> 404 (got {r.status_code})")
    r = client.delete(f"/api/v1/web/history/{device_id}", data="scopes=sms",
                      content_type="text/plain")
    check(r.status_code == 415, f"non-JSON write -> 415 (got {r.status_code})")
    check(store.counts(device_id)["sms"] == 1, "rejected calls deleted nothing")

    anonymous = app.test_client()
    r = anonymous.delete(f"/api/v1/web/history/{device_id}",
                         json={"scopes": ["all"], "confirm": f"TEST-UID-1:{','.join(sorted(S.HISTORY_SCOPES))}"})
    check(r.status_code == 401, f"delete without a session -> 401 (got {r.status_code})")
    check(store.counts(device_id)["sms"] == 1, "unauthenticated delete changed nothing")

    # -- scoped delete only touches what was asked for ---------------------
    r = client.delete(f"/api/v1/web/history/{device_id}",
                      json={"scopes": ["sms", "media"], "confirm": "TEST-UID-1:media,sms"})
    body = r.get_json() or {}
    check(r.status_code == 200, f"scoped delete -> 200 (got {r.status_code})")
    check(body.get("deleted", {}).get("sms") == 1, "sms rows reported as deleted")
    check(body.get("deleted", {}).get("media") == 1, "media rows reported as deleted")
    check(body.get("files_removed") == 1, "one capture file was unlinked")
    check(not media_file.exists(), "capture file is gone from disk")
    check(store.counts(device_id)["media"] == 0, "media table emptied for this device")
    check(store.counts(device_id)["calls"] == 1, "call log untouched by a sms+media delete")
    check(store.counts(device_id)["contacts"] == 1, "contacts untouched by a sms+media delete")

    # -- 'all' clears everything but keeps the device enrolled -------------
    everything = ",".join(sorted(S.HISTORY_SCOPES))
    r = client.delete(f"/api/v1/web/history/{device_id}",
                      json={"scopes": ["all"], "confirm": f"TEST-UID-1:{everything}"})
    body = r.get_json() or {}
    check(r.status_code == 200, f"'all' delete -> 200 (got {r.status_code})")
    check(sorted(body.get("scopes", [])) == sorted(S.HISTORY_SCOPES), "'all' expanded to every scope")
    remaining = store.counts(device_id)
    check(all(value == 0 for value in remaining.values()),
          f"every history table is empty (left: {remaining})")
    check(store.device_by_id(device_id) is not None, "device row itself is kept")
    poll = anon.get("/api/v1/commands?device_id=TEST-UID-1",
                    headers={"Authorization": f"Bearer {device_token}"})
    check(poll.status_code == 200, "device still authenticates after its history was deleted")

    audits = store.one("SELECT COUNT(*) AS n FROM audit_log WHERE action='delete_device_history'")
    check((int(audits["n"]) if audits else 0) == 2, "both real deletes were audited")

    # -- legacy plaintext password is migrated, then erased ----------------
    S.CONFIG_PATH.write_text(json.dumps({"web_password": "legacy-pass", "web_username": ""}),
                             encoding="utf-8")
    cfg = S.load_config()
    check("web_password" not in cfg, "plaintext web_password dropped from the config dict")
    check(S.verify_password("legacy-pass", str(cfg.get("web_password_hash") or "")),
          "legacy password still logs in, now as a hash")
    check(cfg.get("web_username") == "admin", "blank username defaults to admin")
    check(len(str(cfg.get("session_secret") or "")) >= 64, "a session secret is stored")
    on_disk = json.loads(S.CONFIG_PATH.read_text(encoding="utf-8"))
    check("web_password" not in on_disk, "the plaintext key is gone from server_config.json")
    check(str(on_disk.get("web_password_hash", "")).startswith(S.PBKDF2_PREFIX + "$"),
          "only the PBKDF2 hash is written to disk")

    # -- fail closed when no password is configured ------------------------
    bare = S.create_api(S.Store(tmp / "bare.sqlite3"), {
        "enrollment_key": "k", "sync_interval_s": 60, "sms_interval_s": 300,
        "web_username": "admin", "web_password_hash": "", "session_secret": secrets.token_hex(32),
    })
    r = bare.test_client().get("/api/v1/web/devices")
    check(r.status_code == 503, f"no password configured -> 503 (got {r.status_code})")
    check(bare.test_client().post("/auth/login",
                                  json={"username": "admin", "password": ""}).status_code == 503,
          "login refuses while no password is configured")

    failed = [label for ok, label in CHECKS if not ok]
    for ok, label in CHECKS:
        print(("PASS  " if ok else "FAIL  ") + label)
    print(f"\n{len(CHECKS) - len(failed)}/{len(CHECKS)} checks passed")
    if failed:
        print("failed:")
        for label in failed:
            print("  - " + label)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
