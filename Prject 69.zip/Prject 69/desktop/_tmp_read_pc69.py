#!/usr/bin/env python3
"""Prints the status of the two live refresh commands and the device-3 grid totals."""

from __future__ import annotations

import json
from pathlib import Path

OUT = Path(__file__).resolve().parent / "_tmp_pc69_http"


def load(name: str):
    path = OUT / name
    return json.loads(path.read_text(encoding="utf-8", errors="replace")) if path.exists() else {}


log = load("commands_after.json")
for row in (log.get("commands") or [])[:4]:
    print(f"command #{row['id']:<4} {row['action']:<18} status={row['status']:<10} "
          f"created={row['created_at']} delivered={row['delivered_at']} "
          f"message={row['result_message']!r}")

for kind in ("Calls", "Media"):
    grid = load(f"after_{kind}.json")
    print(f"{kind}: total={grid.get('total')} columns={grid.get('columns')}")
    for row in (grid.get("rows") or [])[:3]:
        print(f"   {row}")
