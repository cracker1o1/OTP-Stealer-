# Restart the parental-control server on 8443 with the current code.
$ErrorActionPreference = 'Continue'
Set-Location 'C:\Users\Dell\Desktop\Prject 69\desktop'

$listeners = Get-NetTCPConnection -LocalPort 8443 -State Listen -ErrorAction SilentlyContinue
foreach ($c in $listeners) {
    Write-Output ("killing_old_pid=" + $c.OwningProcess)
    Stop-Process -Id $c.OwningProcess -Force -ErrorAction SilentlyContinue
}
Start-Sleep -Seconds 2

Remove-Item '_server_out_pc69.log','_server_err_pc69.log' -ErrorAction SilentlyContinue
$proc = Start-Process -FilePath 'pythonw' `
    -ArgumentList 'server_gui.py','--autostart','--port','8443' `
    -WorkingDirectory 'C:\Users\Dell\Desktop\Prject 69\desktop' `
    -RedirectStandardOutput '_server_out_pc69.log' `
    -RedirectStandardError '_server_err_pc69.log' -PassThru
Write-Output ("new_pid=" + $proc.Id)

Start-Sleep -Seconds 10
$now = Get-NetTCPConnection -LocalPort 8443 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($now) { Write-Output ("listening_pid=" + $now.OwningProcess) } else { Write-Output 'listening_pid=NONE' }
