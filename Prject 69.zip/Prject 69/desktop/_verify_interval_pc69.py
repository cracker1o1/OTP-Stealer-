"""PC69: verify per-device SMS interval persistence and fallback.

Runs against a throwaway copy of the live database so the enrolled device is
never touched. Exercises the real code paths:

  Store.add_command(..., "set_sms_interval", {"seconds": N})  -> persists override
  Store.sms_interval_for(row, default)                        -> override, else default
"""
import shutil
import sqlite3
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import server_gui as sg  # noqa: E402  (import after path fix; no module-level side effects)

LIVE = Path("pc69.sqlite3")
tmpdir = Path(tempfile.mkdtemp(prefix="pc69_verify_"))
copy = tmpdir / "verify.sqlite3"

# Consistent snapshot of the live DB (WAL-safe).
src = sqlite3.connect(str(LIVE))
dst = sqlite3.connect(str(copy))
with dst:
    src.backup(dst)
src.close()
dst.close()

store = sg.Store(copy)
dev = store.one("SELECT * FROM devices ORDER BY id DESC LIMIT 1")
start = dev["sms_interval_s"]
baseline = store.one(
    "SELECT COUNT(*) c FROM commands WHERE device_id=? AND action='set_sms_interval'",
    (dev["id"],),
)["c"]

print("device  : id=%s model=%s" % (dev["id"], dev["model"]))
print("initial sms_interval_s: %s" % start)
print("pre-existing set_sms_interval commands: %s" % baseline)

fails = []


def check(label, got, want):
    ok = got == want
    print("  [%s] %-46s got=%s want=%s" % ("PASS" if ok else "FAIL", label, got, want))
    if not ok:
        fails.append(label)


print("\n1) add_command persists the override")
store.add_command(dev["id"], "set_sms_interval", {"seconds": 45})
row = store.one("SELECT * FROM devices WHERE id=?", (dev["id"],))
check("devices.sms_interval_s after seconds=45", row["sms_interval_s"], 45)
check("sms_interval_for() reports the override", store.sms_interval_for(row, 60), 45)

print("\n2) clamps out-of-range values")
store.add_command(dev["id"], "set_sms_interval", {"seconds": 99999})
row = store.one("SELECT * FROM devices WHERE id=?", (dev["id"],))
check("seconds=99999 clamped to MAX", row["sms_interval_s"], sg.MAX_SMS_INTERVAL_S)
store.add_command(dev["id"], "set_sms_interval", {"seconds": 0})
row = store.one("SELECT * FROM devices WHERE id=?", (dev["id"],))
check("seconds=0 clamped to MIN", row["sms_interval_s"], sg.MIN_SMS_INTERVAL_S)

print("\n3) NULL override falls back to the global config default")
store.write("UPDATE devices SET sms_interval_s=NULL WHERE id=?", (dev["id"],))
row = store.one("SELECT * FROM devices WHERE id=?", (dev["id"],))
check("sms_interval_for(NULL, 60)", store.sms_interval_for(row, 60), 60)

print("\n4) unrelated commands do not clobber the override")
store.add_command(dev["id"], "set_sms_interval", {"seconds": 30})
before = store.one("SELECT sms_interval_s FROM devices WHERE id=?", (dev["id"],))[0]
store.add_command(dev["id"], "sync_now", {})
after = store.one("SELECT sms_interval_s FROM devices WHERE id=?", (dev["id"],))[0]
check("override preserved after sync_now", after, before)

print("\n5) every call queued a command row (GUI and API share this path)")
n = store.one(
    "SELECT COUNT(*) c FROM commands WHERE device_id=? AND action='set_sms_interval'",
    (dev["id"],),
)["c"]
check("set_sms_interval rows added by this run", n - baseline, 4)

store.conn().close()
shutil.rmtree(tmpdir, ignore_errors=True)
print("\nsnapshot removed: %s" % (not tmpdir.exists()))
print("\nRESULT: %s" % ("ALL CHECKS PASSED" if not fails else "FAILURES: %s" % fails))
sys.exit(0 if not fails else 1)
